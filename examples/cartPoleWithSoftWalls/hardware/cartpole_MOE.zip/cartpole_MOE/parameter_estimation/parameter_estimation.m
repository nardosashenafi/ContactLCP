A0 = 0.3;
omega = 2*pi*0.2;
phi = 0*pi/180;
k = 4.0;
lambda = 1.0;
bhat0 = -0.25;
mhat0 = -0.5;