/*
 * parameter_Estimation_2019a.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "parameter_Estimation_2019a".
 *
 * Model version              : 1.3
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C source code generated on : Wed Feb  1 12:33:17 2023
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_parameter_Estimation_2019a_h_
#define RTW_HEADER_parameter_Estimation_2019a_h_
#include <math.h>
#include <float.h>
#include <string.h>
#include <stddef.h>
#ifndef parameter_Estimation_2019a_COMMON_INCLUDES_
# define parameter_Estimation_2019a_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#include "hil.h"
#include "quanser_messages.h"
#include "quanser_extern.h"
#endif                         /* parameter_Estimation_2019a_COMMON_INCLUDES_ */

#include "parameter_Estimation_2019a_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetContStateDisabled
# define rtmGetContStateDisabled(rtm)  ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
# define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
# define rtmGetContStates(rtm)         ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
# define rtmSetContStates(rtm, val)    ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
# define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
# define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
# define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
# define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetIntgData
# define rtmGetIntgData(rtm)           ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
# define rtmSetIntgData(rtm, val)      ((rtm)->intgData = (val))
#endif

#ifndef rtmGetOdeF
# define rtmGetOdeF(rtm)               ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
# define rtmSetOdeF(rtm, val)          ((rtm)->odeF = (val))
#endif

#ifndef rtmGetOdeY
# define rtmGetOdeY(rtm)               ((rtm)->odeY)
#endif

#ifndef rtmSetOdeY
# define rtmSetOdeY(rtm, val)          ((rtm)->odeY = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
# define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
# define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
# define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
# define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetRTWLogInfo
# define rtmGetRTWLogInfo(rtm)         ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetZCCacheNeedsReset
# define rtmGetZCCacheNeedsReset(rtm)  ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
# define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetdX
# define rtmGetdX(rtm)                 ((rtm)->derivs)
#endif

#ifndef rtmSetdX
# define rtmSetdX(rtm, val)            ((rtm)->derivs = (val))
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T Kenc;                         /* '<Root>/Kenc' */
  real_T DiscreteFilter1;              /* '<Root>/Discrete Filter1' */
  real_T Integrator;                   /* '<Root>/Integrator' */
  real_T Integrator1;                  /* '<Root>/Integrator1' */
  real_T Gain6;                        /* '<S2>/Gain6' */
  real_T Saturation1;                  /* '<S2>/Saturation1' */
  real_T Onoroff;                      /* '<Root>/On or off' */
  real_T Product;                      /* '<Root>/Product' */
  real_T Product1;                     /* '<Root>/Product1' */
} B_parameter_Estimation_2019a_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T DiscreteFilter_states;        /* '<S1>/Discrete Filter' */
  real_T DiscreteFilter1_states[2];    /* '<Root>/Discrete Filter1' */
  real_T HILInitialize_AOVoltages[2];  /* '<Root>/HIL Initialize' */
  real_T DiscreteFilter_tmp;           /* '<S1>/Discrete Filter' */
  real_T DiscreteFilter1_tmp;          /* '<Root>/Discrete Filter1' */
  t_card HILInitialize_Card;           /* '<Root>/HIL Initialize' */
  t_task HILReadEncoderTimebase1_Task; /* '<Root>/HIL Read Encoder Timebase1' */
  void *HILWriteAnalog_PWORK;          /* '<Root>/HIL Write Analog' */
  struct {
    void *LoggedData;
  } Voltage_PWORK;                     /* '<Root>/Voltage' */

  struct {
    void *LoggedData;
  } bhat_PWORK;                        /* '<Root>/bhat' */

  struct {
    void *LoggedData;
  } mhat_PWORK;                        /* '<Root>/mhat' */

  struct {
    void *LoggedData;
  } v_PWORK;                           /* '<Root>/v' */

  struct {
    void *LoggedData;
  } voltage_PWORK;                     /* '<Root>/voltage' */

  struct {
    void *LoggedData;
  } x_PWORK;                           /* '<Root>/x' */

  int32_T HILReadEncoderTimebase1_Buffer[2];/* '<Root>/HIL Read Encoder Timebase1' */
} DW_parameter_Estimation_2019a_T;

/* Continuous states (default storage) */
typedef struct {
  real_T Integrator_CSTATE;            /* '<Root>/Integrator' */
  real_T Integrator1_CSTATE;           /* '<Root>/Integrator1' */
} X_parameter_Estimation_2019a_T;

/* State derivatives (default storage) */
typedef struct {
  real_T Integrator_CSTATE;            /* '<Root>/Integrator' */
  real_T Integrator1_CSTATE;           /* '<Root>/Integrator1' */
} XDot_parameter_Estimation_201_T;

/* State disabled  */
typedef struct {
  boolean_T Integrator_CSTATE;         /* '<Root>/Integrator' */
  boolean_T Integrator1_CSTATE;        /* '<Root>/Integrator1' */
} XDis_parameter_Estimation_201_T;

#ifndef ODE3_INTG
#define ODE3_INTG

/* ODE3 Integration Data */
typedef struct {
  real_T *y;                           /* output */
  real_T *f[3];                        /* derivatives */
} ODE3_IntgData;

#endif

/* Parameters (default storage) */
struct P_parameter_Estimation_2019a_T_ {
  real_T A0;                           /* Variable: A0
                                        * Referenced by:
                                        *   '<Root>/Sine Wave'
                                        *   '<Root>/Sine Wave1'
                                        *   '<Root>/Sine Wave2'
                                        */
  real_T Kt;                           /* Variable: Kt
                                        * Referenced by:
                                        *   '<S2>/Gain5'
                                        *   '<S2>/Gain6'
                                        */
  real_T Nenc;                         /* Variable: Nenc
                                        * Referenced by: '<Root>/Kenc'
                                        */
  real_T R;                            /* Variable: R
                                        * Referenced by: '<S2>/Gain5'
                                        */
  real_T T;                            /* Variable: T
                                        * Referenced by: '<S1>/Gain3'
                                        */
  real_T Vmax;                         /* Variable: Vmax
                                        * Referenced by: '<S2>/Saturation1'
                                        */
  real_T af[3];                        /* Variable: af
                                        * Referenced by: '<Root>/Discrete Filter1'
                                        */
  real_T bf[3];                        /* Variable: bf
                                        * Referenced by: '<Root>/Discrete Filter1'
                                        */
  real_T bhat0;                        /* Variable: bhat0
                                        * Referenced by: '<Root>/Integrator'
                                        */
  real_T k;                            /* Variable: k
                                        * Referenced by: '<Root>/Gain5'
                                        */
  real_T lambda;                       /* Variable: lambda
                                        * Referenced by:
                                        *   '<Root>/Gain'
                                        *   '<Root>/Gain2'
                                        *   '<Root>/Gain4'
                                        */
  real_T mhat0;                        /* Variable: mhat0
                                        * Referenced by: '<Root>/Integrator1'
                                        */
  real_T omega;                        /* Variable: omega
                                        * Referenced by:
                                        *   '<Root>/Sine Wave'
                                        *   '<Root>/Sine Wave1'
                                        *   '<Root>/Sine Wave2'
                                        */
  real_T phi;                          /* Variable: phi
                                        * Referenced by:
                                        *   '<Root>/Sine Wave'
                                        *   '<Root>/Sine Wave1'
                                        *   '<Root>/Sine Wave2'
                                        */
  real_T r_enc;                        /* Variable: r_enc
                                        * Referenced by: '<Root>/Kenc'
                                        */
  real_T rg;                           /* Variable: rg
                                        * Referenced by:
                                        *   '<S2>/Gain5'
                                        *   '<S2>/Gain6'
                                        */
  real_T rm;                           /* Variable: rm
                                        * Referenced by:
                                        *   '<S2>/Gain5'
                                        *   '<S2>/Gain6'
                                        */
  int32_T HILReadEncoderTimebase1_clock;
                                /* Mask Parameter: HILReadEncoderTimebase1_clock
                                 * Referenced by: '<Root>/HIL Read Encoder Timebase1'
                                 */
  uint32_T HILReadEncoderTimebase1_channel[2];
                              /* Mask Parameter: HILReadEncoderTimebase1_channel
                               * Referenced by: '<Root>/HIL Read Encoder Timebase1'
                               */
  uint32_T HILWriteAnalog_channels;   /* Mask Parameter: HILWriteAnalog_channels
                                       * Referenced by: '<Root>/HIL Write Analog'
                                       */
  uint32_T HILReadEncoderTimebase1_samples;
                              /* Mask Parameter: HILReadEncoderTimebase1_samples
                               * Referenced by: '<Root>/HIL Read Encoder Timebase1'
                               */
  real_T HILInitialize_OOTerminate;/* Expression: set_other_outputs_at_terminate
                                    * Referenced by: '<Root>/HIL Initialize'
                                    */
  real_T HILInitialize_OOExit;    /* Expression: set_other_outputs_at_switch_out
                                   * Referenced by: '<Root>/HIL Initialize'
                                   */
  real_T HILInitialize_AOFinal;        /* Expression: final_analog_outputs
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  real_T HILInitialize_POFinal;        /* Expression: final_pwm_outputs
                                        * Referenced by: '<Root>/HIL Initialize'
                                        */
  real_T DiscreteFilter_NumCoef[2];    /* Expression: [1 -1]
                                        * Referenced by: '<S1>/Discrete Filter'
                                        */
  real_T DiscreteFilter_DenCoef[2];    /* Expression: [1  0]
                                        * Referenced by: '<S1>/Discrete Filter'
                                        */
  real_T DiscreteFilter_InitialStates; /* Expression: 0
                                        * Referenced by: '<S1>/Discrete Filter'
                                        */
  real_T DiscreteFilter1_InitialStates;/* Expression: 0
                                        * Referenced by: '<Root>/Discrete Filter1'
                                        */
  real_T SineWave2_Bias;               /* Expression: 0
                                        * Referenced by: '<Root>/Sine Wave2'
                                        */
  real_T SineWave1_Bias;               /* Expression: 0
                                        * Referenced by: '<Root>/Sine Wave1'
                                        */
  real_T SineWave_Bias;                /* Expression: 0
                                        * Referenced by: '<Root>/Sine Wave'
                                        */
  real_T Onoroff_Gain;                 /* Expression: 1.0
                                        * Referenced by: '<Root>/On or off'
                                        */
  real_T Gain1_Gain;                   /* Expression: -1
                                        * Referenced by: '<Root>/Gain1'
                                        */
  real_T Gain3_Gain;                   /* Expression: -1
                                        * Referenced by: '<Root>/Gain3'
                                        */
  boolean_T HILInitialize_Active;    /* Computed Parameter: HILInitialize_Active
                                      * Referenced by: '<Root>/HIL Initialize'
                                      */
  boolean_T HILInitialize_AOTerminate;
                                /* Computed Parameter: HILInitialize_AOTerminate
                                 * Referenced by: '<Root>/HIL Initialize'
                                 */
  boolean_T HILInitialize_AOExit;    /* Computed Parameter: HILInitialize_AOExit
                                      * Referenced by: '<Root>/HIL Initialize'
                                      */
  boolean_T HILInitialize_DOTerminate;
                                /* Computed Parameter: HILInitialize_DOTerminate
                                 * Referenced by: '<Root>/HIL Initialize'
                                 */
  boolean_T HILInitialize_DOExit;    /* Computed Parameter: HILInitialize_DOExit
                                      * Referenced by: '<Root>/HIL Initialize'
                                      */
  boolean_T HILInitialize_POTerminate;
                                /* Computed Parameter: HILInitialize_POTerminate
                                 * Referenced by: '<Root>/HIL Initialize'
                                 */
  boolean_T HILInitialize_POExit;    /* Computed Parameter: HILInitialize_POExit
                                      * Referenced by: '<Root>/HIL Initialize'
                                      */
  boolean_T HILInitialize_DOFinal;  /* Computed Parameter: HILInitialize_DOFinal
                                     * Referenced by: '<Root>/HIL Initialize'
                                     */
  boolean_T HILReadEncoderTimebase1_Active;
                           /* Computed Parameter: HILReadEncoderTimebase1_Active
                            * Referenced by: '<Root>/HIL Read Encoder Timebase1'
                            */
  boolean_T HILWriteAnalog_Active;  /* Computed Parameter: HILWriteAnalog_Active
                                     * Referenced by: '<Root>/HIL Write Analog'
                                     */
};

/* Real-time Model Data Structure */
struct tag_RTM_parameter_Estimation__T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;
  RTWSolverInfo solverInfo;
  X_parameter_Estimation_2019a_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[2];
  real_T odeF[3][2];
  ODE3_IntgData intgData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (default storage) */
extern P_parameter_Estimation_2019a_T parameter_Estimation_2019a_P;

/* Block signals (default storage) */
extern B_parameter_Estimation_2019a_T parameter_Estimation_2019a_B;

/* Continuous states (default storage) */
extern X_parameter_Estimation_2019a_T parameter_Estimation_2019a_X;

/* Block states (default storage) */
extern DW_parameter_Estimation_2019a_T parameter_Estimation_2019a_DW;

/* Model entry point functions */
extern void parameter_Estimation_2019a_initialize(void);
extern void parameter_Estimation_2019a_step(void);
extern void parameter_Estimation_2019a_terminate(void);

/* Real-time Model object */
extern RT_MODEL_parameter_Estimation_T *const parameter_Estimation_2019a_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'parameter_Estimation_2019a'
 * '<S1>'   : 'parameter_Estimation_2019a/Backward Difference1'
 * '<S2>'   : 'parameter_Estimation_2019a/Force to voltage'
 */
#endif                            /* RTW_HEADER_parameter_Estimation_2019a_h_ */
