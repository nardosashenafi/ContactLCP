/*
 * parameter_estimation_hardware.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "parameter_estimation_hardware".
 *
 * Model version              : 1.9
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C source code generated on : Thu Feb  2 13:38:00 2023
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "parameter_estimation_hardware.h"
#include "parameter_estimation_hardware_private.h"
#include "parameter_estimation_hardware_dt.h"

/* Block signals (default storage) */
B_parameter_estimation_hardwa_T parameter_estimation_hardware_B;

/* Continuous states */
X_parameter_estimation_hardwa_T parameter_estimation_hardware_X;

/* Block states (default storage) */
DW_parameter_estimation_hardw_T parameter_estimation_hardwar_DW;

/* Real-time model */
RT_MODEL_parameter_estimation_T parameter_estimation_hardwar_M_;
RT_MODEL_parameter_estimation_T *const parameter_estimation_hardwar_M =
  &parameter_estimation_hardwar_M_;

/*
 * This function updates continuous states using the ODE1 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE1_IntgData *id = (ODE1_IntgData *)rtsiGetSolverData(si);
  real_T *f0 = id->f[0];
  int_T i;
  int_T nXc = 2;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);
  rtsiSetdX(si, f0);
  parameter_estimation_hardware_derivatives();
  rtsiSetT(si, tnew);
  for (i = 0; i < nXc; ++i) {
    x[i] += h * f0[i];
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model output function */
void parameter_estimation_hardware_output(void)
{
  /* local block i/o variables */
  real_T rtb_HILReadEncoderTimebase1_o2;
  real_T rtb_DiscreteFilter;
  real_T rtb_Add2;
  real_T u0;
  real_T Gain3_tmp;
  if (rtmIsMajorTimeStep(parameter_estimation_hardwar_M)) {
    /* set solver stop time */
    if (!(parameter_estimation_hardwar_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&parameter_estimation_hardwar_M->solverInfo,
                            ((parameter_estimation_hardwar_M->Timing.clockTickH0
        + 1) * parameter_estimation_hardwar_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&parameter_estimation_hardwar_M->solverInfo,
                            ((parameter_estimation_hardwar_M->Timing.clockTick0
        + 1) * parameter_estimation_hardwar_M->Timing.stepSize0 +
        parameter_estimation_hardwar_M->Timing.clockTickH0 *
        parameter_estimation_hardwar_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(parameter_estimation_hardwar_M)) {
    parameter_estimation_hardwar_M->Timing.t[0] = rtsiGetT
      (&parameter_estimation_hardwar_M->solverInfo);
  }

  if (rtmIsMajorTimeStep(parameter_estimation_hardwar_M)) {
    /* S-Function (hil_read_encoder_timebase_block): '<Root>/HIL Read Encoder Timebase1' */

    /* S-Function Block: parameter_estimation_hardware/HIL Read Encoder Timebase1 (hil_read_encoder_timebase_block) */
    {
      t_error result;
      result = hil_task_read_encoder
        (parameter_estimation_hardwar_DW.HILReadEncoderTimebase1_Task, 1,
         &parameter_estimation_hardwar_DW.HILReadEncoderTimebase1_Buffer[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(parameter_estimation_hardwar_M, _rt_error_message);
      } else {
        rtb_DiscreteFilter =
          parameter_estimation_hardwar_DW.HILReadEncoderTimebase1_Buffer[0];
        rtb_HILReadEncoderTimebase1_o2 =
          parameter_estimation_hardwar_DW.HILReadEncoderTimebase1_Buffer[1];
      }
    }

    /* Gain: '<Root>/Kenc' */
    parameter_estimation_hardware_B.Kenc = parameter_estimation_hardware_P.r_enc
      * 2.0 * 3.1415926535897931 / parameter_estimation_hardware_P.Nenc *
      rtb_DiscreteFilter;

    /* DiscreteFilter: '<S1>/Discrete Filter' */
    parameter_estimation_hardwar_DW.DiscreteFilter_tmp =
      (parameter_estimation_hardware_B.Kenc -
       parameter_estimation_hardware_P.DiscreteFilter_DenCoef[1] *
       parameter_estimation_hardwar_DW.DiscreteFilter_states) /
      parameter_estimation_hardware_P.DiscreteFilter_DenCoef[0];
    rtb_DiscreteFilter = parameter_estimation_hardware_P.DiscreteFilter_NumCoef
      [0] * parameter_estimation_hardwar_DW.DiscreteFilter_tmp +
      parameter_estimation_hardware_P.DiscreteFilter_NumCoef[1] *
      parameter_estimation_hardwar_DW.DiscreteFilter_states;

    /* DiscreteFilter: '<Root>/Discrete Filter1' incorporates:
     *  Gain: '<S1>/Gain3'
     */
    parameter_estimation_hardwar_DW.DiscreteFilter1_tmp = ((1.0 /
      parameter_estimation_hardware_P.T * rtb_DiscreteFilter -
      parameter_estimation_hardware_P.af[1] *
      parameter_estimation_hardwar_DW.DiscreteFilter1_states[0]) -
      parameter_estimation_hardware_P.af[2] *
      parameter_estimation_hardwar_DW.DiscreteFilter1_states[1]) /
      parameter_estimation_hardware_P.af[0];
    parameter_estimation_hardware_B.DiscreteFilter1 =
      (parameter_estimation_hardware_P.bf[0] *
       parameter_estimation_hardwar_DW.DiscreteFilter1_tmp +
       parameter_estimation_hardware_P.bf[1] *
       parameter_estimation_hardwar_DW.DiscreteFilter1_states[0]) +
      parameter_estimation_hardware_P.bf[2] *
      parameter_estimation_hardwar_DW.DiscreteFilter1_states[1];
  }

  /* Integrator: '<Root>/Integrator' */
  parameter_estimation_hardware_B.Integrator =
    parameter_estimation_hardware_X.Integrator_CSTATE;

  /* Sin: '<Root>/Sine Wave2' incorporates:
   *  Sin: '<Root>/Sine Wave'
   *  Sin: '<Root>/Sine Wave1'
   */
  rtb_Add2 = parameter_estimation_hardware_P.omega *
    parameter_estimation_hardwar_M->Timing.t[0];
  Gain3_tmp = sin(rtb_Add2 + parameter_estimation_hardware_P.phi);

  /* Sum: '<Root>/Add1' incorporates:
   *  Sin: '<Root>/Sine Wave1'
   */
  parameter_estimation_hardware_B.Add1 =
    parameter_estimation_hardware_B.DiscreteFilter1 - (sin(rtb_Add2 +
    (parameter_estimation_hardware_P.phi + 1.5707963267948966)) *
    (parameter_estimation_hardware_P.A0 * parameter_estimation_hardware_P.omega)
    + parameter_estimation_hardware_P.SineWave1_Bias);

  /* Integrator: '<Root>/Integrator1' */
  parameter_estimation_hardware_B.Integrator1 =
    parameter_estimation_hardware_X.Integrator1_CSTATE;

  /* Sum: '<Root>/Add' incorporates:
   *  Sin: '<Root>/Sine Wave'
   */
  parameter_estimation_hardware_B.Add = parameter_estimation_hardware_B.Kenc -
    (Gain3_tmp * parameter_estimation_hardware_P.A0 +
     parameter_estimation_hardware_P.SineWave_Bias);

  /* Sum: '<Root>/Add2' incorporates:
   *  Gain: '<Root>/Gain'
   */
  rtb_Add2 = parameter_estimation_hardware_P.lambda *
    parameter_estimation_hardware_B.Add + parameter_estimation_hardware_B.Add1;
  if (rtmIsMajorTimeStep(parameter_estimation_hardwar_M)) {
    /* Gain: '<S2>/Gain6' */
    parameter_estimation_hardware_B.Gain6 = parameter_estimation_hardware_P.rg *
      parameter_estimation_hardware_P.Kt / parameter_estimation_hardware_P.rm *
      parameter_estimation_hardware_B.DiscreteFilter1;
  }

  /* Sum: '<Root>/Add5' incorporates:
   *  Gain: '<Root>/Gain4'
   *  Sin: '<Root>/Sine Wave2'
   *  Sum: '<Root>/Add3'
   */
  Gain3_tmp = (Gain3_tmp * (-parameter_estimation_hardware_P.A0 *
    parameter_estimation_hardware_P.omega *
    parameter_estimation_hardware_P.omega) +
               parameter_estimation_hardware_P.SineWave2_Bias) -
    parameter_estimation_hardware_P.lambda *
    parameter_estimation_hardware_B.Add1;

  /* Sum: '<S2>/Add' incorporates:
   *  Gain: '<Root>/Gain5'
   *  Gain: '<S2>/Gain5'
   *  Product: '<Root>/Product2'
   *  Product: '<Root>/Product3'
   *  Sum: '<Root>/Add4'
   *  Sum: '<Root>/Add5'
   */
  u0 = ((Gain3_tmp * parameter_estimation_hardware_B.Integrator1 +
         parameter_estimation_hardware_B.DiscreteFilter1 *
         parameter_estimation_hardware_B.Integrator) -
        parameter_estimation_hardware_P.k * rtb_Add2) *
    (parameter_estimation_hardware_P.R * parameter_estimation_hardware_P.rm /
     (parameter_estimation_hardware_P.rg * parameter_estimation_hardware_P.Kt))
    + parameter_estimation_hardware_B.Gain6;

  /* Saturate: '<S2>/Saturation1' */
  if (u0 > parameter_estimation_hardware_P.Vmax) {
    parameter_estimation_hardware_B.Saturation1 =
      parameter_estimation_hardware_P.Vmax;
  } else if (u0 < -parameter_estimation_hardware_P.Vmax) {
    parameter_estimation_hardware_B.Saturation1 =
      -parameter_estimation_hardware_P.Vmax;
  } else {
    parameter_estimation_hardware_B.Saturation1 = u0;
  }

  /* End of Saturate: '<S2>/Saturation1' */

  /* Gain: '<Root>/On or off' */
  parameter_estimation_hardware_B.Onoroff =
    parameter_estimation_hardware_P.Onoroff_Gain *
    parameter_estimation_hardware_B.Saturation1;
  if (rtmIsMajorTimeStep(parameter_estimation_hardwar_M)) {
    /* S-Function (hil_write_analog_block): '<Root>/HIL Write Analog' */

    /* S-Function Block: parameter_estimation_hardware/HIL Write Analog (hil_write_analog_block) */
    {
      t_error result;
      result = hil_write_analog
        (parameter_estimation_hardwar_DW.HILInitialize_Card,
         &parameter_estimation_hardware_P.HILWriteAnalog_channels, 1,
         &parameter_estimation_hardware_B.Onoroff);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(parameter_estimation_hardwar_M, _rt_error_message);
      }
    }
  }

  /* Product: '<Root>/Product' incorporates:
   *  Gain: '<Root>/Gain1'
   */
  parameter_estimation_hardware_B.Product =
    parameter_estimation_hardware_P.Gain1_Gain * rtb_Add2 *
    parameter_estimation_hardware_B.DiscreteFilter1;

  /* Product: '<Root>/Product1' incorporates:
   *  Gain: '<Root>/Gain3'
   */
  parameter_estimation_hardware_B.Product1 = Gain3_tmp *
    (parameter_estimation_hardware_P.Gain3_Gain * rtb_Add2);
}

/* Model update function */
void parameter_estimation_hardware_update(void)
{
  if (rtmIsMajorTimeStep(parameter_estimation_hardwar_M)) {
    /* Update for DiscreteFilter: '<S1>/Discrete Filter' */
    parameter_estimation_hardwar_DW.DiscreteFilter_states =
      parameter_estimation_hardwar_DW.DiscreteFilter_tmp;

    /* Update for DiscreteFilter: '<Root>/Discrete Filter1' */
    parameter_estimation_hardwar_DW.DiscreteFilter1_states[1] =
      parameter_estimation_hardwar_DW.DiscreteFilter1_states[0];
    parameter_estimation_hardwar_DW.DiscreteFilter1_states[0] =
      parameter_estimation_hardwar_DW.DiscreteFilter1_tmp;
  }

  if (rtmIsMajorTimeStep(parameter_estimation_hardwar_M)) {
    rt_ertODEUpdateContinuousStates(&parameter_estimation_hardwar_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++parameter_estimation_hardwar_M->Timing.clockTick0)) {
    ++parameter_estimation_hardwar_M->Timing.clockTickH0;
  }

  parameter_estimation_hardwar_M->Timing.t[0] = rtsiGetSolverStopTime
    (&parameter_estimation_hardwar_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++parameter_estimation_hardwar_M->Timing.clockTick1)) {
      ++parameter_estimation_hardwar_M->Timing.clockTickH1;
    }

    parameter_estimation_hardwar_M->Timing.t[1] =
      parameter_estimation_hardwar_M->Timing.clockTick1 *
      parameter_estimation_hardwar_M->Timing.stepSize1 +
      parameter_estimation_hardwar_M->Timing.clockTickH1 *
      parameter_estimation_hardwar_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void parameter_estimation_hardware_derivatives(void)
{
  XDot_parameter_estimation_har_T *_rtXdot;
  _rtXdot = ((XDot_parameter_estimation_har_T *)
             parameter_estimation_hardwar_M->derivs);

  /* Derivatives for Integrator: '<Root>/Integrator' */
  _rtXdot->Integrator_CSTATE = parameter_estimation_hardware_B.Product;

  /* Derivatives for Integrator: '<Root>/Integrator1' */
  _rtXdot->Integrator1_CSTATE = parameter_estimation_hardware_B.Product1;
}

/* Model initialize function */
void parameter_estimation_hardware_initialize(void)
{
  /* Start for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: parameter_estimation_hardware/HIL Initialize (hil_initialize_block) */
  {
    t_int result;
    t_boolean is_switching;
    result = hil_open("q2_usb", "0",
                      &parameter_estimation_hardwar_DW.HILInitialize_Card);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(parameter_estimation_hardwar_M, _rt_error_message);
      return;
    }

    is_switching = false;
    result = hil_set_card_specific_options
      (parameter_estimation_hardwar_DW.HILInitialize_Card,
       "d0=digital;d1=digital;led=auto;update_rate=normal;decimation=1", 63);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(parameter_estimation_hardwar_M, _rt_error_message);
      return;
    }

    result = hil_watchdog_clear
      (parameter_estimation_hardwar_DW.HILInitialize_Card);
    if (result < 0 && result != -QERR_HIL_WATCHDOG_CLEAR) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(parameter_estimation_hardwar_M, _rt_error_message);
      return;
    }

    if ((parameter_estimation_hardware_P.HILInitialize_AIPStart && !is_switching)
        || (parameter_estimation_hardware_P.HILInitialize_AIPEnter &&
            is_switching)) {
      parameter_estimation_hardwar_DW.HILInitialize_AIMinimums[0] =
        (parameter_estimation_hardware_P.HILInitialize_AILow);
      parameter_estimation_hardwar_DW.HILInitialize_AIMinimums[1] =
        (parameter_estimation_hardware_P.HILInitialize_AILow);
      parameter_estimation_hardwar_DW.HILInitialize_AIMaximums[0] =
        parameter_estimation_hardware_P.HILInitialize_AIHigh;
      parameter_estimation_hardwar_DW.HILInitialize_AIMaximums[1] =
        parameter_estimation_hardware_P.HILInitialize_AIHigh;
      result = hil_set_analog_input_ranges
        (parameter_estimation_hardwar_DW.HILInitialize_Card,
         parameter_estimation_hardware_P.HILInitialize_AIChannels, 2U,
         &parameter_estimation_hardwar_DW.HILInitialize_AIMinimums[0],
         &parameter_estimation_hardwar_DW.HILInitialize_AIMaximums[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(parameter_estimation_hardwar_M, _rt_error_message);
        return;
      }
    }

    if ((parameter_estimation_hardware_P.HILInitialize_AOPStart && !is_switching)
        || (parameter_estimation_hardware_P.HILInitialize_AOPEnter &&
            is_switching)) {
      parameter_estimation_hardwar_DW.HILInitialize_AOMinimums[0] =
        (parameter_estimation_hardware_P.HILInitialize_AOLow);
      parameter_estimation_hardwar_DW.HILInitialize_AOMinimums[1] =
        (parameter_estimation_hardware_P.HILInitialize_AOLow);
      parameter_estimation_hardwar_DW.HILInitialize_AOMaximums[0] =
        parameter_estimation_hardware_P.HILInitialize_AOHigh;
      parameter_estimation_hardwar_DW.HILInitialize_AOMaximums[1] =
        parameter_estimation_hardware_P.HILInitialize_AOHigh;
      result = hil_set_analog_output_ranges
        (parameter_estimation_hardwar_DW.HILInitialize_Card,
         parameter_estimation_hardware_P.HILInitialize_AOChannels, 2U,
         &parameter_estimation_hardwar_DW.HILInitialize_AOMinimums[0],
         &parameter_estimation_hardwar_DW.HILInitialize_AOMaximums[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(parameter_estimation_hardwar_M, _rt_error_message);
        return;
      }
    }

    if ((parameter_estimation_hardware_P.HILInitialize_AOStart && !is_switching)
        || (parameter_estimation_hardware_P.HILInitialize_AOEnter &&
            is_switching)) {
      parameter_estimation_hardwar_DW.HILInitialize_AOVoltages[0] =
        parameter_estimation_hardware_P.HILInitialize_AOInitial;
      parameter_estimation_hardwar_DW.HILInitialize_AOVoltages[1] =
        parameter_estimation_hardware_P.HILInitialize_AOInitial;
      result = hil_write_analog
        (parameter_estimation_hardwar_DW.HILInitialize_Card,
         parameter_estimation_hardware_P.HILInitialize_AOChannels, 2U,
         &parameter_estimation_hardwar_DW.HILInitialize_AOVoltages[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(parameter_estimation_hardwar_M, _rt_error_message);
        return;
      }
    }

    if (parameter_estimation_hardware_P.HILInitialize_AOReset) {
      parameter_estimation_hardwar_DW.HILInitialize_AOVoltages[0] =
        parameter_estimation_hardware_P.HILInitialize_AOWatchdog;
      parameter_estimation_hardwar_DW.HILInitialize_AOVoltages[1] =
        parameter_estimation_hardware_P.HILInitialize_AOWatchdog;
      result = hil_watchdog_set_analog_expiration_state
        (parameter_estimation_hardwar_DW.HILInitialize_Card,
         parameter_estimation_hardware_P.HILInitialize_AOChannels, 2U,
         &parameter_estimation_hardwar_DW.HILInitialize_AOVoltages[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(parameter_estimation_hardwar_M, _rt_error_message);
        return;
      }
    }

    if ((parameter_estimation_hardware_P.HILInitialize_EIPStart && !is_switching)
        || (parameter_estimation_hardware_P.HILInitialize_EIPEnter &&
            is_switching)) {
      parameter_estimation_hardwar_DW.HILInitialize_QuadratureModes[0] =
        parameter_estimation_hardware_P.HILInitialize_EIQuadrature;
      parameter_estimation_hardwar_DW.HILInitialize_QuadratureModes[1] =
        parameter_estimation_hardware_P.HILInitialize_EIQuadrature;
      result = hil_set_encoder_quadrature_mode
        (parameter_estimation_hardwar_DW.HILInitialize_Card,
         parameter_estimation_hardware_P.HILInitialize_EIChannels, 2U,
         (t_encoder_quadrature_mode *)
         &parameter_estimation_hardwar_DW.HILInitialize_QuadratureModes[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(parameter_estimation_hardwar_M, _rt_error_message);
        return;
      }
    }

    if ((parameter_estimation_hardware_P.HILInitialize_EIStart && !is_switching)
        || (parameter_estimation_hardware_P.HILInitialize_EIEnter &&
            is_switching)) {
      parameter_estimation_hardwar_DW.HILInitialize_InitialEICounts[0] =
        parameter_estimation_hardware_P.HILInitialize_EIInitial;
      parameter_estimation_hardwar_DW.HILInitialize_InitialEICounts[1] =
        parameter_estimation_hardware_P.HILInitialize_EIInitial;
      result = hil_set_encoder_counts
        (parameter_estimation_hardwar_DW.HILInitialize_Card,
         parameter_estimation_hardware_P.HILInitialize_EIChannels, 2U,
         &parameter_estimation_hardwar_DW.HILInitialize_InitialEICounts[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(parameter_estimation_hardwar_M, _rt_error_message);
        return;
      }
    }
  }

  /* Start for S-Function (hil_read_encoder_timebase_block): '<Root>/HIL Read Encoder Timebase1' */

  /* S-Function Block: parameter_estimation_hardware/HIL Read Encoder Timebase1 (hil_read_encoder_timebase_block) */
  {
    t_error result;
    result = hil_task_create_encoder_reader
      (parameter_estimation_hardwar_DW.HILInitialize_Card,
       parameter_estimation_hardware_P.HILReadEncoderTimebase1_samples,
       parameter_estimation_hardware_P.HILReadEncoderTimebase1_channel, 2,
       &parameter_estimation_hardwar_DW.HILReadEncoderTimebase1_Task);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(parameter_estimation_hardwar_M, _rt_error_message);
    }
  }

  /* InitializeConditions for DiscreteFilter: '<S1>/Discrete Filter' */
  parameter_estimation_hardwar_DW.DiscreteFilter_states =
    parameter_estimation_hardware_P.DiscreteFilter_InitialStates;

  /* InitializeConditions for DiscreteFilter: '<Root>/Discrete Filter1' */
  parameter_estimation_hardwar_DW.DiscreteFilter1_states[0] =
    parameter_estimation_hardware_P.DiscreteFilter1_InitialStates;
  parameter_estimation_hardwar_DW.DiscreteFilter1_states[1] =
    parameter_estimation_hardware_P.DiscreteFilter1_InitialStates;

  /* InitializeConditions for Integrator: '<Root>/Integrator' */
  parameter_estimation_hardware_X.Integrator_CSTATE =
    parameter_estimation_hardware_P.bhat0;

  /* InitializeConditions for Integrator: '<Root>/Integrator1' */
  parameter_estimation_hardware_X.Integrator1_CSTATE =
    parameter_estimation_hardware_P.mhat0;
}

/* Model terminate function */
void parameter_estimation_hardware_terminate(void)
{
  /* Terminate for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: parameter_estimation_hardware/HIL Initialize (hil_initialize_block) */
  {
    t_boolean is_switching;
    t_int result;
    t_uint32 num_final_analog_outputs = 0;
    hil_task_stop_all(parameter_estimation_hardwar_DW.HILInitialize_Card);
    hil_monitor_stop_all(parameter_estimation_hardwar_DW.HILInitialize_Card);
    is_switching = false;
    if ((parameter_estimation_hardware_P.HILInitialize_AOTerminate &&
         !is_switching) || (parameter_estimation_hardware_P.HILInitialize_AOExit
         && is_switching)) {
      parameter_estimation_hardwar_DW.HILInitialize_AOVoltages[0] =
        parameter_estimation_hardware_P.HILInitialize_AOFinal;
      parameter_estimation_hardwar_DW.HILInitialize_AOVoltages[1] =
        parameter_estimation_hardware_P.HILInitialize_AOFinal;
      num_final_analog_outputs = 2U;
    }

    if (num_final_analog_outputs > 0) {
      result = hil_write_analog
        (parameter_estimation_hardwar_DW.HILInitialize_Card,
         parameter_estimation_hardware_P.HILInitialize_AOChannels,
         num_final_analog_outputs,
         &parameter_estimation_hardwar_DW.HILInitialize_AOVoltages[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(parameter_estimation_hardwar_M, _rt_error_message);
      }
    }

    hil_task_delete_all(parameter_estimation_hardwar_DW.HILInitialize_Card);
    hil_monitor_delete_all(parameter_estimation_hardwar_DW.HILInitialize_Card);
    hil_close(parameter_estimation_hardwar_DW.HILInitialize_Card);
    parameter_estimation_hardwar_DW.HILInitialize_Card = NULL;
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  parameter_estimation_hardware_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  parameter_estimation_hardware_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  parameter_estimation_hardware_initialize();
}

void MdlTerminate(void)
{
  parameter_estimation_hardware_terminate();
}

/* Registration function */
RT_MODEL_parameter_estimation_T *parameter_estimation_hardware(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)parameter_estimation_hardwar_M, 0,
                sizeof(RT_MODEL_parameter_estimation_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&parameter_estimation_hardwar_M->solverInfo,
                          &parameter_estimation_hardwar_M->Timing.simTimeStep);
    rtsiSetTPtr(&parameter_estimation_hardwar_M->solverInfo, &rtmGetTPtr
                (parameter_estimation_hardwar_M));
    rtsiSetStepSizePtr(&parameter_estimation_hardwar_M->solverInfo,
                       &parameter_estimation_hardwar_M->Timing.stepSize0);
    rtsiSetdXPtr(&parameter_estimation_hardwar_M->solverInfo,
                 &parameter_estimation_hardwar_M->derivs);
    rtsiSetContStatesPtr(&parameter_estimation_hardwar_M->solverInfo, (real_T **)
                         &parameter_estimation_hardwar_M->contStates);
    rtsiSetNumContStatesPtr(&parameter_estimation_hardwar_M->solverInfo,
      &parameter_estimation_hardwar_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&parameter_estimation_hardwar_M->solverInfo,
      &parameter_estimation_hardwar_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr
      (&parameter_estimation_hardwar_M->solverInfo,
       &parameter_estimation_hardwar_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr
      (&parameter_estimation_hardwar_M->solverInfo,
       &parameter_estimation_hardwar_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&parameter_estimation_hardwar_M->solverInfo,
                          (&rtmGetErrorStatus(parameter_estimation_hardwar_M)));
    rtsiSetRTModelPtr(&parameter_estimation_hardwar_M->solverInfo,
                      parameter_estimation_hardwar_M);
  }

  rtsiSetSimTimeStep(&parameter_estimation_hardwar_M->solverInfo,
                     MAJOR_TIME_STEP);
  parameter_estimation_hardwar_M->intgData.f[0] =
    parameter_estimation_hardwar_M->odeF[0];
  parameter_estimation_hardwar_M->contStates = ((real_T *)
    &parameter_estimation_hardware_X);
  rtsiSetSolverData(&parameter_estimation_hardwar_M->solverInfo, (void *)
                    &parameter_estimation_hardwar_M->intgData);
  rtsiSetSolverName(&parameter_estimation_hardwar_M->solverInfo,"ode1");

  /* Initialize timing info */
  {
    int_T *mdlTsMap =
      parameter_estimation_hardwar_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    parameter_estimation_hardwar_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    parameter_estimation_hardwar_M->Timing.sampleTimes =
      (&parameter_estimation_hardwar_M->Timing.sampleTimesArray[0]);
    parameter_estimation_hardwar_M->Timing.offsetTimes =
      (&parameter_estimation_hardwar_M->Timing.offsetTimesArray[0]);

    /* task periods */
    parameter_estimation_hardwar_M->Timing.sampleTimes[0] = (0.0);
    parameter_estimation_hardwar_M->Timing.sampleTimes[1] = (0.001);

    /* task offsets */
    parameter_estimation_hardwar_M->Timing.offsetTimes[0] = (0.0);
    parameter_estimation_hardwar_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(parameter_estimation_hardwar_M,
             &parameter_estimation_hardwar_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = parameter_estimation_hardwar_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    parameter_estimation_hardwar_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(parameter_estimation_hardwar_M, -1);
  parameter_estimation_hardwar_M->Timing.stepSize0 = 0.001;
  parameter_estimation_hardwar_M->Timing.stepSize1 = 0.001;

  /* External mode info */
  parameter_estimation_hardwar_M->Sizes.checksums[0] = (2267798225U);
  parameter_estimation_hardwar_M->Sizes.checksums[1] = (1350053079U);
  parameter_estimation_hardwar_M->Sizes.checksums[2] = (1186518877U);
  parameter_estimation_hardwar_M->Sizes.checksums[3] = (3431875335U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    parameter_estimation_hardwar_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(parameter_estimation_hardwar_M->extModeInfo,
      &parameter_estimation_hardwar_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(parameter_estimation_hardwar_M->extModeInfo,
                        parameter_estimation_hardwar_M->Sizes.checksums);
    rteiSetTPtr(parameter_estimation_hardwar_M->extModeInfo, rtmGetTPtr
                (parameter_estimation_hardwar_M));
  }

  parameter_estimation_hardwar_M->solverInfoPtr =
    (&parameter_estimation_hardwar_M->solverInfo);
  parameter_estimation_hardwar_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&parameter_estimation_hardwar_M->solverInfo, 0.001);
  rtsiSetSolverMode(&parameter_estimation_hardwar_M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  parameter_estimation_hardwar_M->blockIO = ((void *)
    &parameter_estimation_hardware_B);
  (void) memset(((void *) &parameter_estimation_hardware_B), 0,
                sizeof(B_parameter_estimation_hardwa_T));

  /* parameters */
  parameter_estimation_hardwar_M->defaultParam = ((real_T *)
    &parameter_estimation_hardware_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &parameter_estimation_hardware_X;
    parameter_estimation_hardwar_M->contStates = (x);
    (void) memset((void *)&parameter_estimation_hardware_X, 0,
                  sizeof(X_parameter_estimation_hardwa_T));
  }

  /* states (dwork) */
  parameter_estimation_hardwar_M->dwork = ((void *)
    &parameter_estimation_hardwar_DW);
  (void) memset((void *)&parameter_estimation_hardwar_DW, 0,
                sizeof(DW_parameter_estimation_hardw_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    parameter_estimation_hardwar_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 16;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  parameter_estimation_hardwar_M->Sizes.numContStates = (2);/* Number of continuous states */
  parameter_estimation_hardwar_M->Sizes.numPeriodicContStates = (0);
                                      /* Number of periodic continuous states */
  parameter_estimation_hardwar_M->Sizes.numY = (0);/* Number of model outputs */
  parameter_estimation_hardwar_M->Sizes.numU = (0);/* Number of model inputs */
  parameter_estimation_hardwar_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  parameter_estimation_hardwar_M->Sizes.numSampTimes = (2);/* Number of sample times */
  parameter_estimation_hardwar_M->Sizes.numBlocks = (41);/* Number of blocks */
  parameter_estimation_hardwar_M->Sizes.numBlockIO = (12);/* Number of block outputs */
  parameter_estimation_hardwar_M->Sizes.numBlockPrms = (101);/* Sum of parameter "widths" */
  return parameter_estimation_hardwar_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
