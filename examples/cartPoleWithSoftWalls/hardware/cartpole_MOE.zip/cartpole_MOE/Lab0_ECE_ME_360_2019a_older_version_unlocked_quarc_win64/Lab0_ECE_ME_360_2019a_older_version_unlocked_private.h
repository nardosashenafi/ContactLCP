/*
 * Lab0_ECE_ME_360_2019a_older_version_unlocked_private.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Lab0_ECE_ME_360_2019a_older_version_unlocked".
 *
 * Model version              : 1.9
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C source code generated on : Tue Jan 31 13:44:58 2023
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Lab0_ECE_ME_360_2019a_older_version_unlocked_private_h_
#define RTW_HEADER_Lab0_ECE_ME_360_2019a_older_version_unlocked_private_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"
#include "Lab0_ECE_ME_360_2019a_older_version_unlocked.h"

/* A global buffer for storing error messages (defined in quanser_common library) */
EXTERN char _rt_error_message[512];
int_T rt_WriteMat4FileHeader(FILE *fp,
  int32_T m,
  int32_T n,
  const char_T *name);
extern void Lab0_ECE_ME_360__MATLABFunction(real_T rtu_x, real_T rtu_x_l, real_T
  rtu_x_c, real_T rtu_x_a, const real_T rtu_W1[40], const real_T rtu_W2[32],
  const real_T rtu_W3[4], const real_T rtu_b1[8], const real_T rtu_b2[4], real_T
  rtu_b3, B_MATLABFunction_Lab0_ECE_ME__T *localB);

#endif  /* RTW_HEADER_Lab0_ECE_ME_360_2019a_older_version_unlocked_private_h_ */
