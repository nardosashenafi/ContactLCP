/*
 * Lab0_ECE_ME_360_2019a_older_version_unlocked.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Lab0_ECE_ME_360_2019a_older_version_unlocked".
 *
 * Model version              : 1.9
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C source code generated on : Tue Jan 31 13:44:58 2023
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Lab0_ECE_ME_360_2019a_older_version_unlocked.h"
#include "Lab0_ECE_ME_360_2019a_older_version_unlocked_private.h"
#include "Lab0_ECE_ME_360_2019a_older_version_unlocked_dt.h"

/* Block signals (default storage) */
B_Lab0_ECE_ME_360_2019a_older_T Lab0_ECE_ME_360_2019a_older_v_B;

/* Block states (default storage) */
DW_Lab0_ECE_ME_360_2019a_olde_T Lab0_ECE_ME_360_2019a_older__DW;

/* Real-time model */
RT_MODEL_Lab0_ECE_ME_360_2019_T Lab0_ECE_ME_360_2019a_older__M_;
RT_MODEL_Lab0_ECE_ME_360_2019_T *const Lab0_ECE_ME_360_2019a_older__M =
  &Lab0_ECE_ME_360_2019a_older__M_;

/*
 * Writes out MAT-file header.  Returns success or failure.
 * Returns:
 *      0 - success
 *      1 - failure
 */
int_T rt_WriteMat4FileHeader(FILE *fp, int32_T m, int32_T n, const char *name)
{
  typedef enum { ELITTLE_ENDIAN, EBIG_ENDIAN } ByteOrder;

  int16_T one = 1;
  ByteOrder byteOrder = (*((int8_T *)&one)==1) ? ELITTLE_ENDIAN : EBIG_ENDIAN;
  int32_T type = (byteOrder == ELITTLE_ENDIAN) ? 0: 1000;
  int32_T imagf = 0;
  int32_T name_len = (int32_T)strlen(name) + 1;
  if ((fwrite(&type, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&m, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&n, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&imagf, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&name_len, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(name, sizeof(char), name_len, fp) == 0)) {
    return(1);
  } else {
    return(0);
  }
}                                      /* end rt_WriteMat4FileHeader */

/*
 * Output and update for atomic system:
 *    '<S7>/MATLAB Function'
 *    '<S8>/MATLAB Function'
 *    '<S9>/MATLAB Function'
 */
void Lab0_ECE_ME_360__MATLABFunction(real_T rtu_x, real_T rtu_x_l, real_T
  rtu_x_c, real_T rtu_x_a, const real_T rtu_W1[40], const real_T rtu_W2[32],
  const real_T rtu_W3[4], const real_T rtu_b1[8], const real_T rtu_b2[4], real_T
  rtu_b3, B_MATLABFunction_Lab0_ECE_ME__T *localB)
{
  real_T z1[8];
  real_T rtb_TmpSignalConversionAtSFun_0[5];
  int32_T i;
  int32_T i_0;
  real_T x;
  real_T rtb_TmpSignalConversionAtSFun_e;

  /* SignalConversion: '<S10>/TmpSignal ConversionAt SFunction Inport1' */
  /* MATLAB Function 'MOE/Switch Case Action Subsystem/MATLAB Function': '<S10>:1' */
  /* '<S10>:1:2' */
  /* '<S10>:1:3' */
  rtb_TmpSignalConversionAtSFun_0[0] = rtu_x;
  rtb_TmpSignalConversionAtSFun_0[1] = cos(rtu_x_l);
  rtb_TmpSignalConversionAtSFun_0[2] = sin(rtu_x_l);
  rtb_TmpSignalConversionAtSFun_0[3] = rtu_x_c;
  rtb_TmpSignalConversionAtSFun_0[4] = rtu_x_a;
  for (i = 0; i < 8; i++) {
    rtb_TmpSignalConversionAtSFun_e = 0.0;
    for (i_0 = 0; i_0 < 5; i_0++) {
      rtb_TmpSignalConversionAtSFun_e += rtu_W1[(i_0 << 3) + i] *
        rtb_TmpSignalConversionAtSFun_0[i_0];
    }

    x = rtb_TmpSignalConversionAtSFun_e + rtu_b1[i];
    if (x > 0.0) {
      z1[i] = x;
    } else {
      z1[i] = exp(x) - 1.0;
    }
  }

  /* '<S10>:1:4' */
  /* '<S10>:1:5' */
  /* '<S10>:1:6' */
  x = 0.0;
  for (i = 0; i < 4; i++) {
    rtb_TmpSignalConversionAtSFun_e = 0.0;
    for (i_0 = 0; i_0 < 8; i_0++) {
      rtb_TmpSignalConversionAtSFun_e += rtu_W2[(i_0 << 2) + i] * z1[i_0];
    }

    rtb_TmpSignalConversionAtSFun_e += rtu_b2[i];
    if (!(rtb_TmpSignalConversionAtSFun_e > 0.0)) {
      rtb_TmpSignalConversionAtSFun_e = exp(rtb_TmpSignalConversionAtSFun_e) -
        1.0;
    }

    x += rtu_W3[i] * rtb_TmpSignalConversionAtSFun_e;
  }

  localB->y = x + rtu_b3;
}

/* Model output function */
void Lab0_ECE_ME_360_2019a_older_version_unlocked_output(void)
{
  /* local block i/o variables */
  real_T rtb_HILReadEncoderTimebase_o2;
  real_T rtb_TmpSignalConversionAtToFile[6];
  real_T rtb_upiNenc;
  real_T rtb_Onoroff;
  real_T z1[5];
  real_T z2[4];
  real_T z3[3];
  int32_T maxindex;
  real_T rtb_Sum;
  real_T rtb_TmpSignalConversionAtSFun_1[5];
  int32_T i;
  real_T x;

  /* Reset subsysRan breadcrumbs */
  srClearBC(Lab0_ECE_ME_360_2019a_older__DW.SwitchCaseActionSubsystem_Subsy);

  /* Reset subsysRan breadcrumbs */
  srClearBC(Lab0_ECE_ME_360_2019a_older__DW.SwitchCaseActionSubsystem1_Subs);

  /* Reset subsysRan breadcrumbs */
  srClearBC(Lab0_ECE_ME_360_2019a_older__DW.SwitchCaseActionSubsystem2_Subs);

  /* S-Function (hil_read_encoder_timebase_block): '<Root>/HIL Read Encoder Timebase' */

  /* S-Function Block: Lab0_ECE_ME_360_2019a_older_version_unlocked/HIL Read Encoder Timebase (hil_read_encoder_timebase_block) */
  {
    t_error result;
    result = hil_task_read_encoder
      (Lab0_ECE_ME_360_2019a_older__DW.HILReadEncoderTimebase_Task, 1,
       &Lab0_ECE_ME_360_2019a_older__DW.HILReadEncoderTimebase_Buffer[0]);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M, _rt_error_message);
    } else {
      rtb_upiNenc =
        Lab0_ECE_ME_360_2019a_older__DW.HILReadEncoderTimebase_Buffer[0];
      rtb_HILReadEncoderTimebase_o2 =
        Lab0_ECE_ME_360_2019a_older__DW.HILReadEncoderTimebase_Buffer[1];
    }
  }

  /* Gain: '<Root>/Kenc' */
  Lab0_ECE_ME_360_2019a_older_v_B.Kenc = Lab0_ECE_ME_360_2019a_older_v_P.r_enc *
    2.0 * 3.1415926535897931 / Lab0_ECE_ME_360_2019a_older_v_P.Nenc *
    rtb_upiNenc;

  /* Gain: '<Root>/2pi//Nenc' */
  rtb_upiNenc = 6.2831853071795862 / Lab0_ECE_ME_360_2019a_older_v_P.Nenc *
    rtb_HILReadEncoderTimebase_o2;

  /* Sum: '<Root>/Sum' incorporates:
   *  Constant: '<Root>/Constant'
   */
  rtb_Sum = rtb_upiNenc + Lab0_ECE_ME_360_2019a_older_v_P.Constant_Value;

  /* DiscreteFilter: '<S2>/Discrete Filter' */
  Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_tmp =
    (Lab0_ECE_ME_360_2019a_older_v_B.Kenc -
     Lab0_ECE_ME_360_2019a_older_v_P.DiscreteFilter_DenCoef[1] *
     Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_states) /
    Lab0_ECE_ME_360_2019a_older_v_P.DiscreteFilter_DenCoef[0];
  rtb_Onoroff = Lab0_ECE_ME_360_2019a_older_v_P.DiscreteFilter_NumCoef[0] *
    Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_tmp +
    Lab0_ECE_ME_360_2019a_older_v_P.DiscreteFilter_NumCoef[1] *
    Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_states;

  /* DiscreteFilter: '<Root>/Discrete Filter1' incorporates:
   *  Gain: '<S2>/Gain3'
   */
  Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter1_tmp = ((1.0 /
    Lab0_ECE_ME_360_2019a_older_v_P.T * rtb_Onoroff -
    Lab0_ECE_ME_360_2019a_older_v_P.af[1] *
    Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter1_states[0]) -
    Lab0_ECE_ME_360_2019a_older_v_P.af[2] *
    Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter1_states[1]) /
    Lab0_ECE_ME_360_2019a_older_v_P.af[0];
  Lab0_ECE_ME_360_2019a_older_v_B.DiscreteFilter1 =
    (Lab0_ECE_ME_360_2019a_older_v_P.bf[0] *
     Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter1_tmp +
     Lab0_ECE_ME_360_2019a_older_v_P.bf[1] *
     Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter1_states[0]) +
    Lab0_ECE_ME_360_2019a_older_v_P.bf[2] *
    Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter1_states[1];

  /* Sum: '<Root>/Sum1' incorporates:
   *  Constant: '<Root>/Constant1'
   */
  Lab0_ECE_ME_360_2019a_older_v_B.Sum1 = rtb_upiNenc +
    Lab0_ECE_ME_360_2019a_older_v_P.Constant1_Value;

  /* DiscreteFilter: '<S1>/Discrete Filter' */
  Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_tmp_c =
    (Lab0_ECE_ME_360_2019a_older_v_B.Sum1 -
     Lab0_ECE_ME_360_2019a_older_v_P.DiscreteFilter_DenCoef_f[1] *
     Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_states_p) /
    Lab0_ECE_ME_360_2019a_older_v_P.DiscreteFilter_DenCoef_f[0];
  rtb_Onoroff = Lab0_ECE_ME_360_2019a_older_v_P.DiscreteFilter_NumCoef_b[0] *
    Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_tmp_c +
    Lab0_ECE_ME_360_2019a_older_v_P.DiscreteFilter_NumCoef_b[1] *
    Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_states_p;

  /* DiscreteFilter: '<Root>/Discrete Filter' incorporates:
   *  Gain: '<S1>/Gain3'
   */
  Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_tmp_a = ((1.0 /
    Lab0_ECE_ME_360_2019a_older_v_P.T * rtb_Onoroff -
    Lab0_ECE_ME_360_2019a_older_v_P.af[1] *
    Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_states_a[0]) -
    Lab0_ECE_ME_360_2019a_older_v_P.af[2] *
    Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_states_a[1]) /
    Lab0_ECE_ME_360_2019a_older_v_P.af[0];
  Lab0_ECE_ME_360_2019a_older_v_B.DiscreteFilter =
    (Lab0_ECE_ME_360_2019a_older_v_P.bf[0] *
     Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_tmp_a +
     Lab0_ECE_ME_360_2019a_older_v_P.bf[1] *
     Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_states_a[0]) +
    Lab0_ECE_ME_360_2019a_older_v_P.bf[2] *
    Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_states_a[1];

  /* MATLAB Function: '<S4>/Gating network' incorporates:
   *  Constant: '<S4>/Constant2'
   *  Constant: '<S4>/Constant3'
   *  Constant: '<S4>/Constant4'
   *  Constant: '<S4>/Constant5'
   *  Constant: '<S4>/Constant6'
   *  Constant: '<S4>/Constant7'
   *  SignalConversion: '<S6>/TmpSignal ConversionAt SFunction Inport1'
   */
  /* MATLAB Function 'MOE/Gating network': '<S6>:1' */
  /* '<S6>:1:3' */
  /* '<S6>:1:4' */
  rtb_TmpSignalConversionAtSFun_1[0] = Lab0_ECE_ME_360_2019a_older_v_B.Kenc;
  rtb_TmpSignalConversionAtSFun_1[1] = cos(rtb_Sum);
  rtb_TmpSignalConversionAtSFun_1[2] = sin(rtb_Sum);
  rtb_TmpSignalConversionAtSFun_1[3] =
    Lab0_ECE_ME_360_2019a_older_v_B.DiscreteFilter1;
  rtb_TmpSignalConversionAtSFun_1[4] =
    Lab0_ECE_ME_360_2019a_older_v_B.DiscreteFilter;
  for (maxindex = 0; maxindex < 5; maxindex++) {
    x = 0.0;
    for (i = 0; i < 5; i++) {
      x += Lab0_ECE_ME_360_2019a_older_v_P.binW1[5 * i + maxindex] *
        rtb_TmpSignalConversionAtSFun_1[i];
    }

    x += Lab0_ECE_ME_360_2019a_older_v_P.binb1[maxindex];
    if (x > 0.0) {
      z1[maxindex] = x;
    } else {
      z1[maxindex] = exp(x) - 1.0;
    }
  }

  /* '<S6>:1:5' */
  for (maxindex = 0; maxindex < 4; maxindex++) {
    x = 0.0;
    for (i = 0; i < 5; i++) {
      x += Lab0_ECE_ME_360_2019a_older_v_P.binW2[(i << 2) + maxindex] * z1[i];
    }

    x += Lab0_ECE_ME_360_2019a_older_v_P.binb2[maxindex];
    if (x > 0.0) {
      z2[maxindex] = x;
    } else {
      z2[maxindex] = exp(x) - 1.0;
    }
  }

  /* '<S6>:1:6' */
  for (i = 0; i < 3; i++) {
    z3[i] = (((Lab0_ECE_ME_360_2019a_older_v_P.binW3[i + 3] * z2[1] +
               Lab0_ECE_ME_360_2019a_older_v_P.binW3[i] * z2[0]) +
              Lab0_ECE_ME_360_2019a_older_v_P.binW3[i + 6] * z2[2]) +
             Lab0_ECE_ME_360_2019a_older_v_P.binW3[i + 9] * z2[3]) +
      Lab0_ECE_ME_360_2019a_older_v_P.binb3[i];
  }

  /* '<S6>:1:7' */
  /* '<S6>:1:12' */
  memset(&Lab0_ECE_ME_360_2019a_older_v_B.pk[0], 0, 9U * sizeof(real_T));

  /* '<S6>:1:13' */
  for (maxindex = 0; maxindex < 3; maxindex++) {
    /* '<S6>:1:13' */
    /* '<S6>:1:14' */
    Lab0_ECE_ME_360_2019a_older_v_B.pk[maxindex] = exp(z3[maxindex]) / ((exp(z3
      [0]) + exp(z3[1])) + exp(z3[2]));
  }

  /* End of MATLAB Function: '<S4>/Gating network' */

  /* MATLAB Function: '<S4>/Argmax' */
  /* MATLAB Function 'MOE/Argmax': '<S5>:1' */
  /* '<S5>:1:2' */
  maxindex = 0;

  /* '<S5>:1:3' */
  if (Lab0_ECE_ME_360_2019a_older_v_B.pk[1] >
      Lab0_ECE_ME_360_2019a_older_v_B.pk[0]) {
    /* '<S5>:1:4' */
    /* '<S5>:1:5' */
    maxindex = 1;
  }

  /* '<S5>:1:3' */
  if (Lab0_ECE_ME_360_2019a_older_v_B.pk[2] >
      Lab0_ECE_ME_360_2019a_older_v_B.pk[maxindex]) {
    /* '<S5>:1:4' */
    /* '<S5>:1:5' */
    maxindex = 2;
  }

  /* '<S5>:1:8' */
  Lab0_ECE_ME_360_2019a_older_v_B.y = (real_T)maxindex + 1.0;

  /* End of MATLAB Function: '<S4>/Argmax' */

  /* SwitchCase: '<S4>/Select controller' */
  if (Lab0_ECE_ME_360_2019a_older_v_B.y < 0.0) {
    x = ceil(Lab0_ECE_ME_360_2019a_older_v_B.y);
  } else {
    x = floor(Lab0_ECE_ME_360_2019a_older_v_B.y);
  }

  if (rtIsNaN(x) || rtIsInf(x)) {
    x = 0.0;
  } else {
    x = fmod(x, 4.294967296E+9);
  }

  switch (x < 0.0 ? -(int32_T)(uint32_T)-x : (int32_T)(uint32_T)x) {
   case 1:
    /* Outputs for IfAction SubSystem: '<S4>/Switch Case Action Subsystem' incorporates:
     *  ActionPort: '<S7>/Action Port'
     */
    /* MATLAB Function: '<S7>/MATLAB Function' incorporates:
     *  Constant: '<S7>/Constant2'
     *  Constant: '<S7>/Constant3'
     *  Constant: '<S7>/Constant4'
     *  Constant: '<S7>/Constant5'
     *  Constant: '<S7>/Constant6'
     *  Constant: '<S7>/Constant7'
     */
    Lab0_ECE_ME_360__MATLABFunction(Lab0_ECE_ME_360_2019a_older_v_B.Kenc,
      rtb_Sum, Lab0_ECE_ME_360_2019a_older_v_B.DiscreteFilter1,
      Lab0_ECE_ME_360_2019a_older_v_B.DiscreteFilter,
      Lab0_ECE_ME_360_2019a_older_v_P.control1W1,
      Lab0_ECE_ME_360_2019a_older_v_P.control1W2,
      Lab0_ECE_ME_360_2019a_older_v_P.control1W3,
      Lab0_ECE_ME_360_2019a_older_v_P.control1b1,
      Lab0_ECE_ME_360_2019a_older_v_P.control1b2,
      Lab0_ECE_ME_360_2019a_older_v_P.control1b3,
      &Lab0_ECE_ME_360_2019a_older_v_B.sf_MATLABFunction);

    /* SignalConversion: '<S7>/OutportBufferForu' */
    Lab0_ECE_ME_360_2019a_older_v_B.Merge =
      Lab0_ECE_ME_360_2019a_older_v_B.sf_MATLABFunction.y;

    /* End of Outputs for SubSystem: '<S4>/Switch Case Action Subsystem' */

    /* Update for IfAction SubSystem: '<S4>/Switch Case Action Subsystem' incorporates:
     *  ActionPort: '<S7>/Action Port'
     */
    /* Update for SwitchCase: '<S4>/Select controller' */
    srUpdateBC(Lab0_ECE_ME_360_2019a_older__DW.SwitchCaseActionSubsystem_Subsy);

    /* End of Update for SubSystem: '<S4>/Switch Case Action Subsystem' */
    break;

   case 2:
    /* Outputs for IfAction SubSystem: '<S4>/Switch Case Action Subsystem1' incorporates:
     *  ActionPort: '<S8>/Action Port'
     */
    /* MATLAB Function: '<S8>/MATLAB Function' incorporates:
     *  Constant: '<S8>/Constant2'
     *  Constant: '<S8>/Constant3'
     *  Constant: '<S8>/Constant4'
     *  Constant: '<S8>/Constant5'
     *  Constant: '<S8>/Constant6'
     *  Constant: '<S8>/Constant7'
     */
    Lab0_ECE_ME_360__MATLABFunction(Lab0_ECE_ME_360_2019a_older_v_B.Kenc,
      rtb_Sum, Lab0_ECE_ME_360_2019a_older_v_B.DiscreteFilter1,
      Lab0_ECE_ME_360_2019a_older_v_B.DiscreteFilter,
      Lab0_ECE_ME_360_2019a_older_v_P.control2W1,
      Lab0_ECE_ME_360_2019a_older_v_P.control2W2,
      Lab0_ECE_ME_360_2019a_older_v_P.control2W3,
      Lab0_ECE_ME_360_2019a_older_v_P.control2b1,
      Lab0_ECE_ME_360_2019a_older_v_P.control2b2,
      Lab0_ECE_ME_360_2019a_older_v_P.control2b3,
      &Lab0_ECE_ME_360_2019a_older_v_B.sf_MATLABFunction_i);

    /* SignalConversion: '<S8>/OutportBufferForu' */
    Lab0_ECE_ME_360_2019a_older_v_B.Merge =
      Lab0_ECE_ME_360_2019a_older_v_B.sf_MATLABFunction_i.y;

    /* End of Outputs for SubSystem: '<S4>/Switch Case Action Subsystem1' */

    /* Update for IfAction SubSystem: '<S4>/Switch Case Action Subsystem1' incorporates:
     *  ActionPort: '<S8>/Action Port'
     */
    /* Update for SwitchCase: '<S4>/Select controller' */
    srUpdateBC(Lab0_ECE_ME_360_2019a_older__DW.SwitchCaseActionSubsystem1_Subs);

    /* End of Update for SubSystem: '<S4>/Switch Case Action Subsystem1' */
    break;

   case 3:
    /* Outputs for IfAction SubSystem: '<S4>/Switch Case Action Subsystem2' incorporates:
     *  ActionPort: '<S9>/Action Port'
     */
    /* MATLAB Function: '<S9>/MATLAB Function' incorporates:
     *  Constant: '<S9>/Constant2'
     *  Constant: '<S9>/Constant3'
     *  Constant: '<S9>/Constant4'
     *  Constant: '<S9>/Constant5'
     *  Constant: '<S9>/Constant6'
     *  Constant: '<S9>/Constant7'
     */
    Lab0_ECE_ME_360__MATLABFunction(Lab0_ECE_ME_360_2019a_older_v_B.Kenc,
      rtb_Sum, Lab0_ECE_ME_360_2019a_older_v_B.DiscreteFilter1,
      Lab0_ECE_ME_360_2019a_older_v_B.DiscreteFilter,
      Lab0_ECE_ME_360_2019a_older_v_P.control3W1,
      Lab0_ECE_ME_360_2019a_older_v_P.control3W2,
      Lab0_ECE_ME_360_2019a_older_v_P.control3W3,
      Lab0_ECE_ME_360_2019a_older_v_P.control3b1,
      Lab0_ECE_ME_360_2019a_older_v_P.control3b2,
      Lab0_ECE_ME_360_2019a_older_v_P.control3b3,
      &Lab0_ECE_ME_360_2019a_older_v_B.sf_MATLABFunction_d);

    /* SignalConversion: '<S9>/OutportBufferForu' */
    Lab0_ECE_ME_360_2019a_older_v_B.Merge =
      Lab0_ECE_ME_360_2019a_older_v_B.sf_MATLABFunction_d.y;

    /* End of Outputs for SubSystem: '<S4>/Switch Case Action Subsystem2' */

    /* Update for IfAction SubSystem: '<S4>/Switch Case Action Subsystem2' incorporates:
     *  ActionPort: '<S9>/Action Port'
     */
    /* Update for SwitchCase: '<S4>/Select controller' */
    srUpdateBC(Lab0_ECE_ME_360_2019a_older__DW.SwitchCaseActionSubsystem2_Subs);

    /* End of Update for SubSystem: '<S4>/Switch Case Action Subsystem2' */
    break;
  }

  /* End of SwitchCase: '<S4>/Select controller' */
  /* Gain: '<S3>/Gain5' incorporates:
   *  Gain: '<S3>/Gain6'
   */
  rtb_Sum = Lab0_ECE_ME_360_2019a_older_v_P.rg *
    Lab0_ECE_ME_360_2019a_older_v_P.Kt;

  /* Sum: '<S3>/Add' incorporates:
   *  Gain: '<Root>/On or off1'
   *  Gain: '<S3>/Gain5'
   *  Gain: '<S3>/Gain6'
   *  Sum: '<Root>/Sum2'
   */
  rtb_Onoroff = Lab0_ECE_ME_360_2019a_older_v_P.R *
    Lab0_ECE_ME_360_2019a_older_v_P.rm / rtb_Sum *
    (Lab0_ECE_ME_360_2019a_older_v_P.Onoroff1_Gain *
     Lab0_ECE_ME_360_2019a_older_v_B.DiscreteFilter1 +
     Lab0_ECE_ME_360_2019a_older_v_B.Merge) + rtb_Sum /
    Lab0_ECE_ME_360_2019a_older_v_P.rm *
    Lab0_ECE_ME_360_2019a_older_v_B.DiscreteFilter1;

  /* Saturate: '<S3>/Saturation1' */
  if (rtb_Onoroff > Lab0_ECE_ME_360_2019a_older_v_P.Vmax) {
    Lab0_ECE_ME_360_2019a_older_v_B.Saturation1 =
      Lab0_ECE_ME_360_2019a_older_v_P.Vmax;
  } else if (rtb_Onoroff < -Lab0_ECE_ME_360_2019a_older_v_P.Vmax) {
    Lab0_ECE_ME_360_2019a_older_v_B.Saturation1 =
      -Lab0_ECE_ME_360_2019a_older_v_P.Vmax;
  } else {
    Lab0_ECE_ME_360_2019a_older_v_B.Saturation1 = rtb_Onoroff;
  }

  /* End of Saturate: '<S3>/Saturation1' */

  /* Gain: '<Root>/On or off' */
  rtb_Onoroff = Lab0_ECE_ME_360_2019a_older_v_P.Onoroff_Gain *
    Lab0_ECE_ME_360_2019a_older_v_B.Saturation1;

  /* S-Function (hil_write_analog_block): '<Root>/HIL Write Analog' */

  /* S-Function Block: Lab0_ECE_ME_360_2019a_older_version_unlocked/HIL Write Analog (hil_write_analog_block) */
  {
    t_error result;
    result = hil_write_analog(Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card,
      &Lab0_ECE_ME_360_2019a_older_v_P.HILWriteAnalog_channels, 1, &rtb_Onoroff);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M, _rt_error_message);
    }
  }

  /* SignalConversion: '<Root>/TmpSignal ConversionAtTo FileInport1' */
  rtb_TmpSignalConversionAtToFile[0] =
    Lab0_ECE_ME_360_2019a_older_v_B.Saturation1;
  rtb_TmpSignalConversionAtToFile[1] = Lab0_ECE_ME_360_2019a_older_v_B.Kenc;
  rtb_TmpSignalConversionAtToFile[2] = rtb_upiNenc;
  rtb_TmpSignalConversionAtToFile[3] =
    Lab0_ECE_ME_360_2019a_older_v_B.DiscreteFilter1;
  rtb_TmpSignalConversionAtToFile[4] =
    Lab0_ECE_ME_360_2019a_older_v_B.DiscreteFilter;
  rtb_TmpSignalConversionAtToFile[5] = Lab0_ECE_ME_360_2019a_older_v_B.Merge;

  /* ToFile: '<Root>/To File' */
  {
    if (!(++Lab0_ECE_ME_360_2019a_older__DW.ToFile_IWORK.Decimation % 1) &&
        (Lab0_ECE_ME_360_2019a_older__DW.ToFile_IWORK.Count * (6 + 1)) + 1 <
        100000000 ) {
      FILE *fp = (FILE *) Lab0_ECE_ME_360_2019a_older__DW.ToFile_PWORK.FilePtr;
      if (fp != (NULL)) {
        real_T u[6 + 1];
        Lab0_ECE_ME_360_2019a_older__DW.ToFile_IWORK.Decimation = 0;
        u[0] = Lab0_ECE_ME_360_2019a_older__M->Timing.t[0];
        u[1] = rtb_TmpSignalConversionAtToFile[0];
        u[2] = rtb_TmpSignalConversionAtToFile[1];
        u[3] = rtb_TmpSignalConversionAtToFile[2];
        u[4] = rtb_TmpSignalConversionAtToFile[3];
        u[5] = rtb_TmpSignalConversionAtToFile[4];
        u[6] = rtb_TmpSignalConversionAtToFile[5];
        if (fwrite(u, sizeof(real_T), 6 + 1, fp) != 6 + 1) {
          rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M,
                            "Error writing to MAT-file cartpole_MOE.mat");
          return;
        }

        if (((++Lab0_ECE_ME_360_2019a_older__DW.ToFile_IWORK.Count) * (6 + 1))+1
            >= 100000000) {
          (void)fprintf(stdout,
                        "*** The ToFile block will stop logging data before\n"
                        "    the simulation has ended, because it has reached\n"
                        "    the maximum number of elements (100000000)\n"
                        "    allowed in MAT-file cartpole_MOE.mat.\n");
        }
      }
    }
  }

  /* Gain: '<Root>/360//Nenc' */
  Lab0_ECE_ME_360_2019a_older_v_B.u60Nenc = 360.0 /
    Lab0_ECE_ME_360_2019a_older_v_P.Nenc * rtb_HILReadEncoderTimebase_o2;
}

/* Model update function */
void Lab0_ECE_ME_360_2019a_older_version_unlocked_update(void)
{
  /* Update for DiscreteFilter: '<S2>/Discrete Filter' */
  Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_states =
    Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_tmp;

  /* Update for DiscreteFilter: '<Root>/Discrete Filter1' */
  Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter1_states[1] =
    Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter1_states[0];
  Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter1_states[0] =
    Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter1_tmp;

  /* Update for DiscreteFilter: '<S1>/Discrete Filter' */
  Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_states_p =
    Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_tmp_c;

  /* Update for DiscreteFilter: '<Root>/Discrete Filter' */
  Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_states_a[1] =
    Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_states_a[0];
  Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_states_a[0] =
    Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_tmp_a;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Lab0_ECE_ME_360_2019a_older__M->Timing.clockTick0)) {
    ++Lab0_ECE_ME_360_2019a_older__M->Timing.clockTickH0;
  }

  Lab0_ECE_ME_360_2019a_older__M->Timing.t[0] =
    Lab0_ECE_ME_360_2019a_older__M->Timing.clockTick0 *
    Lab0_ECE_ME_360_2019a_older__M->Timing.stepSize0 +
    Lab0_ECE_ME_360_2019a_older__M->Timing.clockTickH0 *
    Lab0_ECE_ME_360_2019a_older__M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void Lab0_ECE_ME_360_2019a_older_version_unlocked_initialize(void)
{
  /* Start for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: Lab0_ECE_ME_360_2019a_older_version_unlocked/HIL Initialize (hil_initialize_block) */
  {
    t_int result;
    t_boolean is_switching;
    result = hil_open("q2_usb", "0",
                      &Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M, _rt_error_message);
      return;
    }

    is_switching = false;
    result = hil_set_card_specific_options
      (Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card,
       "d0=digital;d1=digital;led=auto;update_rate=normal;decimation=1", 63);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M, _rt_error_message);
      return;
    }

    result = hil_watchdog_clear
      (Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card);
    if (result < 0 && result != -QERR_HIL_WATCHDOG_CLEAR) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M, _rt_error_message);
      return;
    }

    if ((Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AIPStart && !is_switching)
        || (Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AIPEnter &&
            is_switching)) {
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AIMinimums[0] =
        (Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AILow);
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AIMinimums[1] =
        (Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AILow);
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AIMaximums[0] =
        Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AIHigh;
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AIMaximums[1] =
        Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AIHigh;
      result = hil_set_analog_input_ranges
        (Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card,
         Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AIChannels, 2U,
         &Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AIMinimums[0],
         &Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AIMaximums[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M, _rt_error_message);
        return;
      }
    }

    if ((Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOPStart && !is_switching)
        || (Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOPEnter &&
            is_switching)) {
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AOMinimums[0] =
        (Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOLow);
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AOMinimums[1] =
        (Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOLow);
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AOMaximums[0] =
        Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOHigh;
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AOMaximums[1] =
        Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOHigh;
      result = hil_set_analog_output_ranges
        (Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card,
         Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOChannels, 2U,
         &Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AOMinimums[0],
         &Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AOMaximums[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M, _rt_error_message);
        return;
      }
    }

    if ((Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOStart && !is_switching)
        || (Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOEnter &&
            is_switching)) {
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AOVoltages[0] =
        Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOInitial;
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AOVoltages[1] =
        Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOInitial;
      result = hil_write_analog
        (Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card,
         Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOChannels, 2U,
         &Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AOVoltages[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M, _rt_error_message);
        return;
      }
    }

    if (Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOReset) {
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AOVoltages[0] =
        Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOWatchdog;
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AOVoltages[1] =
        Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOWatchdog;
      result = hil_watchdog_set_analog_expiration_state
        (Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card,
         Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOChannels, 2U,
         &Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AOVoltages[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M, _rt_error_message);
        return;
      }
    }

    if ((Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_EIPStart && !is_switching)
        || (Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_EIPEnter &&
            is_switching)) {
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_QuadratureModes[0] =
        Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_EIQuadrature;
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_QuadratureModes[1] =
        Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_EIQuadrature;
      result = hil_set_encoder_quadrature_mode
        (Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card,
         Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_EIChannels, 2U,
         (t_encoder_quadrature_mode *)
         &Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_QuadratureModes[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M, _rt_error_message);
        return;
      }
    }

    if ((Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_EIStart && !is_switching)
        || (Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_EIEnter &&
            is_switching)) {
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_InitialEICounts[0] =
        Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_EIInitial;
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_InitialEICounts[1] =
        Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_EIInitial;
      result = hil_set_encoder_counts
        (Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card,
         Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_EIChannels, 2U,
         &Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_InitialEICounts[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M, _rt_error_message);
        return;
      }
    }
  }

  /* Start for S-Function (hil_read_encoder_timebase_block): '<Root>/HIL Read Encoder Timebase' */

  /* S-Function Block: Lab0_ECE_ME_360_2019a_older_version_unlocked/HIL Read Encoder Timebase (hil_read_encoder_timebase_block) */
  {
    t_error result;
    result = hil_task_create_encoder_reader
      (Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card,
       Lab0_ECE_ME_360_2019a_older_v_P.HILReadEncoderTimebase_samples_,
       Lab0_ECE_ME_360_2019a_older_v_P.HILReadEncoderTimebase_channels, 2,
       &Lab0_ECE_ME_360_2019a_older__DW.HILReadEncoderTimebase_Task);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M, _rt_error_message);
    }
  }

  /* Start for ToFile: '<Root>/To File' */
  {
    FILE *fp = (NULL);
    char fileName[509] = "cartpole_MOE.mat";
    if ((fp = fopen(fileName, "wb")) == (NULL)) {
      rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M,
                        "Error creating .mat file cartpole_MOE.mat");
      return;
    }

    if (rt_WriteMat4FileHeader(fp, 6 + 1, 0, "cart_data")) {
      rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M,
                        "Error writing mat file header to file cartpole_MOE.mat");
      return;
    }

    Lab0_ECE_ME_360_2019a_older__DW.ToFile_IWORK.Count = 0;
    Lab0_ECE_ME_360_2019a_older__DW.ToFile_IWORK.Decimation = -1;
    Lab0_ECE_ME_360_2019a_older__DW.ToFile_PWORK.FilePtr = fp;
  }

  /* InitializeConditions for DiscreteFilter: '<S2>/Discrete Filter' */
  Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_states =
    Lab0_ECE_ME_360_2019a_older_v_P.DiscreteFilter_InitialStates;

  /* InitializeConditions for DiscreteFilter: '<S1>/Discrete Filter' */
  Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_states_p =
    Lab0_ECE_ME_360_2019a_older_v_P.DiscreteFilter_InitialStates_g;

  /* InitializeConditions for DiscreteFilter: '<Root>/Discrete Filter1' */
  Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter1_states[0] =
    Lab0_ECE_ME_360_2019a_older_v_P.DiscreteFilter1_InitialStates;

  /* InitializeConditions for DiscreteFilter: '<Root>/Discrete Filter' */
  Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_states_a[0] =
    Lab0_ECE_ME_360_2019a_older_v_P.DiscreteFilter_InitialStates_h;

  /* InitializeConditions for DiscreteFilter: '<Root>/Discrete Filter1' */
  Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter1_states[1] =
    Lab0_ECE_ME_360_2019a_older_v_P.DiscreteFilter1_InitialStates;

  /* InitializeConditions for DiscreteFilter: '<Root>/Discrete Filter' */
  Lab0_ECE_ME_360_2019a_older__DW.DiscreteFilter_states_a[1] =
    Lab0_ECE_ME_360_2019a_older_v_P.DiscreteFilter_InitialStates_h;

  /* SystemInitialize for Merge: '<S4>/Merge' */
  Lab0_ECE_ME_360_2019a_older_v_B.Merge =
    Lab0_ECE_ME_360_2019a_older_v_P.Merge_InitialOutput;
}

/* Model terminate function */
void Lab0_ECE_ME_360_2019a_older_version_unlocked_terminate(void)
{
  /* Terminate for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: Lab0_ECE_ME_360_2019a_older_version_unlocked/HIL Initialize (hil_initialize_block) */
  {
    t_boolean is_switching;
    t_int result;
    t_uint32 num_final_analog_outputs = 0;
    hil_task_stop_all(Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card);
    hil_monitor_stop_all(Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card);
    is_switching = false;
    if ((Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOTerminate &&
         !is_switching) || (Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOExit
         && is_switching)) {
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AOVoltages[0] =
        Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOFinal;
      Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AOVoltages[1] =
        Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOFinal;
      num_final_analog_outputs = 2U;
    }

    if (num_final_analog_outputs > 0) {
      result = hil_write_analog
        (Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card,
         Lab0_ECE_ME_360_2019a_older_v_P.HILInitialize_AOChannels,
         num_final_analog_outputs,
         &Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_AOVoltages[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M, _rt_error_message);
      }
    }

    hil_task_delete_all(Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card);
    hil_monitor_delete_all(Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card);
    hil_close(Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card);
    Lab0_ECE_ME_360_2019a_older__DW.HILInitialize_Card = NULL;
  }

  /* Terminate for ToFile: '<Root>/To File' */
  {
    FILE *fp = (FILE *) Lab0_ECE_ME_360_2019a_older__DW.ToFile_PWORK.FilePtr;
    if (fp != (NULL)) {
      char fileName[509] = "cartpole_MOE.mat";
      if (fclose(fp) == EOF) {
        rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M,
                          "Error closing MAT-file cartpole_MOE.mat");
        return;
      }

      if ((fp = fopen(fileName, "r+b")) == (NULL)) {
        rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M,
                          "Error reopening MAT-file cartpole_MOE.mat");
        return;
      }

      if (rt_WriteMat4FileHeader(fp, 6 + 1,
           Lab0_ECE_ME_360_2019a_older__DW.ToFile_IWORK.Count, "cart_data")) {
        rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M,
                          "Error writing header for cart_data to MAT-file cartpole_MOE.mat");
      }

      if (fclose(fp) == EOF) {
        rtmSetErrorStatus(Lab0_ECE_ME_360_2019a_older__M,
                          "Error closing MAT-file cartpole_MOE.mat");
        return;
      }

      Lab0_ECE_ME_360_2019a_older__DW.ToFile_PWORK.FilePtr = (NULL);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  Lab0_ECE_ME_360_2019a_older_version_unlocked_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  Lab0_ECE_ME_360_2019a_older_version_unlocked_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  Lab0_ECE_ME_360_2019a_older_version_unlocked_initialize();
}

void MdlTerminate(void)
{
  Lab0_ECE_ME_360_2019a_older_version_unlocked_terminate();
}

/* Registration function */
RT_MODEL_Lab0_ECE_ME_360_2019_T *Lab0_ECE_ME_360_2019a_older_version_unlocked
  (void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)Lab0_ECE_ME_360_2019a_older__M, 0,
                sizeof(RT_MODEL_Lab0_ECE_ME_360_2019_T));

  /* Initialize timing info */
  {
    int_T *mdlTsMap =
      Lab0_ECE_ME_360_2019a_older__M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    Lab0_ECE_ME_360_2019a_older__M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    Lab0_ECE_ME_360_2019a_older__M->Timing.sampleTimes =
      (&Lab0_ECE_ME_360_2019a_older__M->Timing.sampleTimesArray[0]);
    Lab0_ECE_ME_360_2019a_older__M->Timing.offsetTimes =
      (&Lab0_ECE_ME_360_2019a_older__M->Timing.offsetTimesArray[0]);

    /* task periods */
    Lab0_ECE_ME_360_2019a_older__M->Timing.sampleTimes[0] = (0.001);

    /* task offsets */
    Lab0_ECE_ME_360_2019a_older__M->Timing.offsetTimes[0] = (0.0);
  }

  rtmSetTPtr(Lab0_ECE_ME_360_2019a_older__M,
             &Lab0_ECE_ME_360_2019a_older__M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = Lab0_ECE_ME_360_2019a_older__M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    Lab0_ECE_ME_360_2019a_older__M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(Lab0_ECE_ME_360_2019a_older__M, -1);
  Lab0_ECE_ME_360_2019a_older__M->Timing.stepSize0 = 0.001;

  /* External mode info */
  Lab0_ECE_ME_360_2019a_older__M->Sizes.checksums[0] = (1817274173U);
  Lab0_ECE_ME_360_2019a_older__M->Sizes.checksums[1] = (4151289828U);
  Lab0_ECE_ME_360_2019a_older__M->Sizes.checksums[2] = (2941169150U);
  Lab0_ECE_ME_360_2019a_older__M->Sizes.checksums[3] = (2728187131U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[9];
    Lab0_ECE_ME_360_2019a_older__M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = (sysRanDType *)
      &Lab0_ECE_ME_360_2019a_older__DW.SwitchCaseActionSubsystem_Subsy;
    systemRan[4] = (sysRanDType *)
      &Lab0_ECE_ME_360_2019a_older__DW.SwitchCaseActionSubsystem_Subsy;
    systemRan[5] = (sysRanDType *)
      &Lab0_ECE_ME_360_2019a_older__DW.SwitchCaseActionSubsystem1_Subs;
    systemRan[6] = (sysRanDType *)
      &Lab0_ECE_ME_360_2019a_older__DW.SwitchCaseActionSubsystem1_Subs;
    systemRan[7] = (sysRanDType *)
      &Lab0_ECE_ME_360_2019a_older__DW.SwitchCaseActionSubsystem2_Subs;
    systemRan[8] = (sysRanDType *)
      &Lab0_ECE_ME_360_2019a_older__DW.SwitchCaseActionSubsystem2_Subs;
    rteiSetModelMappingInfoPtr(Lab0_ECE_ME_360_2019a_older__M->extModeInfo,
      &Lab0_ECE_ME_360_2019a_older__M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(Lab0_ECE_ME_360_2019a_older__M->extModeInfo,
                        Lab0_ECE_ME_360_2019a_older__M->Sizes.checksums);
    rteiSetTPtr(Lab0_ECE_ME_360_2019a_older__M->extModeInfo, rtmGetTPtr
                (Lab0_ECE_ME_360_2019a_older__M));
  }

  Lab0_ECE_ME_360_2019a_older__M->solverInfoPtr =
    (&Lab0_ECE_ME_360_2019a_older__M->solverInfo);
  Lab0_ECE_ME_360_2019a_older__M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&Lab0_ECE_ME_360_2019a_older__M->solverInfo, 0.001);
  rtsiSetSolverMode(&Lab0_ECE_ME_360_2019a_older__M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  Lab0_ECE_ME_360_2019a_older__M->blockIO = ((void *)
    &Lab0_ECE_ME_360_2019a_older_v_B);
  (void) memset(((void *) &Lab0_ECE_ME_360_2019a_older_v_B), 0,
                sizeof(B_Lab0_ECE_ME_360_2019a_older_T));

  /* parameters */
  Lab0_ECE_ME_360_2019a_older__M->defaultParam = ((real_T *)
    &Lab0_ECE_ME_360_2019a_older_v_P);

  /* states (dwork) */
  Lab0_ECE_ME_360_2019a_older__M->dwork = ((void *)
    &Lab0_ECE_ME_360_2019a_older__DW);
  (void) memset((void *)&Lab0_ECE_ME_360_2019a_older__DW, 0,
                sizeof(DW_Lab0_ECE_ME_360_2019a_olde_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    Lab0_ECE_ME_360_2019a_older__M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 16;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  Lab0_ECE_ME_360_2019a_older__M->Sizes.numContStates = (0);/* Number of continuous states */
  Lab0_ECE_ME_360_2019a_older__M->Sizes.numY = (0);/* Number of model outputs */
  Lab0_ECE_ME_360_2019a_older__M->Sizes.numU = (0);/* Number of model inputs */
  Lab0_ECE_ME_360_2019a_older__M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  Lab0_ECE_ME_360_2019a_older__M->Sizes.numSampTimes = (1);/* Number of sample times */
  Lab0_ECE_ME_360_2019a_older__M->Sizes.numBlocks = (77);/* Number of blocks */
  Lab0_ECE_ME_360_2019a_older__M->Sizes.numBlockIO = (14);/* Number of block outputs */
  Lab0_ECE_ME_360_2019a_older__M->Sizes.numBlockPrms = (435);/* Sum of parameter "widths" */
  return Lab0_ECE_ME_360_2019a_older__M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
