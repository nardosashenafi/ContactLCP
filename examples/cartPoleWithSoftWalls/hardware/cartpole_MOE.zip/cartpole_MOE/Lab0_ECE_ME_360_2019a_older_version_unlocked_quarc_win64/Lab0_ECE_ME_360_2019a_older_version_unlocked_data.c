/*
 * Lab0_ECE_ME_360_2019a_older_version_unlocked_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Lab0_ECE_ME_360_2019a_older_version_unlocked".
 *
 * Model version              : 1.9
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C source code generated on : Tue Jan 31 13:44:58 2023
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Lab0_ECE_ME_360_2019a_older_version_unlocked.h"
#include "Lab0_ECE_ME_360_2019a_older_version_unlocked_private.h"

/* Block parameters (default storage) */
P_Lab0_ECE_ME_360_2019a_older_T Lab0_ECE_ME_360_2019a_older_v_P = {
  /* Variable: Kt
   * Referenced by:
   *   '<S3>/Gain5'
   *   '<S3>/Gain6'
   */
  0.00767,

  /* Variable: Nenc
   * Referenced by:
   *   '<Root>/2pi//Nenc'
   *   '<Root>/360//Nenc'
   *   '<Root>/Kenc'
   */
  4096.0,

  /* Variable: R
   * Referenced by: '<S3>/Gain5'
   */
  2.6,

  /* Variable: T
   * Referenced by:
   *   '<S1>/Gain3'
   *   '<S2>/Gain3'
   */
  0.001,

  /* Variable: Vmax
   * Referenced by: '<S3>/Saturation1'
   */
  10.0,

  /* Variable: af
   * Referenced by:
   *   '<Root>/Discrete Filter'
   *   '<Root>/Discrete Filter1'
   */
  { 1.0, -1.8226949251963083, 0.83718165125602284 },

  /* Variable: bf
   * Referenced by:
   *   '<Root>/Discrete Filter'
   *   '<Root>/Discrete Filter1'
   */
  { 0.003621681514928643, 0.007243363029857286, 0.003621681514928643 },

  /* Variable: binW1
   * Referenced by: '<S4>/Constant2'
   */
  { 0.767200430244548, -1.16135700516221, 0.88764887074744125,
    0.55744428276673486, -0.093335187731844252, -0.21491051452167595,
    -0.9716885367974345, 1.1717182802839745, 1.2931717990987213,
    1.5528468455038311, 0.050914348939397204, 0.24957734692693068,
    0.034948173453151307, -0.18092320889714905, 0.67083046999602891,
    0.38265760558242545, 0.37888286516669506, 0.26547710721682294,
    -0.095222776083401253, 0.0757455315290951, -1.1463660817878611,
    -1.4287023983063452, -0.36917924814852932, -0.76940458263732014,
    0.022079995558167996 },

  /* Variable: binW2
   * Referenced by: '<S4>/Constant3'
   */
  { 0.66886608063493647, 0.9991243892432401, -0.29507309256732728,
    -0.10868331123337538, 0.2094081789439653, 1.6698916400068771,
    0.069904154203692087, -0.20374119490618664, 1.3382681316079061,
    -0.66561630197239141, -0.79346647567533846, 1.2273531691031787,
    1.7964437632431267, -0.83332153206527693, -1.5779129273714354,
    -1.3321455644062949, 1.8003068106670173, -0.29147622091016251,
    -1.4047264843784919, -0.929739411078294 },

  /* Variable: binW3
   * Referenced by: '<S4>/Constant4'
   */
  { 1.0386514092611425, 1.5643718254919303, -3.3642584151693873,
    -2.5947218238964105, 0.66188857007310442, 0.35922742012803932,
    -2.3838534394638273, -1.0954053726356325, 2.7753196493525247,
    0.16419084348840879, -2.0250075932335592, 0.65271471694436212 },

  /* Variable: binb1
   * Referenced by: '<S4>/Constant5'
   */
  { -0.21686783876632962, -0.390393203698414, 0.35531392402823625,
    -0.34059864529220107, -1.2427616959243708 },

  /* Variable: binb2
   * Referenced by: '<S4>/Constant6'
   */
  { -0.7946492846182398, 0.883984930815371, 0.8844304857078038,
    1.6545096945302356 },

  /* Variable: binb3
   * Referenced by: '<S4>/Constant7'
   */
  { 0.5789146816472982, -1.6425602554056571, 0.81822325538883911 },

  /* Variable: control1W1
   * Referenced by: '<S7>/Constant2'
   */
  { 0.89880337066648686, -0.79835665197611594, 0.84047570202762822,
    -0.83102780387314978, 0.76815884272353518, 0.72741487799062976,
    0.880003323994818, -0.8581226651037539, 0.0355707460586577,
    -0.0546148193234518, 0.14114757838056746, -0.14661668988736631,
    -0.13137891983426064, -0.01902995812464368, 0.11992908548572474,
    0.066069343220542837, 0.38058749724918162, -0.385873210629132,
    0.59456930581661915, -0.21854227448458555, 0.15181761289568096,
    0.35850089157258347, 0.35226028836481171, -0.27993845139258766,
    0.16877755860049215, -0.023587120718423692, -0.0799543177476072,
    0.00976465585547487, -0.094269832878887988, -0.014455554707155935,
    -0.089855581800641932, 0.044171723866257555, -0.013433911557693962,
    -0.031789144775706428, 0.076302196200841735, -0.0049457374811173287,
    0.080157247636032172, 0.014601078285326672, -0.0046238884714240288,
    0.0053990553857377445 },

  /* Variable: control1W2
   * Referenced by: '<S7>/Constant3'
   */
  { 0.40503603568963242, -0.21677183617154086, -0.39718156206497518,
    0.45997346371203235, -0.32958115664098919, 0.35659305274719527,
    0.18237358903914902, -0.49306231877205686, 0.34855117345156494,
    -0.27749714813208687, -0.35317411713500757, 0.29660379674785442,
    -0.57185359248974565, 0.41710398027760542, 0.4776649369041423,
    -0.65139755972553581, 0.10916026640625708, -0.26722770164561044,
    -0.38539579863403484, 0.24053008824165395, 0.4093302026317085,
    -0.18790042025145129, -0.15722910342098687, 0.27290982051440849,
    0.69606016402393545, -0.749576614722177, -0.638070388694117,
    0.55994039381171656, -0.45954114221060827, 0.29837939097567312,
    0.30740306877863621, -0.4988199249355999 },

  /* Variable: control1W3
   * Referenced by: '<S7>/Constant4'
   */
  { -0.55047564878394384, 0.45221689340016852, 0.39573521250310828,
    -0.47262947594126481 },

  /* Variable: control1b1
   * Referenced by: '<S7>/Constant5'
   */
  { 0.1036172534373172, 0.0036586287790753109, -0.037555737056543095,
    0.10196940108381963, -0.081277986722071746, 0.25702870129120425,
    0.14994639677283372, 0.066350168981920712 },

  /* Variable: control1b2
   * Referenced by: '<S7>/Constant6'
   */
  { 0.13822100470507029, 0.03382873645281282, 0.0072655590955059282,
    0.042147198728025706 },

  /* Variable: control1b3
   * Referenced by: '<S7>/Constant7'
   */
  -0.22386419137524793,

  /* Variable: control2W1
   * Referenced by: '<S8>/Constant2'
   */
  { -0.8238295298828141, 0.70568568144001553, 0.84077168883832953,
    0.84632052279217185, 0.76102895399708892, -0.57611379631541737,
    -0.90277672314961932, -0.88050446253557679, -0.029430135984228889,
    0.13410053412576942, 0.18902955779879671, 0.34402687531817411,
    0.22844178142664334, -0.079084076830939945, 0.083975985450314039,
    0.10185734779687688, -0.11618684969517472, -0.32295960411263691,
    -0.1460810384665312, -0.08424097397997124, -0.003154371182037556,
    0.24372724695110198, -0.097227304757951466, 0.013127629739151185,
    -0.5724779413857749, -0.003527465187056504, 0.54170945514421787,
    0.47950379350733591, 0.43558448337440447, -0.25347687686857245,
    -0.64272284028692561, -0.73699759315089908, -0.037562060031619784,
    -0.0068674151490526122, -0.012865515192292825, 0.10712236161547189,
    -0.0060770032231990557, -0.0827236495039057, -0.05575331124497359,
    -0.03752583896997385 },

  /* Variable: control2W2
   * Referenced by: '<S8>/Constant3'
   */
  { 0.3466216059446629, 0.45557178997609526, 0.15082334690741375,
    0.33390131460490524, -0.32310223067945248, -0.24989143767244695,
    -0.19603173637246246, -0.30180331216048578, -0.57430646055619772,
    -0.51353010724356474, -0.59197171904638368, -0.52959356202515662,
    -0.18048224812322849, -0.31247637349621105, -0.16934038924053013,
    -0.15003576627980283, -0.55948036623234709, -0.62444640367339954,
    -0.5164767527357107, -0.64761003708761744, -0.045427036986007363,
    0.17567330409445392, 0.10039474112411953, 0.072555723277802547,
    0.46964629879216307, 0.53820373679893418, 0.34652620816226182,
    0.36167319383749064, 0.42965902375978754, 0.61848619631086343,
    0.36928840457266526, 0.59602332266923663 },

  /* Variable: control2W3
   * Referenced by: '<S8>/Constant4'
   */
  { 0.63488752176196639, 0.52785516865714832, 0.516703507834947,
    0.868313070447727 },

  /* Variable: control2b1
   * Referenced by: '<S8>/Constant5'
   */
  { 0.3431191188153831, -0.10828128684706584, -0.183904552339504,
    0.1524731094080142, -0.072741632640302575, 0.031971334490487426,
    0.22045018567250693, 0.15513464911977964 },

  /* Variable: control2b2
   * Referenced by: '<S8>/Constant6'
   */
  { 0.10203802254405912, -0.081049383763317648, 0.096217396476576789,
    0.053733900153200891 },

  /* Variable: control2b3
   * Referenced by: '<S8>/Constant7'
   */
  -0.074352331870624636,

  /* Variable: control3W1
   * Referenced by: '<S9>/Constant2'
   */
  { -0.73187552456711169, 0.91981152345221728, -0.79296090585091727,
    -0.87350737789329946, -0.91814899685532747, -0.76539045649179338,
    0.84398500486341588, -0.91600183582925443, 0.17335019503923715,
    0.083751105213325072, 0.15297357188633898, 0.25649163370992967,
    0.164729806710216, 0.31003993451883377, 0.29832183997067013,
    0.10349186830224691, 0.14947309209723461, -0.13955037478064963,
    0.29913548649697436, 0.032455238570817876, 0.25599918932496346,
    -0.0774406327987974, -0.037866367370490442, 0.078154296432686718,
    -0.27657348931185161, 0.67805299470637326, -0.77381750910624336,
    -0.434958596680363, -0.60288170606130576, -0.55566590636177482,
    0.66307840340262658, -0.57298384239474887, -0.0630355779080068,
    0.0669300371911962, 0.011664379617309831, -0.06951687671654197,
    -0.010207113997671761, -0.043179707205376075, 0.018713905567964272,
    0.036987540448319312 },

  /* Variable: control3W2
   * Referenced by: '<S9>/Constant3'
   */
  { 0.1856522199039726, -0.26293199963983849, -0.13403947791349552,
    -0.14183114020295215, -0.5192593646046646, 0.91600186393742855,
    0.83696463141696154, 0.75834119164474278, 0.37971936589664707,
    -0.76864814553810135, -0.75151637393583937, -0.96589445543603525,
    0.282975862447851, -0.47999538482071946, -0.22286923218466825,
    -0.40028114903329415, 0.30134164204326963, -0.65284232256184571,
    -0.771855573370959, -0.74321701757503011, 0.19439308457031845,
    -0.33250556802877573, -0.31869022451909051, -0.228428521903038,
    -0.22314747732893472, 0.47729097963633965, 0.443532170331931,
    0.51224722515145582, 0.49285190949610941, -0.7797806016179295,
    -0.73650139898923561, -0.88514439946160817 },

  /* Variable: control3W3
   * Referenced by: '<S9>/Constant4'
   */
  { 0.54502740715348208, -0.5745698368882729, -0.8216650205424515,
    -0.67266461570743141 },

  /* Variable: control3b1
   * Referenced by: '<S9>/Constant5'
   */
  { -0.098391488748865469, 0.1909429319882025, -0.088515266675932291,
    -0.064175146297065222, -0.042880210988472695, -0.19535029650758062,
    0.13555367716698613, -0.28128408170275043 },

  /* Variable: control3b2
   * Referenced by: '<S9>/Constant6'
   */
  { -0.1636628061155902, 0.3195125331651793, 0.11653303009724376,
    0.35462548903344332 },

  /* Variable: control3b3
   * Referenced by: '<S9>/Constant7'
   */
  -0.053350871020658705,

  /* Variable: r_enc
   * Referenced by: '<Root>/Kenc'
   */
  0.01483,

  /* Variable: rg
   * Referenced by:
   *   '<S3>/Gain5'
   *   '<S3>/Gain6'
   */
  3.71,

  /* Variable: rm
   * Referenced by:
   *   '<S3>/Gain5'
   *   '<S3>/Gain6'
   */
  0.00635,

  /* Mask Parameter: HILReadEncoderTimebase_clock
   * Referenced by: '<Root>/HIL Read Encoder Timebase'
   */
  0,

  /* Mask Parameter: HILReadEncoderTimebase_channels
   * Referenced by: '<Root>/HIL Read Encoder Timebase'
   */
  { 0U, 1U },

  /* Mask Parameter: HILWriteAnalog_channels
   * Referenced by: '<Root>/HIL Write Analog'
   */
  0U,

  /* Mask Parameter: HILReadEncoderTimebase_samples_
   * Referenced by: '<Root>/HIL Read Encoder Timebase'
   */
  1000U,

  /* Expression: set_other_outputs_at_terminate
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: set_other_outputs_at_switch_out
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: set_other_outputs_at_start
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: set_other_outputs_at_switch_in
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: final_analog_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: final_pwm_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: analog_input_maximums
   * Referenced by: '<Root>/HIL Initialize'
   */
  10.0,

  /* Expression: analog_input_minimums
   * Referenced by: '<Root>/HIL Initialize'
   */
  -10.0,

  /* Expression: analog_output_maximums
   * Referenced by: '<Root>/HIL Initialize'
   */
  10.0,

  /* Expression: analog_output_minimums
   * Referenced by: '<Root>/HIL Initialize'
   */
  -10.0,

  /* Expression: initial_analog_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: watchdog_analog_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: pwm_frequency
   * Referenced by: '<Root>/HIL Initialize'
   */
  50.0,

  /* Expression: initial_pwm_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: watchdog_pwm_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: pi
   * Referenced by: '<Root>/Constant'
   */
  3.1415926535897931,

  /* Expression: [1 -1]
   * Referenced by: '<S2>/Discrete Filter'
   */
  { 1.0, -1.0 },

  /* Expression: [1  0]
   * Referenced by: '<S2>/Discrete Filter'
   */
  { 1.0, 0.0 },

  /* Expression: 0
   * Referenced by: '<S2>/Discrete Filter'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Discrete Filter1'
   */
  0.0,

  /* Expression: pi
   * Referenced by: '<Root>/Constant1'
   */
  3.1415926535897931,

  /* Expression: [1 -1]
   * Referenced by: '<S1>/Discrete Filter'
   */
  { 1.0, -1.0 },

  /* Expression: [1  0]
   * Referenced by: '<S1>/Discrete Filter'
   */
  { 1.0, 0.0 },

  /* Expression: 0
   * Referenced by: '<S1>/Discrete Filter'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Discrete Filter'
   */
  0.0,

  /* Computed Parameter: Merge_InitialOutput
   * Referenced by: '<S4>/Merge'
   */
  0.0,

  /* Expression: 0.1
   * Referenced by: '<Root>/On or off1'
   */
  0.1,

  /* Expression: 1.2
   * Referenced by: '<Root>/On or off'
   */
  1.2,

  /* Computed Parameter: HILInitialize_CKChannels
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOWatchdog
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_EIInitial
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POModes
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AIChannels
   * Referenced by: '<Root>/HIL Initialize'
   */
  { 0U, 1U },

  /* Computed Parameter: HILInitialize_AOChannels
   * Referenced by: '<Root>/HIL Initialize'
   */
  { 0U, 1U },

  /* Computed Parameter: HILInitialize_EIChannels
   * Referenced by: '<Root>/HIL Initialize'
   */
  { 0U, 1U },

  /* Computed Parameter: HILInitialize_EIQuadrature
   * Referenced by: '<Root>/HIL Initialize'
   */
  4U,

  /* Computed Parameter: HILInitialize_Active
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOTerminate
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_AOExit
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOTerminate
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOExit
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POTerminate
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_POExit
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AIPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_AIPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_AOPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_AOEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOReset
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOReset
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_EIPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_EIPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_EIStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_EIEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_POPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_POEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POReset
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_OOReset
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOFinal
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOInitial
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILReadEncoderTimebase_Active
   * Referenced by: '<Root>/HIL Read Encoder Timebase'
   */
  1,

  /* Computed Parameter: HILWriteAnalog_Active
   * Referenced by: '<Root>/HIL Write Analog'
   */
  0
};
