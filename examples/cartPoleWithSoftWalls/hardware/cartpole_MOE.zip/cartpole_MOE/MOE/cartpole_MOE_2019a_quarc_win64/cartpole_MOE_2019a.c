/*
 * cartpole_MOE_2019a.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "cartpole_MOE_2019a".
 *
 * Model version              : 1.21
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C source code generated on : Wed Feb  8 15:27:21 2023
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "cartpole_MOE_2019a.h"
#include "cartpole_MOE_2019a_private.h"
#include "cartpole_MOE_2019a_dt.h"

/* Block signals (default storage) */
B_cartpole_MOE_2019a_T cartpole_MOE_2019a_B;

/* Continuous states */
X_cartpole_MOE_2019a_T cartpole_MOE_2019a_X;

/* Block states (default storage) */
DW_cartpole_MOE_2019a_T cartpole_MOE_2019a_DW;

/* Real-time model */
RT_MODEL_cartpole_MOE_2019a_T cartpole_MOE_2019a_M_;
RT_MODEL_cartpole_MOE_2019a_T *const cartpole_MOE_2019a_M =
  &cartpole_MOE_2019a_M_;

/*
 * Writes out MAT-file header.  Returns success or failure.
 * Returns:
 *      0 - success
 *      1 - failure
 */
int_T rt_WriteMat4FileHeader(FILE *fp, int32_T m, int32_T n, const char *name)
{
  typedef enum { ELITTLE_ENDIAN, EBIG_ENDIAN } ByteOrder;

  int16_T one = 1;
  ByteOrder byteOrder = (*((int8_T *)&one)==1) ? ELITTLE_ENDIAN : EBIG_ENDIAN;
  int32_T type = (byteOrder == ELITTLE_ENDIAN) ? 0: 1000;
  int32_T imagf = 0;
  int32_T name_len = (int32_T)strlen(name) + 1;
  if ((fwrite(&type, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&m, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&n, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&imagf, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&name_len, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(name, sizeof(char), name_len, fp) == 0)) {
    return(1);
  } else {
    return(0);
  }
}                                      /* end rt_WriteMat4FileHeader */

/*
 * This function updates continuous states using the ODE1 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE1_IntgData *id = (ODE1_IntgData *)rtsiGetSolverData(si);
  real_T *f0 = id->f[0];
  int_T i;
  int_T nXc = 1;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);
  rtsiSetdX(si, f0);
  cartpole_MOE_2019a_derivatives();
  rtsiSetT(si, tnew);
  for (i = 0; i < nXc; ++i) {
    x[i] += h * f0[i];
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/*
 * Output and update for atomic system:
 *    '<S9>/MATLAB Function'
 *    '<S10>/MATLAB Function'
 *    '<S11>/MATLAB Function'
 */
void cartpole_MOE_201_MATLABFunction(real_T rtu_x, real_T rtu_x_k, real_T
  rtu_x_n, real_T rtu_x_g, const real_T rtu_W1[50], const real_T rtu_W2[40],
  const real_T rtu_W3[4], const real_T rtu_b1[10], const real_T rtu_b2[4],
  real_T rtu_b3, B_MATLABFunction_cartpole_MOE_T *localB)
{
  real_T z1[10];
  real_T rtb_TmpSignalConversionAtSFun_0[5];
  int32_T i;
  int32_T i_0;
  real_T x;
  real_T rtb_TmpSignalConversionAtSFun_d;

  /* SignalConversion: '<S13>/TmpSignal ConversionAt SFunction Inport1' */
  /* MATLAB Function 'MOE/Swingup Control/Controller 1/MATLAB Function': '<S13>:1' */
  /* '<S13>:1:2' */
  /* '<S13>:1:3' */
  rtb_TmpSignalConversionAtSFun_0[0] = rtu_x;
  rtb_TmpSignalConversionAtSFun_0[1] = cos(rtu_x_k);
  rtb_TmpSignalConversionAtSFun_0[2] = sin(rtu_x_k);
  rtb_TmpSignalConversionAtSFun_0[3] = rtu_x_n;
  rtb_TmpSignalConversionAtSFun_0[4] = rtu_x_g;
  for (i = 0; i < 10; i++) {
    rtb_TmpSignalConversionAtSFun_d = 0.0;
    for (i_0 = 0; i_0 < 5; i_0++) {
      rtb_TmpSignalConversionAtSFun_d += rtu_W1[10 * i_0 + i] *
        rtb_TmpSignalConversionAtSFun_0[i_0];
    }

    x = rtb_TmpSignalConversionAtSFun_d + rtu_b1[i];
    if (x > 0.0) {
      z1[i] = x;
    } else {
      z1[i] = exp(x) - 1.0;
    }
  }

  /* '<S13>:1:4' */
  /* '<S13>:1:5' */
  /* '<S13>:1:6' */
  x = 0.0;
  for (i = 0; i < 4; i++) {
    rtb_TmpSignalConversionAtSFun_d = 0.0;
    for (i_0 = 0; i_0 < 10; i_0++) {
      rtb_TmpSignalConversionAtSFun_d += rtu_W2[(i_0 << 2) + i] * z1[i_0];
    }

    rtb_TmpSignalConversionAtSFun_d += rtu_b2[i];
    if (!(rtb_TmpSignalConversionAtSFun_d > 0.0)) {
      rtb_TmpSignalConversionAtSFun_d = exp(rtb_TmpSignalConversionAtSFun_d) -
        1.0;
    }

    x += rtu_W3[i] * rtb_TmpSignalConversionAtSFun_d;
  }

  localB->y = x + rtu_b3;
}

/* Model output function */
void cartpole_MOE_2019a_output(void)
{
  /* local block i/o variables */
  real_T rtb_HILReadEncoderTimebase_o2;
  real_T rtb_TmpSignalConversionAtToFile[6];
  real_T rtb_upiNenc;
  real_T z1[4];
  real_T z2[3];
  real_T z3[3];
  int32_T maxindex;
  int8_T rtPrevAction;
  int8_T rtAction;
  real_T z1_0[5];
  int32_T i;
  real_T u0;
  if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
    /* set solver stop time */
    if (!(cartpole_MOE_2019a_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&cartpole_MOE_2019a_M->solverInfo,
                            ((cartpole_MOE_2019a_M->Timing.clockTickH0 + 1) *
        cartpole_MOE_2019a_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&cartpole_MOE_2019a_M->solverInfo,
                            ((cartpole_MOE_2019a_M->Timing.clockTick0 + 1) *
        cartpole_MOE_2019a_M->Timing.stepSize0 +
        cartpole_MOE_2019a_M->Timing.clockTickH0 *
        cartpole_MOE_2019a_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(cartpole_MOE_2019a_M)) {
    cartpole_MOE_2019a_M->Timing.t[0] = rtsiGetT
      (&cartpole_MOE_2019a_M->solverInfo);
  }

  /* Reset subsysRan breadcrumbs */
  srClearBC(cartpole_MOE_2019a_DW.LQR_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(cartpole_MOE_2019a_DW.Controller1_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(cartpole_MOE_2019a_DW.Controller2_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(cartpole_MOE_2019a_DW.Controller3_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(cartpole_MOE_2019a_DW.SwingupControl_SubsysRanBC);
  if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
    /* S-Function (hil_read_encoder_timebase_block): '<Root>/HIL Read Encoder Timebase' */

    /* S-Function Block: cartpole_MOE_2019a/HIL Read Encoder Timebase (hil_read_encoder_timebase_block) */
    {
      t_error result;
      result = hil_task_read_encoder
        (cartpole_MOE_2019a_DW.HILReadEncoderTimebase_Task, 1,
         &cartpole_MOE_2019a_DW.HILReadEncoderTimebase_Buffer[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
      } else {
        rtb_upiNenc = cartpole_MOE_2019a_DW.HILReadEncoderTimebase_Buffer[0];
        rtb_HILReadEncoderTimebase_o2 =
          cartpole_MOE_2019a_DW.HILReadEncoderTimebase_Buffer[1];
      }
    }

    /* Gain: '<Root>/Kenc' */
    cartpole_MOE_2019a_B.Kenc = cartpole_MOE_2019a_P.r_enc * 2.0 *
      3.1415926535897931 / cartpole_MOE_2019a_P.Nenc * rtb_upiNenc;

    /* Gain: '<Root>/2pi//Nenc' */
    rtb_upiNenc = 6.2831853071795862 / cartpole_MOE_2019a_P.Nenc *
      rtb_HILReadEncoderTimebase_o2;

    /* Sum: '<Root>/Sum' incorporates:
     *  Constant: '<Root>/Constant'
     */
    cartpole_MOE_2019a_B.Sum = rtb_upiNenc + cartpole_MOE_2019a_P.Constant_Value;

    /* DiscreteFilter: '<S2>/Discrete Filter' */
    cartpole_MOE_2019a_DW.DiscreteFilter_tmp = (cartpole_MOE_2019a_B.Kenc -
      cartpole_MOE_2019a_P.DiscreteFilter_DenCoef[1] *
      cartpole_MOE_2019a_DW.DiscreteFilter_states) /
      cartpole_MOE_2019a_P.DiscreteFilter_DenCoef[0];

    /* DiscreteFilter: '<Root>/Discrete Filter1' incorporates:
     *  DiscreteFilter: '<S2>/Discrete Filter'
     *  Gain: '<S2>/Gain3'
     */
    cartpole_MOE_2019a_DW.DiscreteFilter1_tmp =
      (((cartpole_MOE_2019a_P.DiscreteFilter_NumCoef[0] *
         cartpole_MOE_2019a_DW.DiscreteFilter_tmp +
         cartpole_MOE_2019a_P.DiscreteFilter_NumCoef[1] *
         cartpole_MOE_2019a_DW.DiscreteFilter_states) * (1.0 /
         cartpole_MOE_2019a_P.T) - cartpole_MOE_2019a_P.af[1] *
        cartpole_MOE_2019a_DW.DiscreteFilter1_states[0]) -
       cartpole_MOE_2019a_P.af[2] *
       cartpole_MOE_2019a_DW.DiscreteFilter1_states[1]) /
      cartpole_MOE_2019a_P.af[0];
    cartpole_MOE_2019a_B.DiscreteFilter1 = (cartpole_MOE_2019a_P.bf[0] *
      cartpole_MOE_2019a_DW.DiscreteFilter1_tmp + cartpole_MOE_2019a_P.bf[1] *
      cartpole_MOE_2019a_DW.DiscreteFilter1_states[0]) +
      cartpole_MOE_2019a_P.bf[2] * cartpole_MOE_2019a_DW.DiscreteFilter1_states
      [1];

    /* Sum: '<Root>/Sum1' incorporates:
     *  Constant: '<Root>/Constant1'
     */
    cartpole_MOE_2019a_B.Sum1 = rtb_upiNenc +
      cartpole_MOE_2019a_P.Constant1_Value;

    /* DiscreteFilter: '<S1>/Discrete Filter' */
    cartpole_MOE_2019a_DW.DiscreteFilter_tmp_c = (cartpole_MOE_2019a_B.Sum1 -
      cartpole_MOE_2019a_P.DiscreteFilter_DenCoef_f[1] *
      cartpole_MOE_2019a_DW.DiscreteFilter_states_p) /
      cartpole_MOE_2019a_P.DiscreteFilter_DenCoef_f[0];

    /* DiscreteFilter: '<Root>/Discrete Filter' incorporates:
     *  DiscreteFilter: '<S1>/Discrete Filter'
     *  Gain: '<S1>/Gain3'
     */
    cartpole_MOE_2019a_DW.DiscreteFilter_tmp_a =
      (((cartpole_MOE_2019a_P.DiscreteFilter_NumCoef_b[0] *
         cartpole_MOE_2019a_DW.DiscreteFilter_tmp_c +
         cartpole_MOE_2019a_P.DiscreteFilter_NumCoef_b[1] *
         cartpole_MOE_2019a_DW.DiscreteFilter_states_p) * (1.0 /
         cartpole_MOE_2019a_P.T) - cartpole_MOE_2019a_P.af[1] *
        cartpole_MOE_2019a_DW.DiscreteFilter_states_a[0]) -
       cartpole_MOE_2019a_P.af[2] *
       cartpole_MOE_2019a_DW.DiscreteFilter_states_a[1]) /
      cartpole_MOE_2019a_P.af[0];
    cartpole_MOE_2019a_B.DiscreteFilter = (cartpole_MOE_2019a_P.bf[0] *
      cartpole_MOE_2019a_DW.DiscreteFilter_tmp_a + cartpole_MOE_2019a_P.bf[1] *
      cartpole_MOE_2019a_DW.DiscreteFilter_states_a[0]) +
      cartpole_MOE_2019a_P.bf[2] *
      cartpole_MOE_2019a_DW.DiscreteFilter_states_a[1];

    /* MATLAB Function: '<S4>/LQR switch condition' incorporates:
     *  SignalConversion: '<S6>/TmpSignal ConversionAt SFunction Inport1'
     */
    /* MATLAB Function 'MOE/LQR switch condition': '<S6>:1' */
    /* '<S6>:1:2' */
    if ((1.0 - cos(cartpole_MOE_2019a_B.Sum) <= 0.034074173710931688) && (fabs
         (cartpole_MOE_2019a_B.DiscreteFilter) <= 1.5)) {
      /* '<S6>:1:3' */
      /* '<S6>:1:4' */
      cartpole_MOE_2019a_B.y = 1.0;
    } else {
      /* '<S6>:1:6' */
      cartpole_MOE_2019a_B.y = 2.0;
    }

    /* End of MATLAB Function: '<S4>/LQR switch condition' */
  }

  /* SwitchCase: '<S4>/LQR or swingup' */
  rtPrevAction = cartpole_MOE_2019a_DW.LQRorswingup_ActiveSubsystem;
  rtAction = -1;
  if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
    if (cartpole_MOE_2019a_B.y < 0.0) {
      u0 = ceil(cartpole_MOE_2019a_B.y);
    } else {
      u0 = floor(cartpole_MOE_2019a_B.y);
    }

    if (rtIsNaN(u0) || rtIsInf(u0)) {
      u0 = 0.0;
    } else {
      u0 = fmod(u0, 4.294967296E+9);
    }

    switch (u0 < 0.0 ? -(int32_T)(uint32_T)-u0 : (int32_T)(uint32_T)u0) {
     case 1:
      rtAction = 0;
      break;

     case 2:
      rtAction = 1;
      break;
    }

    cartpole_MOE_2019a_DW.LQRorswingup_ActiveSubsystem = rtAction;
  } else {
    rtAction = cartpole_MOE_2019a_DW.LQRorswingup_ActiveSubsystem;
  }

  if ((rtPrevAction != rtAction) && (rtPrevAction == 1)) {
    /* Disable for SwitchCase: '<S7>/Select controller' */
    cartpole_MOE_2019a_DW.Selectcontroller_ActiveSubsyste = -1;
  }

  switch (rtAction) {
   case 0:
    /* Outputs for IfAction SubSystem: '<S4>/LQR' incorporates:
     *  ActionPort: '<S5>/Action Port'
     */
    /* Gain: '<S5>/Gain1' incorporates:
     *  Integrator: '<S5>/Integrator'
     */
    u0 = cartpole_MOE_2019a_P.Gain1_Gain *
      cartpole_MOE_2019a_X.Integrator_CSTATE;

    /* Saturate: '<S5>/Saturation2' */
    if (u0 > cartpole_MOE_2019a_P.Saturation2_UpperSat) {
      cartpole_MOE_2019a_B.Saturation2 =
        cartpole_MOE_2019a_P.Saturation2_UpperSat;
    } else if (u0 < cartpole_MOE_2019a_P.Saturation2_LowerSat) {
      cartpole_MOE_2019a_B.Saturation2 =
        cartpole_MOE_2019a_P.Saturation2_LowerSat;
    } else {
      cartpole_MOE_2019a_B.Saturation2 = u0;
    }

    /* End of Saturate: '<S5>/Saturation2' */
    if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
    }

    /* Trigonometry: '<S5>/Sin' */
    u0 = sin(cartpole_MOE_2019a_B.Sum);

    /* Sum: '<S5>/Sum1' incorporates:
     *  Gain: '<S5>/Gain3'
     *  Trigonometry: '<S5>/Sin'
     */
    cartpole_MOE_2019a_B.Sum1_e = cartpole_MOE_2019a_P.Gain3_Gain * u0 -
      cartpole_MOE_2019a_B.Kenc;
    if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
    }

    /* Sum: '<S5>/Add' incorporates:
     *  Gain: '<S5>/Gain'
     *  Gain: '<S5>/Gain4'
     *  Gain: '<S5>/Gain5'
     *  Gain: '<S5>/Gain6'
     *  Gain: '<S5>/Gain7'
     *  Sum: '<S5>/Add1'
     *  Trigonometry: '<S5>/Sin'
     */
    u0 = (((cartpole_MOE_2019a_P.Gain4_Gain * cartpole_MOE_2019a_B.Kenc +
            cartpole_MOE_2019a_P.Gain5_Gain * u0) +
           cartpole_MOE_2019a_P.Gain6_Gain *
           cartpole_MOE_2019a_B.DiscreteFilter1) +
          cartpole_MOE_2019a_P.Gain7_Gain * cartpole_MOE_2019a_B.DiscreteFilter)
      * cartpole_MOE_2019a_P.Gain_Gain + cartpole_MOE_2019a_B.Saturation2;

    /* Saturate: '<S5>/Saturation1' */
    if (u0 > cartpole_MOE_2019a_P.Fmax) {
      cartpole_MOE_2019a_B.Merge = cartpole_MOE_2019a_P.Fmax;
    } else if (u0 < -cartpole_MOE_2019a_P.Fmax) {
      cartpole_MOE_2019a_B.Merge = -cartpole_MOE_2019a_P.Fmax;
    } else {
      cartpole_MOE_2019a_B.Merge = u0;
    }

    /* End of Saturate: '<S5>/Saturation1' */

    /* Sum: '<S5>/Sum' incorporates:
     *  Gain: '<S5>/Gain2'
     *  Integrator: '<S5>/Integrator'
     */
    cartpole_MOE_2019a_B.Sum_c = cartpole_MOE_2019a_B.Sum1_e -
      cartpole_MOE_2019a_P.Gain2_Gain * cartpole_MOE_2019a_X.Integrator_CSTATE;
    if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
      srUpdateBC(cartpole_MOE_2019a_DW.LQR_SubsysRanBC);
    }

    /* End of Outputs for SubSystem: '<S4>/LQR' */
    break;

   case 1:
    /* Outputs for IfAction SubSystem: '<S4>/Swingup Control' incorporates:
     *  ActionPort: '<S7>/Action Port'
     */
    /* MATLAB Function: '<S7>/Gating network' incorporates:
     *  Constant: '<S7>/Constant2'
     *  Constant: '<S7>/Constant3'
     *  Constant: '<S7>/Constant4'
     *  Constant: '<S7>/Constant5'
     *  Constant: '<S7>/Constant6'
     *  Constant: '<S7>/Constant7'
     *  SignalConversion: '<S12>/TmpSignal ConversionAt SFunction Inport1'
     */
    /* MATLAB Function 'MOE/Swingup Control/Gating network': '<S12>:1' */
    /* '<S12>:1:3' */
    /* '<S12>:1:4' */
    z1_0[0] = cartpole_MOE_2019a_B.Kenc;
    z1_0[1] = cos(cartpole_MOE_2019a_B.Sum);
    z1_0[2] = sin(cartpole_MOE_2019a_B.Sum);
    z1_0[3] = cartpole_MOE_2019a_B.DiscreteFilter1;
    z1_0[4] = cartpole_MOE_2019a_B.DiscreteFilter;
    for (maxindex = 0; maxindex < 4; maxindex++) {
      u0 = 0.0;
      for (i = 0; i < 5; i++) {
        u0 += cartpole_MOE_2019a_P.binW1[(i << 2) + maxindex] * z1_0[i];
      }

      u0 += cartpole_MOE_2019a_P.binb1[maxindex];
      if (u0 > 0.0) {
        z1[maxindex] = u0;
      } else {
        z1[maxindex] = exp(u0) - 1.0;
      }
    }

    /* '<S12>:1:5' */
    for (maxindex = 0; maxindex < 3; maxindex++) {
      u0 = (((cartpole_MOE_2019a_P.binW2[maxindex + 3] * z1[1] +
              cartpole_MOE_2019a_P.binW2[maxindex] * z1[0]) +
             cartpole_MOE_2019a_P.binW2[maxindex + 6] * z1[2]) +
            cartpole_MOE_2019a_P.binW2[maxindex + 9] * z1[3]) +
        cartpole_MOE_2019a_P.binb2[maxindex];
      if (u0 > 0.0) {
        z2[maxindex] = u0;
      } else {
        z2[maxindex] = exp(u0) - 1.0;
      }
    }

    /* '<S12>:1:6' */
    for (i = 0; i < 3; i++) {
      z3[i] = ((cartpole_MOE_2019a_P.binW3[i + 3] * z2[1] +
                cartpole_MOE_2019a_P.binW3[i] * z2[0]) +
               cartpole_MOE_2019a_P.binW3[i + 6] * z2[2]) +
        cartpole_MOE_2019a_P.binb3[i];
    }

    /* '<S12>:1:7' */
    /* '<S12>:1:12' */
    memset(&cartpole_MOE_2019a_B.pk[0], 0, 9U * sizeof(real_T));

    /* '<S12>:1:13' */
    for (maxindex = 0; maxindex < 3; maxindex++) {
      /* '<S12>:1:13' */
      /* '<S12>:1:14' */
      cartpole_MOE_2019a_B.pk[maxindex] = exp(z3[maxindex]) / ((exp(z3[0]) + exp
        (z3[1])) + exp(z3[2]));
    }

    /* End of MATLAB Function: '<S7>/Gating network' */

    /* MATLAB Function: '<S7>/Argmax' */
    /* MATLAB Function 'MOE/Swingup Control/Argmax': '<S8>:1' */
    /* '<S8>:1:2' */
    maxindex = 0;

    /* '<S8>:1:3' */
    if (cartpole_MOE_2019a_B.pk[1] > cartpole_MOE_2019a_B.pk[0]) {
      /* '<S8>:1:4' */
      /* '<S8>:1:5' */
      maxindex = 1;
    }

    /* '<S8>:1:3' */
    if (cartpole_MOE_2019a_B.pk[2] > cartpole_MOE_2019a_B.pk[maxindex]) {
      /* '<S8>:1:4' */
      /* '<S8>:1:5' */
      maxindex = 2;
    }

    /* '<S8>:1:8' */
    cartpole_MOE_2019a_B.y_e = (real_T)maxindex + 1.0;

    /* End of MATLAB Function: '<S7>/Argmax' */
    if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
    }

    /* SwitchCase: '<S7>/Select controller' */
    rtAction = -1;
    if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
      if (cartpole_MOE_2019a_B.y_e < 0.0) {
        u0 = ceil(cartpole_MOE_2019a_B.y_e);
      } else {
        u0 = floor(cartpole_MOE_2019a_B.y_e);
      }

      if (rtIsNaN(u0) || rtIsInf(u0)) {
        u0 = 0.0;
      } else {
        u0 = fmod(u0, 4.294967296E+9);
      }

      switch (u0 < 0.0 ? -(int32_T)(uint32_T)-u0 : (int32_T)(uint32_T)u0) {
       case 1:
        rtAction = 0;
        break;

       case 2:
        rtAction = 1;
        break;

       case 3:
        rtAction = 2;
        break;
      }

      cartpole_MOE_2019a_DW.Selectcontroller_ActiveSubsyste = rtAction;
    } else {
      rtAction = cartpole_MOE_2019a_DW.Selectcontroller_ActiveSubsyste;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S7>/Controller 1' incorporates:
       *  ActionPort: '<S9>/Action Port'
       */
      /* MATLAB Function: '<S9>/MATLAB Function' incorporates:
       *  Constant: '<S9>/Constant2'
       *  Constant: '<S9>/Constant3'
       *  Constant: '<S9>/Constant4'
       *  Constant: '<S9>/Constant5'
       *  Constant: '<S9>/Constant6'
       *  Constant: '<S9>/Constant7'
       */
      cartpole_MOE_201_MATLABFunction(cartpole_MOE_2019a_B.Kenc,
        cartpole_MOE_2019a_B.Sum, cartpole_MOE_2019a_B.DiscreteFilter1,
        cartpole_MOE_2019a_B.DiscreteFilter, cartpole_MOE_2019a_P.control1W1,
        cartpole_MOE_2019a_P.control1W2, cartpole_MOE_2019a_P.control1W3,
        cartpole_MOE_2019a_P.control1b1, cartpole_MOE_2019a_P.control1b2,
        cartpole_MOE_2019a_P.control1b3, &cartpole_MOE_2019a_B.sf_MATLABFunction);

      /* SignalConversion: '<S9>/OutportBufferForu' */
      cartpole_MOE_2019a_B.Merge_f = cartpole_MOE_2019a_B.sf_MATLABFunction.y;
      if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
        srUpdateBC(cartpole_MOE_2019a_DW.Controller1_SubsysRanBC);
      }

      /* End of Outputs for SubSystem: '<S7>/Controller 1' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S7>/Controller 2' incorporates:
       *  ActionPort: '<S10>/Action Port'
       */
      /* MATLAB Function: '<S10>/MATLAB Function' incorporates:
       *  Constant: '<S10>/Constant2'
       *  Constant: '<S10>/Constant3'
       *  Constant: '<S10>/Constant4'
       *  Constant: '<S10>/Constant5'
       *  Constant: '<S10>/Constant6'
       *  Constant: '<S10>/Constant7'
       */
      cartpole_MOE_201_MATLABFunction(cartpole_MOE_2019a_B.Kenc,
        cartpole_MOE_2019a_B.Sum, cartpole_MOE_2019a_B.DiscreteFilter1,
        cartpole_MOE_2019a_B.DiscreteFilter, cartpole_MOE_2019a_P.control2W1,
        cartpole_MOE_2019a_P.control2W2, cartpole_MOE_2019a_P.control2W3,
        cartpole_MOE_2019a_P.control2b1, cartpole_MOE_2019a_P.control2b2,
        cartpole_MOE_2019a_P.control2b3,
        &cartpole_MOE_2019a_B.sf_MATLABFunction_m);

      /* SignalConversion: '<S10>/OutportBufferForu' */
      cartpole_MOE_2019a_B.Merge_f = cartpole_MOE_2019a_B.sf_MATLABFunction_m.y;
      if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
        srUpdateBC(cartpole_MOE_2019a_DW.Controller2_SubsysRanBC);
      }

      /* End of Outputs for SubSystem: '<S7>/Controller 2' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S7>/Controller 3' incorporates:
       *  ActionPort: '<S11>/Action Port'
       */
      /* MATLAB Function: '<S11>/MATLAB Function' incorporates:
       *  Constant: '<S11>/Constant2'
       *  Constant: '<S11>/Constant3'
       *  Constant: '<S11>/Constant4'
       *  Constant: '<S11>/Constant5'
       *  Constant: '<S11>/Constant6'
       *  Constant: '<S11>/Constant7'
       */
      cartpole_MOE_201_MATLABFunction(cartpole_MOE_2019a_B.Kenc,
        cartpole_MOE_2019a_B.Sum, cartpole_MOE_2019a_B.DiscreteFilter1,
        cartpole_MOE_2019a_B.DiscreteFilter, cartpole_MOE_2019a_P.control3W1,
        cartpole_MOE_2019a_P.control3W2, cartpole_MOE_2019a_P.control3W3,
        cartpole_MOE_2019a_P.control3b1, cartpole_MOE_2019a_P.control3b2,
        cartpole_MOE_2019a_P.control3b3,
        &cartpole_MOE_2019a_B.sf_MATLABFunction_j);

      /* SignalConversion: '<S11>/OutportBufferForu' */
      cartpole_MOE_2019a_B.Merge_f = cartpole_MOE_2019a_B.sf_MATLABFunction_j.y;
      if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
        srUpdateBC(cartpole_MOE_2019a_DW.Controller3_SubsysRanBC);
      }

      /* End of Outputs for SubSystem: '<S7>/Controller 3' */
      break;
    }

    /* End of SwitchCase: '<S7>/Select controller' */

    /* Gain: '<S7>/On or off2' */
    cartpole_MOE_2019a_B.Merge = cartpole_MOE_2019a_P.Onoroff2_Gain *
      cartpole_MOE_2019a_B.Merge_f;
    if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
      srUpdateBC(cartpole_MOE_2019a_DW.SwingupControl_SubsysRanBC);
    }

    /* End of Outputs for SubSystem: '<S4>/Swingup Control' */
    break;
  }

  /* End of SwitchCase: '<S4>/LQR or swingup' */

  /* Saturate: '<S4>/Saturation1' */
  if (cartpole_MOE_2019a_B.Merge > cartpole_MOE_2019a_P.Fmax) {
    cartpole_MOE_2019a_B.Saturation1 = cartpole_MOE_2019a_P.Fmax;
  } else if (cartpole_MOE_2019a_B.Merge < -cartpole_MOE_2019a_P.Fmax) {
    cartpole_MOE_2019a_B.Saturation1 = -cartpole_MOE_2019a_P.Fmax;
  } else {
    cartpole_MOE_2019a_B.Saturation1 = cartpole_MOE_2019a_B.Merge;
  }

  /* End of Saturate: '<S4>/Saturation1' */
  if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
    /* Gain: '<Root>/On or off1' */
    cartpole_MOE_2019a_B.Onoroff1 = cartpole_MOE_2019a_P.Onoroff1_Gain *
      cartpole_MOE_2019a_B.DiscreteFilter1;

    /* Gain: '<S3>/Gain6' */
    cartpole_MOE_2019a_B.Gain6 = cartpole_MOE_2019a_P.rg *
      cartpole_MOE_2019a_P.Kt / cartpole_MOE_2019a_P.rm *
      cartpole_MOE_2019a_B.DiscreteFilter1;
  }

  /* Sum: '<S3>/Add' incorporates:
   *  Gain: '<S3>/Gain5'
   *  Sum: '<Root>/Sum2'
   */
  u0 = cartpole_MOE_2019a_P.R * cartpole_MOE_2019a_P.rm /
    (cartpole_MOE_2019a_P.rg * cartpole_MOE_2019a_P.Kt) *
    (cartpole_MOE_2019a_B.Saturation1 + cartpole_MOE_2019a_B.Onoroff1) +
    cartpole_MOE_2019a_B.Gain6;

  /* Saturate: '<S3>/Saturation1' */
  if (u0 > cartpole_MOE_2019a_P.Vmax) {
    cartpole_MOE_2019a_B.Saturation1_k = cartpole_MOE_2019a_P.Vmax;
  } else if (u0 < -cartpole_MOE_2019a_P.Vmax) {
    cartpole_MOE_2019a_B.Saturation1_k = -cartpole_MOE_2019a_P.Vmax;
  } else {
    cartpole_MOE_2019a_B.Saturation1_k = u0;
  }

  /* End of Saturate: '<S3>/Saturation1' */

  /* Gain: '<Root>/On or off' */
  cartpole_MOE_2019a_B.Onoroff = cartpole_MOE_2019a_P.Onoroff_Gain *
    cartpole_MOE_2019a_B.Saturation1_k;
  if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
    /* S-Function (hil_write_analog_block): '<Root>/HIL Write Analog' */

    /* S-Function Block: cartpole_MOE_2019a/HIL Write Analog (hil_write_analog_block) */
    {
      t_error result;
      result = hil_write_analog(cartpole_MOE_2019a_DW.HILInitialize_Card,
        &cartpole_MOE_2019a_P.HILWriteAnalog_channels, 1,
        &cartpole_MOE_2019a_B.Onoroff);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
      }
    }

    /* SignalConversion: '<Root>/TmpSignal ConversionAtTo FileInport1' */
    rtb_TmpSignalConversionAtToFile[0] = cartpole_MOE_2019a_B.Saturation1_k;
    rtb_TmpSignalConversionAtToFile[1] = cartpole_MOE_2019a_B.Kenc;
    rtb_TmpSignalConversionAtToFile[2] = rtb_upiNenc;
    rtb_TmpSignalConversionAtToFile[3] = cartpole_MOE_2019a_B.DiscreteFilter1;
    rtb_TmpSignalConversionAtToFile[4] = cartpole_MOE_2019a_B.DiscreteFilter;
    rtb_TmpSignalConversionAtToFile[5] = cartpole_MOE_2019a_B.Saturation1;

    /* ToFile: '<Root>/To File' */
    {
      if (!(++cartpole_MOE_2019a_DW.ToFile_IWORK.Decimation % 1) &&
          (cartpole_MOE_2019a_DW.ToFile_IWORK.Count * (6 + 1)) + 1 < 100000000 )
      {
        FILE *fp = (FILE *) cartpole_MOE_2019a_DW.ToFile_PWORK.FilePtr;
        if (fp != (NULL)) {
          real_T u[6 + 1];
          cartpole_MOE_2019a_DW.ToFile_IWORK.Decimation = 0;
          u[0] = cartpole_MOE_2019a_M->Timing.t[1];
          u[1] = rtb_TmpSignalConversionAtToFile[0];
          u[2] = rtb_TmpSignalConversionAtToFile[1];
          u[3] = rtb_TmpSignalConversionAtToFile[2];
          u[4] = rtb_TmpSignalConversionAtToFile[3];
          u[5] = rtb_TmpSignalConversionAtToFile[4];
          u[6] = rtb_TmpSignalConversionAtToFile[5];
          if (fwrite(u, sizeof(real_T), 6 + 1, fp) != 6 + 1) {
            rtmSetErrorStatus(cartpole_MOE_2019a_M,
                              "Error writing to MAT-file cartpole_MOE.mat");
            return;
          }

          if (((++cartpole_MOE_2019a_DW.ToFile_IWORK.Count) * (6 + 1))+1 >=
              100000000) {
            (void)fprintf(stdout,
                          "*** The ToFile block will stop logging data before\n"
                          "    the simulation has ended, because it has reached\n"
                          "    the maximum number of elements (100000000)\n"
                          "    allowed in MAT-file cartpole_MOE.mat.\n");
          }
        }
      }
    }

    /* Gain: '<Root>/360//Nenc' */
    cartpole_MOE_2019a_B.u60Nenc = 360.0 / cartpole_MOE_2019a_P.Nenc *
      rtb_HILReadEncoderTimebase_o2;
  }
}

/* Model update function */
void cartpole_MOE_2019a_update(void)
{
  if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
    /* Update for DiscreteFilter: '<S2>/Discrete Filter' */
    cartpole_MOE_2019a_DW.DiscreteFilter_states =
      cartpole_MOE_2019a_DW.DiscreteFilter_tmp;

    /* Update for DiscreteFilter: '<Root>/Discrete Filter1' */
    cartpole_MOE_2019a_DW.DiscreteFilter1_states[1] =
      cartpole_MOE_2019a_DW.DiscreteFilter1_states[0];
    cartpole_MOE_2019a_DW.DiscreteFilter1_states[0] =
      cartpole_MOE_2019a_DW.DiscreteFilter1_tmp;

    /* Update for DiscreteFilter: '<S1>/Discrete Filter' */
    cartpole_MOE_2019a_DW.DiscreteFilter_states_p =
      cartpole_MOE_2019a_DW.DiscreteFilter_tmp_c;

    /* Update for DiscreteFilter: '<Root>/Discrete Filter' */
    cartpole_MOE_2019a_DW.DiscreteFilter_states_a[1] =
      cartpole_MOE_2019a_DW.DiscreteFilter_states_a[0];
    cartpole_MOE_2019a_DW.DiscreteFilter_states_a[0] =
      cartpole_MOE_2019a_DW.DiscreteFilter_tmp_a;
  }

  if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
    rt_ertODEUpdateContinuousStates(&cartpole_MOE_2019a_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++cartpole_MOE_2019a_M->Timing.clockTick0)) {
    ++cartpole_MOE_2019a_M->Timing.clockTickH0;
  }

  cartpole_MOE_2019a_M->Timing.t[0] = rtsiGetSolverStopTime
    (&cartpole_MOE_2019a_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++cartpole_MOE_2019a_M->Timing.clockTick1)) {
      ++cartpole_MOE_2019a_M->Timing.clockTickH1;
    }

    cartpole_MOE_2019a_M->Timing.t[1] = cartpole_MOE_2019a_M->Timing.clockTick1 *
      cartpole_MOE_2019a_M->Timing.stepSize1 +
      cartpole_MOE_2019a_M->Timing.clockTickH1 *
      cartpole_MOE_2019a_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void cartpole_MOE_2019a_derivatives(void)
{
  XDot_cartpole_MOE_2019a_T *_rtXdot;
  _rtXdot = ((XDot_cartpole_MOE_2019a_T *) cartpole_MOE_2019a_M->derivs);

  /* Derivatives for SwitchCase: '<S4>/LQR or swingup' */
  ((XDot_cartpole_MOE_2019a_T *) cartpole_MOE_2019a_M->derivs)
    ->Integrator_CSTATE = 0.0;
  if (cartpole_MOE_2019a_DW.LQRorswingup_ActiveSubsystem == 0) {
    /* Derivatives for IfAction SubSystem: '<S4>/LQR' incorporates:
     *  ActionPort: '<S5>/Action Port'
     */
    /* Derivatives for Integrator: '<S5>/Integrator' */
    _rtXdot->Integrator_CSTATE = cartpole_MOE_2019a_B.Sum_c;

    /* End of Derivatives for SubSystem: '<S4>/LQR' */
  }

  /* End of Derivatives for SwitchCase: '<S4>/LQR or swingup' */
}

/* Model initialize function */
void cartpole_MOE_2019a_initialize(void)
{
  /* Start for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: cartpole_MOE_2019a/HIL Initialize (hil_initialize_block) */
  {
    t_int result;
    t_boolean is_switching;
    result = hil_open("q2_usb", "0", &cartpole_MOE_2019a_DW.HILInitialize_Card);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
      return;
    }

    is_switching = false;
    result = hil_set_card_specific_options
      (cartpole_MOE_2019a_DW.HILInitialize_Card,
       "d0=digital;d1=digital;led=auto;update_rate=normal;decimation=1", 63);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
      return;
    }

    result = hil_watchdog_clear(cartpole_MOE_2019a_DW.HILInitialize_Card);
    if (result < 0 && result != -QERR_HIL_WATCHDOG_CLEAR) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
      return;
    }

    if ((cartpole_MOE_2019a_P.HILInitialize_AIPStart && !is_switching) ||
        (cartpole_MOE_2019a_P.HILInitialize_AIPEnter && is_switching)) {
      cartpole_MOE_2019a_DW.HILInitialize_AIMinimums[0] =
        (cartpole_MOE_2019a_P.HILInitialize_AILow);
      cartpole_MOE_2019a_DW.HILInitialize_AIMinimums[1] =
        (cartpole_MOE_2019a_P.HILInitialize_AILow);
      cartpole_MOE_2019a_DW.HILInitialize_AIMaximums[0] =
        cartpole_MOE_2019a_P.HILInitialize_AIHigh;
      cartpole_MOE_2019a_DW.HILInitialize_AIMaximums[1] =
        cartpole_MOE_2019a_P.HILInitialize_AIHigh;
      result = hil_set_analog_input_ranges
        (cartpole_MOE_2019a_DW.HILInitialize_Card,
         cartpole_MOE_2019a_P.HILInitialize_AIChannels, 2U,
         &cartpole_MOE_2019a_DW.HILInitialize_AIMinimums[0],
         &cartpole_MOE_2019a_DW.HILInitialize_AIMaximums[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
        return;
      }
    }

    if ((cartpole_MOE_2019a_P.HILInitialize_AOPStart && !is_switching) ||
        (cartpole_MOE_2019a_P.HILInitialize_AOPEnter && is_switching)) {
      cartpole_MOE_2019a_DW.HILInitialize_AOMinimums[0] =
        (cartpole_MOE_2019a_P.HILInitialize_AOLow);
      cartpole_MOE_2019a_DW.HILInitialize_AOMinimums[1] =
        (cartpole_MOE_2019a_P.HILInitialize_AOLow);
      cartpole_MOE_2019a_DW.HILInitialize_AOMaximums[0] =
        cartpole_MOE_2019a_P.HILInitialize_AOHigh;
      cartpole_MOE_2019a_DW.HILInitialize_AOMaximums[1] =
        cartpole_MOE_2019a_P.HILInitialize_AOHigh;
      result = hil_set_analog_output_ranges
        (cartpole_MOE_2019a_DW.HILInitialize_Card,
         cartpole_MOE_2019a_P.HILInitialize_AOChannels, 2U,
         &cartpole_MOE_2019a_DW.HILInitialize_AOMinimums[0],
         &cartpole_MOE_2019a_DW.HILInitialize_AOMaximums[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
        return;
      }
    }

    if ((cartpole_MOE_2019a_P.HILInitialize_AOStart && !is_switching) ||
        (cartpole_MOE_2019a_P.HILInitialize_AOEnter && is_switching)) {
      cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[0] =
        cartpole_MOE_2019a_P.HILInitialize_AOInitial;
      cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[1] =
        cartpole_MOE_2019a_P.HILInitialize_AOInitial;
      result = hil_write_analog(cartpole_MOE_2019a_DW.HILInitialize_Card,
        cartpole_MOE_2019a_P.HILInitialize_AOChannels, 2U,
        &cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
        return;
      }
    }

    if (cartpole_MOE_2019a_P.HILInitialize_AOReset) {
      cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[0] =
        cartpole_MOE_2019a_P.HILInitialize_AOWatchdog;
      cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[1] =
        cartpole_MOE_2019a_P.HILInitialize_AOWatchdog;
      result = hil_watchdog_set_analog_expiration_state
        (cartpole_MOE_2019a_DW.HILInitialize_Card,
         cartpole_MOE_2019a_P.HILInitialize_AOChannels, 2U,
         &cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
        return;
      }
    }

    if ((cartpole_MOE_2019a_P.HILInitialize_EIPStart && !is_switching) ||
        (cartpole_MOE_2019a_P.HILInitialize_EIPEnter && is_switching)) {
      cartpole_MOE_2019a_DW.HILInitialize_QuadratureModes[0] =
        cartpole_MOE_2019a_P.HILInitialize_EIQuadrature;
      cartpole_MOE_2019a_DW.HILInitialize_QuadratureModes[1] =
        cartpole_MOE_2019a_P.HILInitialize_EIQuadrature;
      result = hil_set_encoder_quadrature_mode
        (cartpole_MOE_2019a_DW.HILInitialize_Card,
         cartpole_MOE_2019a_P.HILInitialize_EIChannels, 2U,
         (t_encoder_quadrature_mode *)
         &cartpole_MOE_2019a_DW.HILInitialize_QuadratureModes[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
        return;
      }
    }

    if ((cartpole_MOE_2019a_P.HILInitialize_EIStart && !is_switching) ||
        (cartpole_MOE_2019a_P.HILInitialize_EIEnter && is_switching)) {
      cartpole_MOE_2019a_DW.HILInitialize_InitialEICounts[0] =
        cartpole_MOE_2019a_P.HILInitialize_EIInitial;
      cartpole_MOE_2019a_DW.HILInitialize_InitialEICounts[1] =
        cartpole_MOE_2019a_P.HILInitialize_EIInitial;
      result = hil_set_encoder_counts(cartpole_MOE_2019a_DW.HILInitialize_Card,
        cartpole_MOE_2019a_P.HILInitialize_EIChannels, 2U,
        &cartpole_MOE_2019a_DW.HILInitialize_InitialEICounts[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
        return;
      }
    }
  }

  /* Start for S-Function (hil_read_encoder_timebase_block): '<Root>/HIL Read Encoder Timebase' */

  /* S-Function Block: cartpole_MOE_2019a/HIL Read Encoder Timebase (hil_read_encoder_timebase_block) */
  {
    t_error result;
    result = hil_task_create_encoder_reader
      (cartpole_MOE_2019a_DW.HILInitialize_Card,
       cartpole_MOE_2019a_P.HILReadEncoderTimebase_samples_,
       cartpole_MOE_2019a_P.HILReadEncoderTimebase_channels, 2,
       &cartpole_MOE_2019a_DW.HILReadEncoderTimebase_Task);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
    }
  }

  /* Start for SwitchCase: '<S4>/LQR or swingup' */
  cartpole_MOE_2019a_DW.LQRorswingup_ActiveSubsystem = -1;

  /* Start for SwitchCase: '<S7>/Select controller' */
  cartpole_MOE_2019a_DW.Selectcontroller_ActiveSubsyste = -1;

  /* End of Start for SubSystem: '<S4>/Swingup Control' */
  /* Start for ToFile: '<Root>/To File' */
  {
    FILE *fp = (NULL);
    char fileName[509] = "cartpole_MOE.mat";
    if ((fp = fopen(fileName, "wb")) == (NULL)) {
      rtmSetErrorStatus(cartpole_MOE_2019a_M,
                        "Error creating .mat file cartpole_MOE.mat");
      return;
    }

    if (rt_WriteMat4FileHeader(fp, 6 + 1, 0, "cart_data")) {
      rtmSetErrorStatus(cartpole_MOE_2019a_M,
                        "Error writing mat file header to file cartpole_MOE.mat");
      return;
    }

    cartpole_MOE_2019a_DW.ToFile_IWORK.Count = 0;
    cartpole_MOE_2019a_DW.ToFile_IWORK.Decimation = -1;
    cartpole_MOE_2019a_DW.ToFile_PWORK.FilePtr = fp;
  }

  /* InitializeConditions for DiscreteFilter: '<S2>/Discrete Filter' */
  cartpole_MOE_2019a_DW.DiscreteFilter_states =
    cartpole_MOE_2019a_P.DiscreteFilter_InitialStates;

  /* InitializeConditions for DiscreteFilter: '<S1>/Discrete Filter' */
  cartpole_MOE_2019a_DW.DiscreteFilter_states_p =
    cartpole_MOE_2019a_P.DiscreteFilter_InitialStates_g;

  /* InitializeConditions for DiscreteFilter: '<Root>/Discrete Filter1' */
  cartpole_MOE_2019a_DW.DiscreteFilter1_states[0] =
    cartpole_MOE_2019a_P.DiscreteFilter1_InitialStates;

  /* InitializeConditions for DiscreteFilter: '<Root>/Discrete Filter' */
  cartpole_MOE_2019a_DW.DiscreteFilter_states_a[0] =
    cartpole_MOE_2019a_P.DiscreteFilter_InitialStates_h;

  /* InitializeConditions for DiscreteFilter: '<Root>/Discrete Filter1' */
  cartpole_MOE_2019a_DW.DiscreteFilter1_states[1] =
    cartpole_MOE_2019a_P.DiscreteFilter1_InitialStates;

  /* InitializeConditions for DiscreteFilter: '<Root>/Discrete Filter' */
  cartpole_MOE_2019a_DW.DiscreteFilter_states_a[1] =
    cartpole_MOE_2019a_P.DiscreteFilter_InitialStates_h;

  /* SystemInitialize for IfAction SubSystem: '<S4>/LQR' */
  /* InitializeConditions for Integrator: '<S5>/Integrator' */
  cartpole_MOE_2019a_X.Integrator_CSTATE = cartpole_MOE_2019a_P.Integrator_IC;

  /* End of SystemInitialize for SubSystem: '<S4>/LQR' */

  /* SystemInitialize for IfAction SubSystem: '<S4>/Swingup Control' */
  /* SystemInitialize for Merge: '<S7>/Merge' */
  cartpole_MOE_2019a_B.Merge_f = cartpole_MOE_2019a_P.Merge_InitialOutput;

  /* End of SystemInitialize for SubSystem: '<S4>/Swingup Control' */

  /* SystemInitialize for Merge: '<S4>/Merge' */
  cartpole_MOE_2019a_B.Merge = cartpole_MOE_2019a_P.Merge_InitialOutput_g;
}

/* Model terminate function */
void cartpole_MOE_2019a_terminate(void)
{
  /* Terminate for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: cartpole_MOE_2019a/HIL Initialize (hil_initialize_block) */
  {
    t_boolean is_switching;
    t_int result;
    t_uint32 num_final_analog_outputs = 0;
    hil_task_stop_all(cartpole_MOE_2019a_DW.HILInitialize_Card);
    hil_monitor_stop_all(cartpole_MOE_2019a_DW.HILInitialize_Card);
    is_switching = false;
    if ((cartpole_MOE_2019a_P.HILInitialize_AOTerminate && !is_switching) ||
        (cartpole_MOE_2019a_P.HILInitialize_AOExit && is_switching)) {
      cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[0] =
        cartpole_MOE_2019a_P.HILInitialize_AOFinal;
      cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[1] =
        cartpole_MOE_2019a_P.HILInitialize_AOFinal;
      num_final_analog_outputs = 2U;
    }

    if (num_final_analog_outputs > 0) {
      result = hil_write_analog(cartpole_MOE_2019a_DW.HILInitialize_Card,
        cartpole_MOE_2019a_P.HILInitialize_AOChannels, num_final_analog_outputs,
        &cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
      }
    }

    hil_task_delete_all(cartpole_MOE_2019a_DW.HILInitialize_Card);
    hil_monitor_delete_all(cartpole_MOE_2019a_DW.HILInitialize_Card);
    hil_close(cartpole_MOE_2019a_DW.HILInitialize_Card);
    cartpole_MOE_2019a_DW.HILInitialize_Card = NULL;
  }

  /* Terminate for ToFile: '<Root>/To File' */
  {
    FILE *fp = (FILE *) cartpole_MOE_2019a_DW.ToFile_PWORK.FilePtr;
    if (fp != (NULL)) {
      char fileName[509] = "cartpole_MOE.mat";
      if (fclose(fp) == EOF) {
        rtmSetErrorStatus(cartpole_MOE_2019a_M,
                          "Error closing MAT-file cartpole_MOE.mat");
        return;
      }

      if ((fp = fopen(fileName, "r+b")) == (NULL)) {
        rtmSetErrorStatus(cartpole_MOE_2019a_M,
                          "Error reopening MAT-file cartpole_MOE.mat");
        return;
      }

      if (rt_WriteMat4FileHeader(fp, 6 + 1,
           cartpole_MOE_2019a_DW.ToFile_IWORK.Count, "cart_data")) {
        rtmSetErrorStatus(cartpole_MOE_2019a_M,
                          "Error writing header for cart_data to MAT-file cartpole_MOE.mat");
      }

      if (fclose(fp) == EOF) {
        rtmSetErrorStatus(cartpole_MOE_2019a_M,
                          "Error closing MAT-file cartpole_MOE.mat");
        return;
      }

      cartpole_MOE_2019a_DW.ToFile_PWORK.FilePtr = (NULL);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  cartpole_MOE_2019a_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  cartpole_MOE_2019a_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  cartpole_MOE_2019a_initialize();
}

void MdlTerminate(void)
{
  cartpole_MOE_2019a_terminate();
}

/* Registration function */
RT_MODEL_cartpole_MOE_2019a_T *cartpole_MOE_2019a(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)cartpole_MOE_2019a_M, 0,
                sizeof(RT_MODEL_cartpole_MOE_2019a_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&cartpole_MOE_2019a_M->solverInfo,
                          &cartpole_MOE_2019a_M->Timing.simTimeStep);
    rtsiSetTPtr(&cartpole_MOE_2019a_M->solverInfo, &rtmGetTPtr
                (cartpole_MOE_2019a_M));
    rtsiSetStepSizePtr(&cartpole_MOE_2019a_M->solverInfo,
                       &cartpole_MOE_2019a_M->Timing.stepSize0);
    rtsiSetdXPtr(&cartpole_MOE_2019a_M->solverInfo,
                 &cartpole_MOE_2019a_M->derivs);
    rtsiSetContStatesPtr(&cartpole_MOE_2019a_M->solverInfo, (real_T **)
                         &cartpole_MOE_2019a_M->contStates);
    rtsiSetNumContStatesPtr(&cartpole_MOE_2019a_M->solverInfo,
      &cartpole_MOE_2019a_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&cartpole_MOE_2019a_M->solverInfo,
      &cartpole_MOE_2019a_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&cartpole_MOE_2019a_M->solverInfo,
      &cartpole_MOE_2019a_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&cartpole_MOE_2019a_M->solverInfo,
      &cartpole_MOE_2019a_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&cartpole_MOE_2019a_M->solverInfo, (&rtmGetErrorStatus
      (cartpole_MOE_2019a_M)));
    rtsiSetRTModelPtr(&cartpole_MOE_2019a_M->solverInfo, cartpole_MOE_2019a_M);
  }

  rtsiSetSimTimeStep(&cartpole_MOE_2019a_M->solverInfo, MAJOR_TIME_STEP);
  cartpole_MOE_2019a_M->intgData.f[0] = cartpole_MOE_2019a_M->odeF[0];
  cartpole_MOE_2019a_M->contStates = ((real_T *) &cartpole_MOE_2019a_X);
  rtsiSetSolverData(&cartpole_MOE_2019a_M->solverInfo, (void *)
                    &cartpole_MOE_2019a_M->intgData);
  rtsiSetSolverName(&cartpole_MOE_2019a_M->solverInfo,"ode1");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = cartpole_MOE_2019a_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    cartpole_MOE_2019a_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    cartpole_MOE_2019a_M->Timing.sampleTimes =
      (&cartpole_MOE_2019a_M->Timing.sampleTimesArray[0]);
    cartpole_MOE_2019a_M->Timing.offsetTimes =
      (&cartpole_MOE_2019a_M->Timing.offsetTimesArray[0]);

    /* task periods */
    cartpole_MOE_2019a_M->Timing.sampleTimes[0] = (0.0);
    cartpole_MOE_2019a_M->Timing.sampleTimes[1] = (0.001);

    /* task offsets */
    cartpole_MOE_2019a_M->Timing.offsetTimes[0] = (0.0);
    cartpole_MOE_2019a_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(cartpole_MOE_2019a_M, &cartpole_MOE_2019a_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = cartpole_MOE_2019a_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    cartpole_MOE_2019a_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(cartpole_MOE_2019a_M, -1);
  cartpole_MOE_2019a_M->Timing.stepSize0 = 0.001;
  cartpole_MOE_2019a_M->Timing.stepSize1 = 0.001;

  /* External mode info */
  cartpole_MOE_2019a_M->Sizes.checksums[0] = (544088241U);
  cartpole_MOE_2019a_M->Sizes.checksums[1] = (3728286217U);
  cartpole_MOE_2019a_M->Sizes.checksums[2] = (2885890186U);
  cartpole_MOE_2019a_M->Sizes.checksums[3] = (3830767550U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[12];
    cartpole_MOE_2019a_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = (sysRanDType *)&cartpole_MOE_2019a_DW.LQR_SubsysRanBC;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = (sysRanDType *)
      &cartpole_MOE_2019a_DW.SwingupControl_SubsysRanBC;
    systemRan[4] = (sysRanDType *)&cartpole_MOE_2019a_DW.Controller1_SubsysRanBC;
    systemRan[5] = (sysRanDType *)&cartpole_MOE_2019a_DW.Controller1_SubsysRanBC;
    systemRan[6] = (sysRanDType *)&cartpole_MOE_2019a_DW.Controller2_SubsysRanBC;
    systemRan[7] = (sysRanDType *)&cartpole_MOE_2019a_DW.Controller2_SubsysRanBC;
    systemRan[8] = (sysRanDType *)&cartpole_MOE_2019a_DW.Controller3_SubsysRanBC;
    systemRan[9] = (sysRanDType *)&cartpole_MOE_2019a_DW.Controller3_SubsysRanBC;
    systemRan[10] = (sysRanDType *)
      &cartpole_MOE_2019a_DW.SwingupControl_SubsysRanBC;
    systemRan[11] = (sysRanDType *)
      &cartpole_MOE_2019a_DW.SwingupControl_SubsysRanBC;
    rteiSetModelMappingInfoPtr(cartpole_MOE_2019a_M->extModeInfo,
      &cartpole_MOE_2019a_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(cartpole_MOE_2019a_M->extModeInfo,
                        cartpole_MOE_2019a_M->Sizes.checksums);
    rteiSetTPtr(cartpole_MOE_2019a_M->extModeInfo, rtmGetTPtr
                (cartpole_MOE_2019a_M));
  }

  cartpole_MOE_2019a_M->solverInfoPtr = (&cartpole_MOE_2019a_M->solverInfo);
  cartpole_MOE_2019a_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&cartpole_MOE_2019a_M->solverInfo, 0.001);
  rtsiSetSolverMode(&cartpole_MOE_2019a_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  cartpole_MOE_2019a_M->blockIO = ((void *) &cartpole_MOE_2019a_B);
  (void) memset(((void *) &cartpole_MOE_2019a_B), 0,
                sizeof(B_cartpole_MOE_2019a_T));

  /* parameters */
  cartpole_MOE_2019a_M->defaultParam = ((real_T *)&cartpole_MOE_2019a_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &cartpole_MOE_2019a_X;
    cartpole_MOE_2019a_M->contStates = (x);
    (void) memset((void *)&cartpole_MOE_2019a_X, 0,
                  sizeof(X_cartpole_MOE_2019a_T));
  }

  /* states (dwork) */
  cartpole_MOE_2019a_M->dwork = ((void *) &cartpole_MOE_2019a_DW);
  (void) memset((void *)&cartpole_MOE_2019a_DW, 0,
                sizeof(DW_cartpole_MOE_2019a_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    cartpole_MOE_2019a_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 16;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  cartpole_MOE_2019a_M->Sizes.numContStates = (1);/* Number of continuous states */
  cartpole_MOE_2019a_M->Sizes.numPeriodicContStates = (0);
                                      /* Number of periodic continuous states */
  cartpole_MOE_2019a_M->Sizes.numY = (0);/* Number of model outputs */
  cartpole_MOE_2019a_M->Sizes.numU = (0);/* Number of model inputs */
  cartpole_MOE_2019a_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  cartpole_MOE_2019a_M->Sizes.numSampTimes = (2);/* Number of sample times */
  cartpole_MOE_2019a_M->Sizes.numBlocks = (104);/* Number of blocks */
  cartpole_MOE_2019a_M->Sizes.numBlockIO = (24);/* Number of block outputs */
  cartpole_MOE_2019a_M->Sizes.numBlockPrms = (491);/* Sum of parameter "widths" */
  return cartpole_MOE_2019a_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
