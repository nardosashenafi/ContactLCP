/*
 * cartpole_MOE_2019a_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "cartpole_MOE_2019a".
 *
 * Model version              : 1.21
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C source code generated on : Wed Feb  8 15:27:21 2023
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "cartpole_MOE_2019a.h"
#include "cartpole_MOE_2019a_private.h"

/* Block parameters (default storage) */
P_cartpole_MOE_2019a_T cartpole_MOE_2019a_P = {
  /* Variable: Fmax
   * Referenced by:
   *   '<S4>/Saturation1'
   *   '<S5>/Saturation1'
   */
  4.5,

  /* Variable: Kt
   * Referenced by:
   *   '<S3>/Gain5'
   *   '<S3>/Gain6'
   */
  0.00767,

  /* Variable: Nenc
   * Referenced by:
   *   '<Root>/2pi//Nenc'
   *   '<Root>/360//Nenc'
   *   '<Root>/Kenc'
   */
  4096.0,

  /* Variable: R
   * Referenced by: '<S3>/Gain5'
   */
  2.6,

  /* Variable: T
   * Referenced by:
   *   '<S1>/Gain3'
   *   '<S2>/Gain3'
   */
  0.001,

  /* Variable: Vmax
   * Referenced by: '<S3>/Saturation1'
   */
  7.0,

  /* Variable: af
   * Referenced by:
   *   '<Root>/Discrete Filter'
   *   '<Root>/Discrete Filter1'
   */
  { 1.0, -1.8226949251963083, 0.83718165125602284 },

  /* Variable: bf
   * Referenced by:
   *   '<Root>/Discrete Filter'
   *   '<Root>/Discrete Filter1'
   */
  { 0.003621681514928643, 0.007243363029857286, 0.003621681514928643 },

  /* Variable: binW1
   * Referenced by: '<S7>/Constant2'
   */
  { 0.057435381310887643, 0.60952006119241142, 0.010599198966293735,
    0.55580039087553312, -0.59282963468418237, 0.798693856841798,
    0.45330836700941757, -0.69275623630138428, -0.79860017003170347,
    0.66611189527775094, 0.0910378808964638, -0.15644787296470264,
    -0.1563613270855678, -0.98306862622609159, 0.87633819624447951,
    -1.0533296902013554, 0.64809858757173744, -0.80534005896602368,
    -0.84444323967139168, 1.0577582567703863 },

  /* Variable: binW2
   * Referenced by: '<S7>/Constant3'
   */
  { 0.42427764573193211, -1.2050873327375493, -0.97732382338369128,
    -0.47325899185642406, 1.2879445548491317, 2.10291934200629,
    -1.2082915123080791, 1.2124736494729986, 1.3085143244924902,
    1.1933363290058834, -0.054804438073274273, -1.6394151770834486 },

  /* Variable: binW3
   * Referenced by: '<S7>/Constant4'
   */
  { -0.74211372750478555, -0.60312642984042086, 1.3231699040468414,
    0.54301892414173891, -0.8989534507887682, -0.97490998661391648,
    0.39036656393288283, -0.48872324389505117, -0.72816416073180656 },

  /* Variable: binb1
   * Referenced by: '<S7>/Constant5'
   */
  { -0.4266987078378886, 0.51260732432984657, 0.11917023520502429,
    0.10861816163587999 },

  /* Variable: binb2
   * Referenced by: '<S7>/Constant6'
   */
  { 0.22670912372150634, 0.73755802527569037, 1.3379010883675098 },

  /* Variable: binb3
   * Referenced by: '<S7>/Constant7'
   */
  { 0.74580831564846573, -0.91383102689049112, 1.1097723419332144 },

  /* Variable: control1W1
   * Referenced by: '<S9>/Constant2'
   */
  { -0.85927191078966869, 1.1663724556804331, -1.0407874644139103,
    -0.98289280298020942, -0.78716084430345667, -1.1921590809411087,
    -1.1477100565687119, -1.0833800262530231, 1.1379161518075067,
    -1.0885550440967995, 0.067578870776460742, 0.40351024662743806,
    -0.26048619536208595, 0.087727538405930158, -0.26797158424072404,
    -0.27216186189947, -0.13541281619385298, -0.15756752956060419,
    0.52897698112561531, -0.054371256529742285, 0.45397103031709091,
    -0.33830817201961333, 0.39276761275470351, 0.20469094402218874,
    0.19928893627733549, 0.39714733088405, 0.43598601837237638,
    0.28110984746807383, -0.1589633395794271, 0.19666658000152007,
    -0.20713779336323182, 0.35142620881927694, -0.29484540762381894,
    -0.28481944733759235, -0.13074911562454908, -0.24587465844258466,
    -0.21974976483504141, -0.419525004795728, 0.34373813577571682,
    -0.33755776716647939, -0.22833289235057086, -0.047016126615561531,
    -0.027694656309178192, -0.18508112567704302, -0.13485908724284781,
    -0.024818116359610398, -0.22812925969613024, -0.033137052588376861,
    -0.067216985206505431, -0.04559927613435924 },

  /* Variable: control1W2
   * Referenced by: '<S9>/Constant3'
   */
  { 0.35212424509315388, 0.19606744944760268, 0.21535093874752026,
    0.027701430982196719, -0.6936059175725463, 0.56435393517708932,
    -0.3551007136627175, -0.49010546571561969, 0.5022485460218814,
    -0.82979494297986778, 0.57903594141751913, 0.73434858921107748,
    0.28909424985797827, 0.1575720343423507, 0.3022482309661661,
    0.14260474459221814, 0.14909548643546272, -0.18744697156856543,
    0.21691081116185826, 0.27820891509444756, 0.639299737298669,
    -0.948909454598496, 0.61781094522840541, 0.64782301137828024,
    0.25116908576189245, -0.002162733353294454, 0.13896992077799733,
    0.32128471873867059, 0.64901000498245032, -0.87244570962159651,
    0.66944982364706251, 0.52037476606937538, -0.87693462830068059,
    0.90937815552037626, -0.71204571778942527, -0.72805529771321587,
    0.4813017716522352, -0.26147969484572481, 0.51734088223862751,
    0.44900018207824116 },

  /* Variable: control1W3
   * Referenced by: '<S9>/Constant4'
   */
  { 0.7277393024559371, -0.88137733344500924, 0.584769260209916,
    0.43636147771729916 },

  /* Variable: control1b1
   * Referenced by: '<S9>/Constant5'
   */
  { 0.47526634164738946, -0.063655122526577609, 0.29101229882088636,
    0.26227800245417565, 0.0853478336462674, 0.2746312810070809,
    0.15706758134341131, 0.2917291339716262, -0.14927239332611841,
    0.32748801499024172 },

  /* Variable: control1b2
   * Referenced by: '<S9>/Constant6'
   */
  { 0.23560427653768046, 0.22055577413598998, 0.085354892400872684,
    0.34219908357107148 },

  /* Variable: control1b3
   * Referenced by: '<S9>/Constant7'
   */
  0.21182092502772962,

  /* Variable: control2W1
   * Referenced by: '<S10>/Constant2'
   */
  { 0.98263040548762215, -1.066557819884042, -0.83329781993939489,
    1.1513288099248082, -0.86836295350308268, -0.97009140740917765,
    1.0013969398736846, -1.1025648297133352, -1.2019711015990913,
    1.3600679263916342, 0.31331244525823687, 0.044040608471802446,
    0.16998682902491569, 0.063477830524501844, 0.11635976376747972,
    0.11122210524971909, 0.47436741776232177, 0.12057921895409435,
    0.18752904934406991, 0.14231406103535382, 0.1137002644040695,
    -0.079586094995635848, -0.15659845856278562, 0.22595132416706395,
    -0.20196557555701986, -0.11958547894327745, 0.15062572849431452,
    -0.10627640316938491, -0.33497166355855057, 0.29541485893109454,
    0.922421811711661, -0.59371615813129963, -0.81748476232944489,
    0.94785010917082724, -0.85716349506196232, -0.67431962879452156,
    0.83987323975915362, -0.70926433040362147, -0.82763503531265437,
    0.8218470504148625, 0.15407186154283226, 0.028396720306510241,
    0.044444934605337258, 0.25798643248397057, -0.047027124161572786,
    -0.011801959303537963, 0.093657158476079957, 0.0028955928954759436,
    -0.016789601060279796, 0.10236508155444657 },

  /* Variable: control2W2
   * Referenced by: '<S10>/Constant3'
   */
  { 0.61497053700097248, 0.367772562446218, -0.15048862551835684,
    -0.070372651560477964, -0.63246602753636438, -0.620020054254298,
    0.38651273177084255, 0.63902402034231442, -0.36208837061141153,
    -0.47707382865773751, 0.71184067852934441, 0.63451224968027409,
    0.33960029222391336, 0.25159569491804346, -0.0587788414683042,
    -0.19236512361888161, -0.41987390598235191, -0.42374651871015778,
    0.61695644623066936, 0.40857245420084137, -0.38741028657312776,
    -0.43724857538348127, 0.58790779414540484, 0.48795175466932822,
    0.58266376839042555, 0.66275872036336825, -0.11527285126167423,
    0.08755222291154155, -0.5909861578203045, -0.5766407902120958,
    0.73730896882931, 0.825572858807371, -0.71340900786315309,
    -0.4676226533438107, 0.72679973109839835, 0.52979004214717351,
    0.59132717303559224, 0.69281787308878762, -0.60481326839937544,
    -0.66083960597302549 },

  /* Variable: control2W3
   * Referenced by: '<S10>/Constant4'
   */
  { -0.37907507250972444, -0.45747161211746257, 0.3944448992818918,
    0.42367727649597725 },

  /* Variable: control2b1
   * Referenced by: '<S10>/Constant5'
   */
  { 0.4059399628297477, -0.052069385704063935, -0.12028920580571086,
    0.211992408970264, 0.03226516330808879, 0.17009040300209974,
    0.43518072567636779, 0.072583293457786344, 0.17561238255333536,
    0.23941301251733768 },

  /* Variable: control2b2
   * Referenced by: '<S10>/Constant6'
   */
  { 0.28059262988732453, 0.28980498037075431, 0.25341189238152384,
    0.17841507580448279 },

  /* Variable: control2b3
   * Referenced by: '<S10>/Constant7'
   */
  0.025189125082017257,

  /* Variable: control3W1
   * Referenced by: '<S11>/Constant2'
   */
  { 1.0683244352970798, 1.2744908290152308, 1.3138329756597047,
    1.2865700198010983, 1.4564384900971554, 0.19742910597188137,
    -0.38623506787569578, 1.2757742909211831, -0.85488623275029674,
    -1.0463350177657837, -0.085342463799196022, -0.27060336770602089,
    -0.074564985219697844, 0.013494743833371223, 0.11515442742171793,
    -0.47714982771927333, -0.10788122955011861, -0.14381986090397553,
    0.36993467792708812, 0.28351975227707527, 0.32402711915286203,
    0.15778508165367824, 0.24105392325552427, 0.21113367079374468,
    0.40303355792873974, -0.31477703088294584, -0.018373838585790454,
    0.39317602150545056, -0.12759675344234403, -0.383597922617443,
    0.69981162460012325, 0.70804217545340375, 0.68152069591876141,
    0.87689512687416682, 0.78685397123327927, -0.31707465767910131,
    -0.48293307187948031, 0.93684419948687092, -0.6725796782045097,
    -0.73147026452044639, 0.46129070252475751, 0.10472406848964755,
    0.11614899282983476, 0.11928114316369091, 0.046279851840808239,
    -0.19190735786921961, -0.29277155794658405, 0.16901115291961427,
    0.068929544651207861, 0.1230346310324418 },

  /* Variable: control3W2
   * Referenced by: '<S11>/Constant3'
   */
  { -0.00866829034915995, 0.20528808304406582, 0.528209623627263,
    0.18597311784498022, -0.72261053370175665, 0.75218772051563243,
    0.64844065595561173, -0.78926807167474122, -0.66289671204741507,
    0.77988812668182428, 0.61748837580899274, -0.651520187354987,
    -0.14868298377637384, 0.53827895988673935, 0.479545233291174,
    -0.21240266424392268, -0.56006544122635948, 0.76721975367917283,
    0.66471542911876247, -0.66746985338046083, -0.30572387970296022,
    -0.018884580409396938, -0.069153655484129592, -0.20838098916953426,
    -0.2065494858971757, -0.086590069286090837, -0.14841215094136673,
    0.029449875785185341, -0.098948067207190668, 0.38748805567282363,
    0.31300089234876777, -0.068029920053628165, 0.37607989107724127,
    -0.35469975493735839, -0.30621300606046054, 0.409930476579416,
    0.36057247291246969, -0.40330908448941133, -0.37805546354475156,
    0.614801914120748 },

  /* Variable: control3W3
   * Referenced by: '<S11>/Constant4'
   */
  { 0.555691218852498, -0.57922609684472581, -0.320373187394294,
    0.40841062400318368 },

  /* Variable: control3b1
   * Referenced by: '<S11>/Constant5'
   */
  { 0.17294082270914349, 0.18567015105310589, 0.12258520296148448,
    0.19636644883272514, 0.00836500758962088, 0.258994294142244,
    -0.18032843166186205, 0.0839388342619195, -0.11002324130046753,
    -0.082471666952688788 },

  /* Variable: control3b2
   * Referenced by: '<S11>/Constant6'
   */
  { -0.018217229795693995, 0.16196970867416727, 0.24017816104903306,
    0.066373460532185541 },

  /* Variable: control3b3
   * Referenced by: '<S11>/Constant7'
   */
  -0.015770882783536295,

  /* Variable: r_enc
   * Referenced by: '<Root>/Kenc'
   */
  0.01483,

  /* Variable: rg
   * Referenced by:
   *   '<S3>/Gain5'
   *   '<S3>/Gain6'
   */
  3.71,

  /* Variable: rm
   * Referenced by:
   *   '<S3>/Gain5'
   *   '<S3>/Gain6'
   */
  0.00635,

  /* Mask Parameter: HILReadEncoderTimebase_clock
   * Referenced by: '<Root>/HIL Read Encoder Timebase'
   */
  0,

  /* Mask Parameter: HILReadEncoderTimebase_channels
   * Referenced by: '<Root>/HIL Read Encoder Timebase'
   */
  { 0U, 1U },

  /* Mask Parameter: HILWriteAnalog_channels
   * Referenced by: '<Root>/HIL Write Analog'
   */
  0U,

  /* Mask Parameter: HILReadEncoderTimebase_samples_
   * Referenced by: '<Root>/HIL Read Encoder Timebase'
   */
  1000U,

  /* Expression: 0
   * Referenced by: '<S5>/Integrator'
   */
  0.0,

  /* Expression: -0.15
   * Referenced by: '<S5>/Gain1'
   */
  -0.15,

  /* Expression: 1.0
   * Referenced by: '<S5>/Saturation2'
   */
  1.0,

  /* Expression: -1.0
   * Referenced by: '<S5>/Saturation2'
   */
  -1.0,

  /* Expression: 0.3
   * Referenced by: '<S5>/Gain3'
   */
  0.3,

  /* Expression: -4
   * Referenced by: '<S5>/Gain4'
   */
  -4.0,

  /* Expression: 30
   * Referenced by: '<S5>/Gain5'
   */
  30.0,

  /* Expression: -10
   * Referenced by: '<S5>/Gain6'
   */
  -10.0,

  /* Expression: 6
   * Referenced by: '<S5>/Gain7'
   */
  6.0,

  /* Expression: -1.25
   * Referenced by: '<S5>/Gain'
   */
  -1.25,

  /* Expression: 0.05
   * Referenced by: '<S5>/Gain2'
   */
  0.05,

  /* Computed Parameter: Merge_InitialOutput
   * Referenced by: '<S7>/Merge'
   */
  0.0,

  /* Expression: 1.3
   * Referenced by: '<S7>/On or off2'
   */
  1.3,

  /* Expression: set_other_outputs_at_terminate
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: set_other_outputs_at_switch_out
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: set_other_outputs_at_start
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: set_other_outputs_at_switch_in
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: final_analog_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: final_pwm_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: analog_input_maximums
   * Referenced by: '<Root>/HIL Initialize'
   */
  10.0,

  /* Expression: analog_input_minimums
   * Referenced by: '<Root>/HIL Initialize'
   */
  -10.0,

  /* Expression: analog_output_maximums
   * Referenced by: '<Root>/HIL Initialize'
   */
  10.0,

  /* Expression: analog_output_minimums
   * Referenced by: '<Root>/HIL Initialize'
   */
  -10.0,

  /* Expression: initial_analog_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: watchdog_analog_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: pwm_frequency
   * Referenced by: '<Root>/HIL Initialize'
   */
  50.0,

  /* Expression: initial_pwm_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: watchdog_pwm_outputs
   * Referenced by: '<Root>/HIL Initialize'
   */
  0.0,

  /* Expression: pi
   * Referenced by: '<Root>/Constant'
   */
  3.1415926535897931,

  /* Expression: [1 -1]
   * Referenced by: '<S2>/Discrete Filter'
   */
  { 1.0, -1.0 },

  /* Expression: [1  0]
   * Referenced by: '<S2>/Discrete Filter'
   */
  { 1.0, 0.0 },

  /* Expression: 0
   * Referenced by: '<S2>/Discrete Filter'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Discrete Filter1'
   */
  0.0,

  /* Expression: pi
   * Referenced by: '<Root>/Constant1'
   */
  3.1415926535897931,

  /* Expression: [1 -1]
   * Referenced by: '<S1>/Discrete Filter'
   */
  { 1.0, -1.0 },

  /* Expression: [1  0]
   * Referenced by: '<S1>/Discrete Filter'
   */
  { 1.0, 0.0 },

  /* Expression: 0
   * Referenced by: '<S1>/Discrete Filter'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Discrete Filter'
   */
  0.0,

  /* Computed Parameter: Merge_InitialOutput_g
   * Referenced by: '<S4>/Merge'
   */
  0.0,

  /* Expression: 0.0
   * Referenced by: '<Root>/On or off1'
   */
  0.0,

  /* Expression: 1.0
   * Referenced by: '<Root>/On or off'
   */
  1.0,

  /* Computed Parameter: HILInitialize_CKChannels
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOWatchdog
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_EIInitial
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POModes
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AIChannels
   * Referenced by: '<Root>/HIL Initialize'
   */
  { 0U, 1U },

  /* Computed Parameter: HILInitialize_AOChannels
   * Referenced by: '<Root>/HIL Initialize'
   */
  { 0U, 1U },

  /* Computed Parameter: HILInitialize_EIChannels
   * Referenced by: '<Root>/HIL Initialize'
   */
  { 0U, 1U },

  /* Computed Parameter: HILInitialize_EIQuadrature
   * Referenced by: '<Root>/HIL Initialize'
   */
  4U,

  /* Computed Parameter: HILInitialize_Active
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOTerminate
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_AOExit
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOTerminate
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOExit
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POTerminate
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_POExit
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_CKEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AIPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_AIPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_AOPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_AOEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOReset
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOReset
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_EIPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_EIPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_EIStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_EIEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POPStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_POPEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POStart
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_POEnter
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POReset
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_OOReset
   * Referenced by: '<Root>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOFinal
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOInitial
   * Referenced by: '<Root>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILReadEncoderTimebase_Active
   * Referenced by: '<Root>/HIL Read Encoder Timebase'
   */
  1,

  /* Computed Parameter: HILWriteAnalog_Active
   * Referenced by: '<Root>/HIL Write Analog'
   */
  0
};
