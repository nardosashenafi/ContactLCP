/*
 * cartpole_MOE_2019a.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "cartpole_MOE_2019a".
 *
 * Model version              : 1.26
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C source code generated on : Wed Feb  8 15:06:26 2023
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "cartpole_MOE_2019a.h"
#include "cartpole_MOE_2019a_private.h"
#include "cartpole_MOE_2019a_dt.h"

/* Block signals (default storage) */
B_cartpole_MOE_2019a_T cartpole_MOE_2019a_B;

/* Continuous states */
X_cartpole_MOE_2019a_T cartpole_MOE_2019a_X;

/* Block states (default storage) */
DW_cartpole_MOE_2019a_T cartpole_MOE_2019a_DW;

/* Real-time model */
RT_MODEL_cartpole_MOE_2019a_T cartpole_MOE_2019a_M_;
RT_MODEL_cartpole_MOE_2019a_T *const cartpole_MOE_2019a_M =
  &cartpole_MOE_2019a_M_;

/*
 * Writes out MAT-file header.  Returns success or failure.
 * Returns:
 *      0 - success
 *      1 - failure
 */
int_T rt_WriteMat4FileHeader(FILE *fp, int32_T m, int32_T n, const char *name)
{
  typedef enum { ELITTLE_ENDIAN, EBIG_ENDIAN } ByteOrder;

  int16_T one = 1;
  ByteOrder byteOrder = (*((int8_T *)&one)==1) ? ELITTLE_ENDIAN : EBIG_ENDIAN;
  int32_T type = (byteOrder == ELITTLE_ENDIAN) ? 0: 1000;
  int32_T imagf = 0;
  int32_T name_len = (int32_T)strlen(name) + 1;
  if ((fwrite(&type, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&m, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&n, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&imagf, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&name_len, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(name, sizeof(char), name_len, fp) == 0)) {
    return(1);
  } else {
    return(0);
  }
}                                      /* end rt_WriteMat4FileHeader */

/*
 * This function updates continuous states using the ODE1 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE1_IntgData *id = (ODE1_IntgData *)rtsiGetSolverData(si);
  real_T *f0 = id->f[0];
  int_T i;
  int_T nXc = 1;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);
  rtsiSetdX(si, f0);
  cartpole_MOE_2019a_derivatives();
  rtsiSetT(si, tnew);
  for (i = 0; i < nXc; ++i) {
    x[i] += h * f0[i];
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model output function */
void cartpole_MOE_2019a_output(void)
{
  /* local block i/o variables */
  real_T rtb_HILReadEncoderTimebase_o2;
  real_T rtb_TmpSignalConversionAtToFile[6];
  real_T rtb_upiNenc;
  real_T rtb_Sin;
  real_T u0;
  if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
    /* set solver stop time */
    if (!(cartpole_MOE_2019a_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&cartpole_MOE_2019a_M->solverInfo,
                            ((cartpole_MOE_2019a_M->Timing.clockTickH0 + 1) *
        cartpole_MOE_2019a_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&cartpole_MOE_2019a_M->solverInfo,
                            ((cartpole_MOE_2019a_M->Timing.clockTick0 + 1) *
        cartpole_MOE_2019a_M->Timing.stepSize0 +
        cartpole_MOE_2019a_M->Timing.clockTickH0 *
        cartpole_MOE_2019a_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(cartpole_MOE_2019a_M)) {
    cartpole_MOE_2019a_M->Timing.t[0] = rtsiGetT
      (&cartpole_MOE_2019a_M->solverInfo);
  }

  if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
    /* S-Function (hil_read_encoder_timebase_block): '<Root>/HIL Read Encoder Timebase' */

    /* S-Function Block: cartpole_MOE_2019a/HIL Read Encoder Timebase (hil_read_encoder_timebase_block) */
    {
      t_error result;
      result = hil_task_read_encoder
        (cartpole_MOE_2019a_DW.HILReadEncoderTimebase_Task, 1,
         &cartpole_MOE_2019a_DW.HILReadEncoderTimebase_Buffer[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
      } else {
        rtb_upiNenc = cartpole_MOE_2019a_DW.HILReadEncoderTimebase_Buffer[0];
        rtb_HILReadEncoderTimebase_o2 =
          cartpole_MOE_2019a_DW.HILReadEncoderTimebase_Buffer[1];
      }
    }

    /* Gain: '<Root>/Kenc' */
    cartpole_MOE_2019a_B.Kenc = cartpole_MOE_2019a_P.r_enc * 2.0 *
      3.1415926535897931 / cartpole_MOE_2019a_P.Nenc * rtb_upiNenc;

    /* Gain: '<Root>/2pi//Nenc' */
    rtb_upiNenc = 6.2831853071795862 / cartpole_MOE_2019a_P.Nenc *
      rtb_HILReadEncoderTimebase_o2;

    /* Trigonometry: '<S4>/Sin' incorporates:
     *  Constant: '<Root>/Constant'
     *  Sum: '<Root>/Sum'
     */
    rtb_Sin = sin(rtb_upiNenc + cartpole_MOE_2019a_P.Constant_Value);

    /* DiscreteFilter: '<S2>/Discrete Filter' */
    cartpole_MOE_2019a_DW.DiscreteFilter_tmp = (cartpole_MOE_2019a_B.Kenc -
      cartpole_MOE_2019a_P.DiscreteFilter_DenCoef[1] *
      cartpole_MOE_2019a_DW.DiscreteFilter_states) /
      cartpole_MOE_2019a_P.DiscreteFilter_DenCoef[0];

    /* DiscreteFilter: '<Root>/Discrete Filter1' incorporates:
     *  DiscreteFilter: '<S2>/Discrete Filter'
     *  Gain: '<S2>/Gain3'
     */
    cartpole_MOE_2019a_DW.DiscreteFilter1_tmp =
      (((cartpole_MOE_2019a_P.DiscreteFilter_NumCoef[0] *
         cartpole_MOE_2019a_DW.DiscreteFilter_tmp +
         cartpole_MOE_2019a_P.DiscreteFilter_NumCoef[1] *
         cartpole_MOE_2019a_DW.DiscreteFilter_states) * (1.0 /
         cartpole_MOE_2019a_P.T) - cartpole_MOE_2019a_P.af[1] *
        cartpole_MOE_2019a_DW.DiscreteFilter1_states[0]) -
       cartpole_MOE_2019a_P.af[2] *
       cartpole_MOE_2019a_DW.DiscreteFilter1_states[1]) /
      cartpole_MOE_2019a_P.af[0];
    cartpole_MOE_2019a_B.DiscreteFilter1 = (cartpole_MOE_2019a_P.bf[0] *
      cartpole_MOE_2019a_DW.DiscreteFilter1_tmp + cartpole_MOE_2019a_P.bf[1] *
      cartpole_MOE_2019a_DW.DiscreteFilter1_states[0]) +
      cartpole_MOE_2019a_P.bf[2] * cartpole_MOE_2019a_DW.DiscreteFilter1_states
      [1];

    /* Sum: '<Root>/Sum1' incorporates:
     *  Constant: '<Root>/Constant1'
     */
    cartpole_MOE_2019a_B.Sum1 = rtb_upiNenc +
      cartpole_MOE_2019a_P.Constant1_Value;

    /* DiscreteFilter: '<S1>/Discrete Filter' */
    cartpole_MOE_2019a_DW.DiscreteFilter_tmp_c = (cartpole_MOE_2019a_B.Sum1 -
      cartpole_MOE_2019a_P.DiscreteFilter_DenCoef_f[1] *
      cartpole_MOE_2019a_DW.DiscreteFilter_states_p) /
      cartpole_MOE_2019a_P.DiscreteFilter_DenCoef_f[0];

    /* DiscreteFilter: '<Root>/Discrete Filter' incorporates:
     *  DiscreteFilter: '<S1>/Discrete Filter'
     *  Gain: '<S1>/Gain3'
     */
    cartpole_MOE_2019a_DW.DiscreteFilter_tmp_a =
      (((cartpole_MOE_2019a_P.DiscreteFilter_NumCoef_b[0] *
         cartpole_MOE_2019a_DW.DiscreteFilter_tmp_c +
         cartpole_MOE_2019a_P.DiscreteFilter_NumCoef_b[1] *
         cartpole_MOE_2019a_DW.DiscreteFilter_states_p) * (1.0 /
         cartpole_MOE_2019a_P.T) - cartpole_MOE_2019a_P.af[1] *
        cartpole_MOE_2019a_DW.DiscreteFilter_states_a[0]) -
       cartpole_MOE_2019a_P.af[2] *
       cartpole_MOE_2019a_DW.DiscreteFilter_states_a[1]) /
      cartpole_MOE_2019a_P.af[0];
    cartpole_MOE_2019a_B.DiscreteFilter = (cartpole_MOE_2019a_P.bf[0] *
      cartpole_MOE_2019a_DW.DiscreteFilter_tmp_a + cartpole_MOE_2019a_P.bf[1] *
      cartpole_MOE_2019a_DW.DiscreteFilter_states_a[0]) +
      cartpole_MOE_2019a_P.bf[2] *
      cartpole_MOE_2019a_DW.DiscreteFilter_states_a[1];

    /* Gain: '<S4>/Gain' incorporates:
     *  Gain: '<S4>/Gain4'
     *  Gain: '<S4>/Gain5'
     *  Gain: '<S4>/Gain6'
     *  Gain: '<S4>/Gain7'
     *  Sum: '<S4>/Add1'
     */
    cartpole_MOE_2019a_B.Gain = (((cartpole_MOE_2019a_P.Gain4_Gain *
      cartpole_MOE_2019a_B.Kenc + cartpole_MOE_2019a_P.Gain5_Gain * rtb_Sin) +
      cartpole_MOE_2019a_P.Gain6_Gain * cartpole_MOE_2019a_B.DiscreteFilter1) +
      cartpole_MOE_2019a_P.Gain7_Gain * cartpole_MOE_2019a_B.DiscreteFilter) *
      cartpole_MOE_2019a_P.Gain_Gain;
  }

  /* Gain: '<S4>/Gain1' incorporates:
   *  Integrator: '<S4>/Integrator'
   */
  u0 = cartpole_MOE_2019a_P.Gain1_Gain * cartpole_MOE_2019a_X.Integrator_CSTATE;

  /* Saturate: '<S4>/Saturation2' */
  if (u0 > cartpole_MOE_2019a_P.Saturation2_UpperSat) {
    cartpole_MOE_2019a_B.Saturation2 = cartpole_MOE_2019a_P.Saturation2_UpperSat;
  } else if (u0 < cartpole_MOE_2019a_P.Saturation2_LowerSat) {
    cartpole_MOE_2019a_B.Saturation2 = cartpole_MOE_2019a_P.Saturation2_LowerSat;
  } else {
    cartpole_MOE_2019a_B.Saturation2 = u0;
  }

  /* End of Saturate: '<S4>/Saturation2' */

  /* Sum: '<S4>/Add' */
  u0 = cartpole_MOE_2019a_B.Gain + cartpole_MOE_2019a_B.Saturation2;

  /* Saturate: '<S4>/Saturation1' */
  if (u0 > cartpole_MOE_2019a_P.Fmax) {
    cartpole_MOE_2019a_B.Saturation1 = cartpole_MOE_2019a_P.Fmax;
  } else if (u0 < -cartpole_MOE_2019a_P.Fmax) {
    cartpole_MOE_2019a_B.Saturation1 = -cartpole_MOE_2019a_P.Fmax;
  } else {
    cartpole_MOE_2019a_B.Saturation1 = u0;
  }

  /* End of Saturate: '<S4>/Saturation1' */
  if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
    /* Gain: '<Root>/On or off1' */
    cartpole_MOE_2019a_B.Onoroff1 = cartpole_MOE_2019a_P.Onoroff1_Gain *
      cartpole_MOE_2019a_B.DiscreteFilter1;

    /* Gain: '<S3>/Gain6' */
    cartpole_MOE_2019a_B.Gain6 = cartpole_MOE_2019a_P.rg *
      cartpole_MOE_2019a_P.Kt / cartpole_MOE_2019a_P.rm *
      cartpole_MOE_2019a_B.DiscreteFilter1;
  }

  /* Sum: '<S3>/Add' incorporates:
   *  Gain: '<S3>/Gain5'
   *  Sum: '<Root>/Sum2'
   */
  u0 = cartpole_MOE_2019a_P.R * cartpole_MOE_2019a_P.rm /
    (cartpole_MOE_2019a_P.rg * cartpole_MOE_2019a_P.Kt) *
    (cartpole_MOE_2019a_B.Saturation1 + cartpole_MOE_2019a_B.Onoroff1) +
    cartpole_MOE_2019a_B.Gain6;

  /* Saturate: '<S3>/Saturation1' */
  if (u0 > cartpole_MOE_2019a_P.Vmax) {
    cartpole_MOE_2019a_B.Saturation1_k = cartpole_MOE_2019a_P.Vmax;
  } else if (u0 < -cartpole_MOE_2019a_P.Vmax) {
    cartpole_MOE_2019a_B.Saturation1_k = -cartpole_MOE_2019a_P.Vmax;
  } else {
    cartpole_MOE_2019a_B.Saturation1_k = u0;
  }

  /* End of Saturate: '<S3>/Saturation1' */

  /* Gain: '<Root>/On or off' */
  cartpole_MOE_2019a_B.Onoroff = cartpole_MOE_2019a_P.Onoroff_Gain *
    cartpole_MOE_2019a_B.Saturation1_k;
  if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
    /* S-Function (hil_write_analog_block): '<Root>/HIL Write Analog' */

    /* S-Function Block: cartpole_MOE_2019a/HIL Write Analog (hil_write_analog_block) */
    {
      t_error result;
      result = hil_write_analog(cartpole_MOE_2019a_DW.HILInitialize_Card,
        &cartpole_MOE_2019a_P.HILWriteAnalog_channels, 1,
        &cartpole_MOE_2019a_B.Onoroff);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
      }
    }

    /* SignalConversion: '<Root>/TmpSignal ConversionAtTo FileInport1' */
    rtb_TmpSignalConversionAtToFile[0] = cartpole_MOE_2019a_B.Saturation1_k;
    rtb_TmpSignalConversionAtToFile[1] = cartpole_MOE_2019a_B.Kenc;
    rtb_TmpSignalConversionAtToFile[2] = rtb_upiNenc;
    rtb_TmpSignalConversionAtToFile[3] = cartpole_MOE_2019a_B.DiscreteFilter1;
    rtb_TmpSignalConversionAtToFile[4] = cartpole_MOE_2019a_B.DiscreteFilter;
    rtb_TmpSignalConversionAtToFile[5] = cartpole_MOE_2019a_B.Saturation1;

    /* ToFile: '<Root>/To File' */
    {
      if (!(++cartpole_MOE_2019a_DW.ToFile_IWORK.Decimation % 1) &&
          (cartpole_MOE_2019a_DW.ToFile_IWORK.Count * (6 + 1)) + 1 < 100000000 )
      {
        FILE *fp = (FILE *) cartpole_MOE_2019a_DW.ToFile_PWORK.FilePtr;
        if (fp != (NULL)) {
          real_T u[6 + 1];
          cartpole_MOE_2019a_DW.ToFile_IWORK.Decimation = 0;
          u[0] = cartpole_MOE_2019a_M->Timing.t[1];
          u[1] = rtb_TmpSignalConversionAtToFile[0];
          u[2] = rtb_TmpSignalConversionAtToFile[1];
          u[3] = rtb_TmpSignalConversionAtToFile[2];
          u[4] = rtb_TmpSignalConversionAtToFile[3];
          u[5] = rtb_TmpSignalConversionAtToFile[4];
          u[6] = rtb_TmpSignalConversionAtToFile[5];
          if (fwrite(u, sizeof(real_T), 6 + 1, fp) != 6 + 1) {
            rtmSetErrorStatus(cartpole_MOE_2019a_M,
                              "Error writing to MAT-file cartpole_MOE.mat");
            return;
          }

          if (((++cartpole_MOE_2019a_DW.ToFile_IWORK.Count) * (6 + 1))+1 >=
              100000000) {
            (void)fprintf(stdout,
                          "*** The ToFile block will stop logging data before\n"
                          "    the simulation has ended, because it has reached\n"
                          "    the maximum number of elements (100000000)\n"
                          "    allowed in MAT-file cartpole_MOE.mat.\n");
          }
        }
      }
    }

    /* Gain: '<Root>/360//Nenc' */
    cartpole_MOE_2019a_B.u60Nenc = 360.0 / cartpole_MOE_2019a_P.Nenc *
      rtb_HILReadEncoderTimebase_o2;

    /* Sum: '<S4>/Sum1' incorporates:
     *  Gain: '<S4>/Gain3'
     */
    cartpole_MOE_2019a_B.Sum1_o = cartpole_MOE_2019a_P.Gain3_Gain * rtb_Sin -
      cartpole_MOE_2019a_B.Kenc;
  }

  /* Sum: '<S4>/Sum' incorporates:
   *  Gain: '<S4>/Gain2'
   *  Integrator: '<S4>/Integrator'
   */
  cartpole_MOE_2019a_B.Sum = cartpole_MOE_2019a_B.Sum1_o -
    cartpole_MOE_2019a_P.Gain2_Gain * cartpole_MOE_2019a_X.Integrator_CSTATE;
}

/* Model update function */
void cartpole_MOE_2019a_update(void)
{
  if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
    /* Update for DiscreteFilter: '<S2>/Discrete Filter' */
    cartpole_MOE_2019a_DW.DiscreteFilter_states =
      cartpole_MOE_2019a_DW.DiscreteFilter_tmp;

    /* Update for DiscreteFilter: '<Root>/Discrete Filter1' */
    cartpole_MOE_2019a_DW.DiscreteFilter1_states[1] =
      cartpole_MOE_2019a_DW.DiscreteFilter1_states[0];
    cartpole_MOE_2019a_DW.DiscreteFilter1_states[0] =
      cartpole_MOE_2019a_DW.DiscreteFilter1_tmp;

    /* Update for DiscreteFilter: '<S1>/Discrete Filter' */
    cartpole_MOE_2019a_DW.DiscreteFilter_states_p =
      cartpole_MOE_2019a_DW.DiscreteFilter_tmp_c;

    /* Update for DiscreteFilter: '<Root>/Discrete Filter' */
    cartpole_MOE_2019a_DW.DiscreteFilter_states_a[1] =
      cartpole_MOE_2019a_DW.DiscreteFilter_states_a[0];
    cartpole_MOE_2019a_DW.DiscreteFilter_states_a[0] =
      cartpole_MOE_2019a_DW.DiscreteFilter_tmp_a;
  }

  if (rtmIsMajorTimeStep(cartpole_MOE_2019a_M)) {
    rt_ertODEUpdateContinuousStates(&cartpole_MOE_2019a_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++cartpole_MOE_2019a_M->Timing.clockTick0)) {
    ++cartpole_MOE_2019a_M->Timing.clockTickH0;
  }

  cartpole_MOE_2019a_M->Timing.t[0] = rtsiGetSolverStopTime
    (&cartpole_MOE_2019a_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++cartpole_MOE_2019a_M->Timing.clockTick1)) {
      ++cartpole_MOE_2019a_M->Timing.clockTickH1;
    }

    cartpole_MOE_2019a_M->Timing.t[1] = cartpole_MOE_2019a_M->Timing.clockTick1 *
      cartpole_MOE_2019a_M->Timing.stepSize1 +
      cartpole_MOE_2019a_M->Timing.clockTickH1 *
      cartpole_MOE_2019a_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void cartpole_MOE_2019a_derivatives(void)
{
  XDot_cartpole_MOE_2019a_T *_rtXdot;
  _rtXdot = ((XDot_cartpole_MOE_2019a_T *) cartpole_MOE_2019a_M->derivs);

  /* Derivatives for Integrator: '<S4>/Integrator' */
  _rtXdot->Integrator_CSTATE = cartpole_MOE_2019a_B.Sum;
}

/* Model initialize function */
void cartpole_MOE_2019a_initialize(void)
{
  /* Start for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: cartpole_MOE_2019a/HIL Initialize (hil_initialize_block) */
  {
    t_int result;
    t_boolean is_switching;
    result = hil_open("q2_usb", "0", &cartpole_MOE_2019a_DW.HILInitialize_Card);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
      return;
    }

    is_switching = false;
    result = hil_set_card_specific_options
      (cartpole_MOE_2019a_DW.HILInitialize_Card,
       "d0=digital;d1=digital;led=auto;update_rate=normal;decimation=1", 63);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
      return;
    }

    result = hil_watchdog_clear(cartpole_MOE_2019a_DW.HILInitialize_Card);
    if (result < 0 && result != -QERR_HIL_WATCHDOG_CLEAR) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
      return;
    }

    if ((cartpole_MOE_2019a_P.HILInitialize_AIPStart && !is_switching) ||
        (cartpole_MOE_2019a_P.HILInitialize_AIPEnter && is_switching)) {
      cartpole_MOE_2019a_DW.HILInitialize_AIMinimums[0] =
        (cartpole_MOE_2019a_P.HILInitialize_AILow);
      cartpole_MOE_2019a_DW.HILInitialize_AIMinimums[1] =
        (cartpole_MOE_2019a_P.HILInitialize_AILow);
      cartpole_MOE_2019a_DW.HILInitialize_AIMaximums[0] =
        cartpole_MOE_2019a_P.HILInitialize_AIHigh;
      cartpole_MOE_2019a_DW.HILInitialize_AIMaximums[1] =
        cartpole_MOE_2019a_P.HILInitialize_AIHigh;
      result = hil_set_analog_input_ranges
        (cartpole_MOE_2019a_DW.HILInitialize_Card,
         cartpole_MOE_2019a_P.HILInitialize_AIChannels, 2U,
         &cartpole_MOE_2019a_DW.HILInitialize_AIMinimums[0],
         &cartpole_MOE_2019a_DW.HILInitialize_AIMaximums[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
        return;
      }
    }

    if ((cartpole_MOE_2019a_P.HILInitialize_AOPStart && !is_switching) ||
        (cartpole_MOE_2019a_P.HILInitialize_AOPEnter && is_switching)) {
      cartpole_MOE_2019a_DW.HILInitialize_AOMinimums[0] =
        (cartpole_MOE_2019a_P.HILInitialize_AOLow);
      cartpole_MOE_2019a_DW.HILInitialize_AOMinimums[1] =
        (cartpole_MOE_2019a_P.HILInitialize_AOLow);
      cartpole_MOE_2019a_DW.HILInitialize_AOMaximums[0] =
        cartpole_MOE_2019a_P.HILInitialize_AOHigh;
      cartpole_MOE_2019a_DW.HILInitialize_AOMaximums[1] =
        cartpole_MOE_2019a_P.HILInitialize_AOHigh;
      result = hil_set_analog_output_ranges
        (cartpole_MOE_2019a_DW.HILInitialize_Card,
         cartpole_MOE_2019a_P.HILInitialize_AOChannels, 2U,
         &cartpole_MOE_2019a_DW.HILInitialize_AOMinimums[0],
         &cartpole_MOE_2019a_DW.HILInitialize_AOMaximums[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
        return;
      }
    }

    if ((cartpole_MOE_2019a_P.HILInitialize_AOStart && !is_switching) ||
        (cartpole_MOE_2019a_P.HILInitialize_AOEnter && is_switching)) {
      cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[0] =
        cartpole_MOE_2019a_P.HILInitialize_AOInitial;
      cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[1] =
        cartpole_MOE_2019a_P.HILInitialize_AOInitial;
      result = hil_write_analog(cartpole_MOE_2019a_DW.HILInitialize_Card,
        cartpole_MOE_2019a_P.HILInitialize_AOChannels, 2U,
        &cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
        return;
      }
    }

    if (cartpole_MOE_2019a_P.HILInitialize_AOReset) {
      cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[0] =
        cartpole_MOE_2019a_P.HILInitialize_AOWatchdog;
      cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[1] =
        cartpole_MOE_2019a_P.HILInitialize_AOWatchdog;
      result = hil_watchdog_set_analog_expiration_state
        (cartpole_MOE_2019a_DW.HILInitialize_Card,
         cartpole_MOE_2019a_P.HILInitialize_AOChannels, 2U,
         &cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
        return;
      }
    }

    if ((cartpole_MOE_2019a_P.HILInitialize_EIPStart && !is_switching) ||
        (cartpole_MOE_2019a_P.HILInitialize_EIPEnter && is_switching)) {
      cartpole_MOE_2019a_DW.HILInitialize_QuadratureModes[0] =
        cartpole_MOE_2019a_P.HILInitialize_EIQuadrature;
      cartpole_MOE_2019a_DW.HILInitialize_QuadratureModes[1] =
        cartpole_MOE_2019a_P.HILInitialize_EIQuadrature;
      result = hil_set_encoder_quadrature_mode
        (cartpole_MOE_2019a_DW.HILInitialize_Card,
         cartpole_MOE_2019a_P.HILInitialize_EIChannels, 2U,
         (t_encoder_quadrature_mode *)
         &cartpole_MOE_2019a_DW.HILInitialize_QuadratureModes[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
        return;
      }
    }

    if ((cartpole_MOE_2019a_P.HILInitialize_EIStart && !is_switching) ||
        (cartpole_MOE_2019a_P.HILInitialize_EIEnter && is_switching)) {
      cartpole_MOE_2019a_DW.HILInitialize_InitialEICounts[0] =
        cartpole_MOE_2019a_P.HILInitialize_EIInitial;
      cartpole_MOE_2019a_DW.HILInitialize_InitialEICounts[1] =
        cartpole_MOE_2019a_P.HILInitialize_EIInitial;
      result = hil_set_encoder_counts(cartpole_MOE_2019a_DW.HILInitialize_Card,
        cartpole_MOE_2019a_P.HILInitialize_EIChannels, 2U,
        &cartpole_MOE_2019a_DW.HILInitialize_InitialEICounts[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
        return;
      }
    }
  }

  /* Start for S-Function (hil_read_encoder_timebase_block): '<Root>/HIL Read Encoder Timebase' */

  /* S-Function Block: cartpole_MOE_2019a/HIL Read Encoder Timebase (hil_read_encoder_timebase_block) */
  {
    t_error result;
    result = hil_task_create_encoder_reader
      (cartpole_MOE_2019a_DW.HILInitialize_Card,
       cartpole_MOE_2019a_P.HILReadEncoderTimebase_samples_,
       cartpole_MOE_2019a_P.HILReadEncoderTimebase_channels, 2,
       &cartpole_MOE_2019a_DW.HILReadEncoderTimebase_Task);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
    }
  }

  /* Start for ToFile: '<Root>/To File' */
  {
    FILE *fp = (NULL);
    char fileName[509] = "cartpole_MOE.mat";
    if ((fp = fopen(fileName, "wb")) == (NULL)) {
      rtmSetErrorStatus(cartpole_MOE_2019a_M,
                        "Error creating .mat file cartpole_MOE.mat");
      return;
    }

    if (rt_WriteMat4FileHeader(fp, 6 + 1, 0, "cart_data")) {
      rtmSetErrorStatus(cartpole_MOE_2019a_M,
                        "Error writing mat file header to file cartpole_MOE.mat");
      return;
    }

    cartpole_MOE_2019a_DW.ToFile_IWORK.Count = 0;
    cartpole_MOE_2019a_DW.ToFile_IWORK.Decimation = -1;
    cartpole_MOE_2019a_DW.ToFile_PWORK.FilePtr = fp;
  }

  /* InitializeConditions for DiscreteFilter: '<S2>/Discrete Filter' */
  cartpole_MOE_2019a_DW.DiscreteFilter_states =
    cartpole_MOE_2019a_P.DiscreteFilter_InitialStates;

  /* InitializeConditions for DiscreteFilter: '<S1>/Discrete Filter' */
  cartpole_MOE_2019a_DW.DiscreteFilter_states_p =
    cartpole_MOE_2019a_P.DiscreteFilter_InitialStates_g;

  /* InitializeConditions for DiscreteFilter: '<Root>/Discrete Filter1' */
  cartpole_MOE_2019a_DW.DiscreteFilter1_states[0] =
    cartpole_MOE_2019a_P.DiscreteFilter1_InitialStates;

  /* InitializeConditions for DiscreteFilter: '<Root>/Discrete Filter' */
  cartpole_MOE_2019a_DW.DiscreteFilter_states_a[0] =
    cartpole_MOE_2019a_P.DiscreteFilter_InitialStates_h;

  /* InitializeConditions for DiscreteFilter: '<Root>/Discrete Filter1' */
  cartpole_MOE_2019a_DW.DiscreteFilter1_states[1] =
    cartpole_MOE_2019a_P.DiscreteFilter1_InitialStates;

  /* InitializeConditions for DiscreteFilter: '<Root>/Discrete Filter' */
  cartpole_MOE_2019a_DW.DiscreteFilter_states_a[1] =
    cartpole_MOE_2019a_P.DiscreteFilter_InitialStates_h;

  /* InitializeConditions for Integrator: '<S4>/Integrator' */
  cartpole_MOE_2019a_X.Integrator_CSTATE = cartpole_MOE_2019a_P.Integrator_IC;
}

/* Model terminate function */
void cartpole_MOE_2019a_terminate(void)
{
  /* Terminate for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: cartpole_MOE_2019a/HIL Initialize (hil_initialize_block) */
  {
    t_boolean is_switching;
    t_int result;
    t_uint32 num_final_analog_outputs = 0;
    hil_task_stop_all(cartpole_MOE_2019a_DW.HILInitialize_Card);
    hil_monitor_stop_all(cartpole_MOE_2019a_DW.HILInitialize_Card);
    is_switching = false;
    if ((cartpole_MOE_2019a_P.HILInitialize_AOTerminate && !is_switching) ||
        (cartpole_MOE_2019a_P.HILInitialize_AOExit && is_switching)) {
      cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[0] =
        cartpole_MOE_2019a_P.HILInitialize_AOFinal;
      cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[1] =
        cartpole_MOE_2019a_P.HILInitialize_AOFinal;
      num_final_analog_outputs = 2U;
    }

    if (num_final_analog_outputs > 0) {
      result = hil_write_analog(cartpole_MOE_2019a_DW.HILInitialize_Card,
        cartpole_MOE_2019a_P.HILInitialize_AOChannels, num_final_analog_outputs,
        &cartpole_MOE_2019a_DW.HILInitialize_AOVoltages[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(cartpole_MOE_2019a_M, _rt_error_message);
      }
    }

    hil_task_delete_all(cartpole_MOE_2019a_DW.HILInitialize_Card);
    hil_monitor_delete_all(cartpole_MOE_2019a_DW.HILInitialize_Card);
    hil_close(cartpole_MOE_2019a_DW.HILInitialize_Card);
    cartpole_MOE_2019a_DW.HILInitialize_Card = NULL;
  }

  /* Terminate for ToFile: '<Root>/To File' */
  {
    FILE *fp = (FILE *) cartpole_MOE_2019a_DW.ToFile_PWORK.FilePtr;
    if (fp != (NULL)) {
      char fileName[509] = "cartpole_MOE.mat";
      if (fclose(fp) == EOF) {
        rtmSetErrorStatus(cartpole_MOE_2019a_M,
                          "Error closing MAT-file cartpole_MOE.mat");
        return;
      }

      if ((fp = fopen(fileName, "r+b")) == (NULL)) {
        rtmSetErrorStatus(cartpole_MOE_2019a_M,
                          "Error reopening MAT-file cartpole_MOE.mat");
        return;
      }

      if (rt_WriteMat4FileHeader(fp, 6 + 1,
           cartpole_MOE_2019a_DW.ToFile_IWORK.Count, "cart_data")) {
        rtmSetErrorStatus(cartpole_MOE_2019a_M,
                          "Error writing header for cart_data to MAT-file cartpole_MOE.mat");
      }

      if (fclose(fp) == EOF) {
        rtmSetErrorStatus(cartpole_MOE_2019a_M,
                          "Error closing MAT-file cartpole_MOE.mat");
        return;
      }

      cartpole_MOE_2019a_DW.ToFile_PWORK.FilePtr = (NULL);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  cartpole_MOE_2019a_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  cartpole_MOE_2019a_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  cartpole_MOE_2019a_initialize();
}

void MdlTerminate(void)
{
  cartpole_MOE_2019a_terminate();
}

/* Registration function */
RT_MODEL_cartpole_MOE_2019a_T *cartpole_MOE_2019a(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)cartpole_MOE_2019a_M, 0,
                sizeof(RT_MODEL_cartpole_MOE_2019a_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&cartpole_MOE_2019a_M->solverInfo,
                          &cartpole_MOE_2019a_M->Timing.simTimeStep);
    rtsiSetTPtr(&cartpole_MOE_2019a_M->solverInfo, &rtmGetTPtr
                (cartpole_MOE_2019a_M));
    rtsiSetStepSizePtr(&cartpole_MOE_2019a_M->solverInfo,
                       &cartpole_MOE_2019a_M->Timing.stepSize0);
    rtsiSetdXPtr(&cartpole_MOE_2019a_M->solverInfo,
                 &cartpole_MOE_2019a_M->derivs);
    rtsiSetContStatesPtr(&cartpole_MOE_2019a_M->solverInfo, (real_T **)
                         &cartpole_MOE_2019a_M->contStates);
    rtsiSetNumContStatesPtr(&cartpole_MOE_2019a_M->solverInfo,
      &cartpole_MOE_2019a_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&cartpole_MOE_2019a_M->solverInfo,
      &cartpole_MOE_2019a_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&cartpole_MOE_2019a_M->solverInfo,
      &cartpole_MOE_2019a_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&cartpole_MOE_2019a_M->solverInfo,
      &cartpole_MOE_2019a_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&cartpole_MOE_2019a_M->solverInfo, (&rtmGetErrorStatus
      (cartpole_MOE_2019a_M)));
    rtsiSetRTModelPtr(&cartpole_MOE_2019a_M->solverInfo, cartpole_MOE_2019a_M);
  }

  rtsiSetSimTimeStep(&cartpole_MOE_2019a_M->solverInfo, MAJOR_TIME_STEP);
  cartpole_MOE_2019a_M->intgData.f[0] = cartpole_MOE_2019a_M->odeF[0];
  cartpole_MOE_2019a_M->contStates = ((real_T *) &cartpole_MOE_2019a_X);
  rtsiSetSolverData(&cartpole_MOE_2019a_M->solverInfo, (void *)
                    &cartpole_MOE_2019a_M->intgData);
  rtsiSetSolverName(&cartpole_MOE_2019a_M->solverInfo,"ode1");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = cartpole_MOE_2019a_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    cartpole_MOE_2019a_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    cartpole_MOE_2019a_M->Timing.sampleTimes =
      (&cartpole_MOE_2019a_M->Timing.sampleTimesArray[0]);
    cartpole_MOE_2019a_M->Timing.offsetTimes =
      (&cartpole_MOE_2019a_M->Timing.offsetTimesArray[0]);

    /* task periods */
    cartpole_MOE_2019a_M->Timing.sampleTimes[0] = (0.0);
    cartpole_MOE_2019a_M->Timing.sampleTimes[1] = (0.001);

    /* task offsets */
    cartpole_MOE_2019a_M->Timing.offsetTimes[0] = (0.0);
    cartpole_MOE_2019a_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(cartpole_MOE_2019a_M, &cartpole_MOE_2019a_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = cartpole_MOE_2019a_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    cartpole_MOE_2019a_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(cartpole_MOE_2019a_M, -1);
  cartpole_MOE_2019a_M->Timing.stepSize0 = 0.001;
  cartpole_MOE_2019a_M->Timing.stepSize1 = 0.001;

  /* External mode info */
  cartpole_MOE_2019a_M->Sizes.checksums[0] = (307575652U);
  cartpole_MOE_2019a_M->Sizes.checksums[1] = (1525571376U);
  cartpole_MOE_2019a_M->Sizes.checksums[2] = (2319926166U);
  cartpole_MOE_2019a_M->Sizes.checksums[3] = (818850156U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    cartpole_MOE_2019a_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(cartpole_MOE_2019a_M->extModeInfo,
      &cartpole_MOE_2019a_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(cartpole_MOE_2019a_M->extModeInfo,
                        cartpole_MOE_2019a_M->Sizes.checksums);
    rteiSetTPtr(cartpole_MOE_2019a_M->extModeInfo, rtmGetTPtr
                (cartpole_MOE_2019a_M));
  }

  cartpole_MOE_2019a_M->solverInfoPtr = (&cartpole_MOE_2019a_M->solverInfo);
  cartpole_MOE_2019a_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&cartpole_MOE_2019a_M->solverInfo, 0.001);
  rtsiSetSolverMode(&cartpole_MOE_2019a_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  cartpole_MOE_2019a_M->blockIO = ((void *) &cartpole_MOE_2019a_B);
  (void) memset(((void *) &cartpole_MOE_2019a_B), 0,
                sizeof(B_cartpole_MOE_2019a_T));

  /* parameters */
  cartpole_MOE_2019a_M->defaultParam = ((real_T *)&cartpole_MOE_2019a_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &cartpole_MOE_2019a_X;
    cartpole_MOE_2019a_M->contStates = (x);
    (void) memset((void *)&cartpole_MOE_2019a_X, 0,
                  sizeof(X_cartpole_MOE_2019a_T));
  }

  /* states (dwork) */
  cartpole_MOE_2019a_M->dwork = ((void *) &cartpole_MOE_2019a_DW);
  (void) memset((void *)&cartpole_MOE_2019a_DW, 0,
                sizeof(DW_cartpole_MOE_2019a_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    cartpole_MOE_2019a_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 16;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  cartpole_MOE_2019a_M->Sizes.numContStates = (1);/* Number of continuous states */
  cartpole_MOE_2019a_M->Sizes.numPeriodicContStates = (0);
                                      /* Number of periodic continuous states */
  cartpole_MOE_2019a_M->Sizes.numY = (0);/* Number of model outputs */
  cartpole_MOE_2019a_M->Sizes.numU = (0);/* Number of model inputs */
  cartpole_MOE_2019a_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  cartpole_MOE_2019a_M->Sizes.numSampTimes = (2);/* Number of sample times */
  cartpole_MOE_2019a_M->Sizes.numBlocks = (50);/* Number of blocks */
  cartpole_MOE_2019a_M->Sizes.numBlockIO = (16);/* Number of block outputs */
  cartpole_MOE_2019a_M->Sizes.numBlockPrms = (110);/* Sum of parameter "widths" */
  return cartpole_MOE_2019a_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
