/*
 * parameter_Estimation_2019a.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "parameter_Estimation_2019a".
 *
 * Model version              : 1.3
 * Simulink Coder version : 9.1 (R2019a) 23-Nov-2018
 * C source code generated on : Wed Feb  1 12:33:17 2023
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "parameter_Estimation_2019a.h"
#include "parameter_Estimation_2019a_private.h"

/* Block signals (default storage) */
B_parameter_Estimation_2019a_T parameter_Estimation_2019a_B;

/* Continuous states */
X_parameter_Estimation_2019a_T parameter_Estimation_2019a_X;

/* Block states (default storage) */
DW_parameter_Estimation_2019a_T parameter_Estimation_2019a_DW;

/* Real-time model */
RT_MODEL_parameter_Estimation_T parameter_Estimation_2019a_M_;
RT_MODEL_parameter_Estimation_T *const parameter_Estimation_2019a_M =
  &parameter_Estimation_2019a_M_;

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 2;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  parameter_Estimation_2019a_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  parameter_Estimation_2019a_step();
  parameter_Estimation_2019a_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  parameter_Estimation_2019a_step();
  parameter_Estimation_2019a_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model step function */
void parameter_Estimation_2019a_step(void)
{
  /* local block i/o variables */
  real_T rtb_HILReadEncoderTimebase1_o2;
  real_T rtb_DiscreteFilter;
  real_T rtb_Add1;
  real_T rtb_Add2;
  real_T rtb_Gain3_tmp;
  if (rtmIsMajorTimeStep(parameter_Estimation_2019a_M)) {
    /* set solver stop time */
    if (!(parameter_Estimation_2019a_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&parameter_Estimation_2019a_M->solverInfo,
                            ((parameter_Estimation_2019a_M->Timing.clockTickH0 +
        1) * parameter_Estimation_2019a_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&parameter_Estimation_2019a_M->solverInfo,
                            ((parameter_Estimation_2019a_M->Timing.clockTick0 +
        1) * parameter_Estimation_2019a_M->Timing.stepSize0 +
        parameter_Estimation_2019a_M->Timing.clockTickH0 *
        parameter_Estimation_2019a_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(parameter_Estimation_2019a_M)) {
    parameter_Estimation_2019a_M->Timing.t[0] = rtsiGetT
      (&parameter_Estimation_2019a_M->solverInfo);
  }

  if (rtmIsMajorTimeStep(parameter_Estimation_2019a_M)) {
    /* S-Function (hil_read_encoder_timebase_block): '<Root>/HIL Read Encoder Timebase1' */

    /* S-Function Block: parameter_Estimation_2019a/HIL Read Encoder Timebase1 (hil_read_encoder_timebase_block) */
    {
      t_error result;
      result = hil_task_read_encoder
        (parameter_Estimation_2019a_DW.HILReadEncoderTimebase1_Task, 1,
         &parameter_Estimation_2019a_DW.HILReadEncoderTimebase1_Buffer[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(parameter_Estimation_2019a_M, _rt_error_message);
      } else {
        rtb_DiscreteFilter =
          parameter_Estimation_2019a_DW.HILReadEncoderTimebase1_Buffer[0];
        rtb_HILReadEncoderTimebase1_o2 =
          parameter_Estimation_2019a_DW.HILReadEncoderTimebase1_Buffer[1];
      }
    }

    /* Gain: '<Root>/Kenc' */
    parameter_Estimation_2019a_B.Kenc = parameter_Estimation_2019a_P.r_enc * 2.0
      * 3.1415926535897931 / parameter_Estimation_2019a_P.Nenc *
      rtb_DiscreteFilter;

    /* DiscreteFilter: '<S1>/Discrete Filter' */
    parameter_Estimation_2019a_DW.DiscreteFilter_tmp =
      (parameter_Estimation_2019a_B.Kenc -
       parameter_Estimation_2019a_P.DiscreteFilter_DenCoef[1] *
       parameter_Estimation_2019a_DW.DiscreteFilter_states) /
      parameter_Estimation_2019a_P.DiscreteFilter_DenCoef[0];
    rtb_DiscreteFilter = parameter_Estimation_2019a_P.DiscreteFilter_NumCoef[0] *
      parameter_Estimation_2019a_DW.DiscreteFilter_tmp +
      parameter_Estimation_2019a_P.DiscreteFilter_NumCoef[1] *
      parameter_Estimation_2019a_DW.DiscreteFilter_states;

    /* DiscreteFilter: '<Root>/Discrete Filter1' incorporates:
     *  Gain: '<S1>/Gain3'
     */
    parameter_Estimation_2019a_DW.DiscreteFilter1_tmp = ((1.0 /
      parameter_Estimation_2019a_P.T * rtb_DiscreteFilter -
      parameter_Estimation_2019a_P.af[1] *
      parameter_Estimation_2019a_DW.DiscreteFilter1_states[0]) -
      parameter_Estimation_2019a_P.af[2] *
      parameter_Estimation_2019a_DW.DiscreteFilter1_states[1]) /
      parameter_Estimation_2019a_P.af[0];
    parameter_Estimation_2019a_B.DiscreteFilter1 =
      (parameter_Estimation_2019a_P.bf[0] *
       parameter_Estimation_2019a_DW.DiscreteFilter1_tmp +
       parameter_Estimation_2019a_P.bf[1] *
       parameter_Estimation_2019a_DW.DiscreteFilter1_states[0]) +
      parameter_Estimation_2019a_P.bf[2] *
      parameter_Estimation_2019a_DW.DiscreteFilter1_states[1];
  }

  /* Integrator: '<Root>/Integrator' */
  parameter_Estimation_2019a_B.Integrator =
    parameter_Estimation_2019a_X.Integrator_CSTATE;

  /* Sin: '<Root>/Sine Wave2' incorporates:
   *  Sin: '<Root>/Sine Wave'
   *  Sin: '<Root>/Sine Wave1'
   */
  rtb_Add2 = parameter_Estimation_2019a_P.omega *
    parameter_Estimation_2019a_M->Timing.t[0];
  rtb_Gain3_tmp = sin(rtb_Add2 + parameter_Estimation_2019a_P.phi);

  /* Sum: '<Root>/Add1' incorporates:
   *  Sin: '<Root>/Sine Wave1'
   */
  rtb_Add1 = parameter_Estimation_2019a_B.DiscreteFilter1 - (sin(rtb_Add2 +
    (parameter_Estimation_2019a_P.phi + 1.5707963267948966)) *
    (parameter_Estimation_2019a_P.A0 * parameter_Estimation_2019a_P.omega) +
    parameter_Estimation_2019a_P.SineWave1_Bias);

  /* Integrator: '<Root>/Integrator1' */
  parameter_Estimation_2019a_B.Integrator1 =
    parameter_Estimation_2019a_X.Integrator1_CSTATE;

  /* Sum: '<Root>/Add2' incorporates:
   *  Gain: '<Root>/Gain'
   *  Sin: '<Root>/Sine Wave'
   *  Sum: '<Root>/Add'
   */
  rtb_Add2 = (parameter_Estimation_2019a_B.Kenc - (rtb_Gain3_tmp *
    parameter_Estimation_2019a_P.A0 + parameter_Estimation_2019a_P.SineWave_Bias))
    * parameter_Estimation_2019a_P.lambda + rtb_Add1;
  if (rtmIsMajorTimeStep(parameter_Estimation_2019a_M)) {
    /* Gain: '<S2>/Gain6' */
    parameter_Estimation_2019a_B.Gain6 = parameter_Estimation_2019a_P.rg *
      parameter_Estimation_2019a_P.Kt / parameter_Estimation_2019a_P.rm *
      parameter_Estimation_2019a_B.DiscreteFilter1;
  }

  /* Sum: '<Root>/Add5' incorporates:
   *  Gain: '<Root>/Gain4'
   *  Sin: '<Root>/Sine Wave2'
   *  Sum: '<Root>/Add3'
   */
  rtb_Gain3_tmp = (rtb_Gain3_tmp * (-parameter_Estimation_2019a_P.A0 *
    parameter_Estimation_2019a_P.omega * parameter_Estimation_2019a_P.omega) +
                   parameter_Estimation_2019a_P.SineWave2_Bias) -
    parameter_Estimation_2019a_P.lambda * rtb_Add1;

  /* Sum: '<S2>/Add' incorporates:
   *  Gain: '<Root>/Gain5'
   *  Gain: '<S2>/Gain5'
   *  Product: '<Root>/Product2'
   *  Product: '<Root>/Product3'
   *  Sum: '<Root>/Add4'
   *  Sum: '<Root>/Add5'
   */
  rtb_Add1 = ((rtb_Gain3_tmp * parameter_Estimation_2019a_B.Integrator1 +
               parameter_Estimation_2019a_B.DiscreteFilter1 *
               parameter_Estimation_2019a_B.Integrator) -
              parameter_Estimation_2019a_P.k * rtb_Add2) *
    (parameter_Estimation_2019a_P.R * parameter_Estimation_2019a_P.rm /
     (parameter_Estimation_2019a_P.rg * parameter_Estimation_2019a_P.Kt)) +
    parameter_Estimation_2019a_B.Gain6;

  /* Saturate: '<S2>/Saturation1' */
  if (rtb_Add1 > parameter_Estimation_2019a_P.Vmax) {
    parameter_Estimation_2019a_B.Saturation1 = parameter_Estimation_2019a_P.Vmax;
  } else if (rtb_Add1 < -parameter_Estimation_2019a_P.Vmax) {
    parameter_Estimation_2019a_B.Saturation1 =
      -parameter_Estimation_2019a_P.Vmax;
  } else {
    parameter_Estimation_2019a_B.Saturation1 = rtb_Add1;
  }

  /* End of Saturate: '<S2>/Saturation1' */

  /* Gain: '<Root>/On or off' */
  parameter_Estimation_2019a_B.Onoroff =
    parameter_Estimation_2019a_P.Onoroff_Gain *
    parameter_Estimation_2019a_B.Saturation1;
  if (rtmIsMajorTimeStep(parameter_Estimation_2019a_M)) {
    /* S-Function (hil_write_analog_block): '<Root>/HIL Write Analog' */

    /* S-Function Block: parameter_Estimation_2019a/HIL Write Analog (hil_write_analog_block) */
    {
      t_error result;
      result = hil_write_analog(parameter_Estimation_2019a_DW.HILInitialize_Card,
        &parameter_Estimation_2019a_P.HILWriteAnalog_channels, 1,
        &parameter_Estimation_2019a_B.Onoroff);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(parameter_Estimation_2019a_M, _rt_error_message);
      }
    }
  }

  /* Product: '<Root>/Product' incorporates:
   *  Gain: '<Root>/Gain1'
   */
  parameter_Estimation_2019a_B.Product = parameter_Estimation_2019a_P.Gain1_Gain
    * rtb_Add2 * parameter_Estimation_2019a_B.DiscreteFilter1;

  /* Product: '<Root>/Product1' incorporates:
   *  Gain: '<Root>/Gain3'
   */
  parameter_Estimation_2019a_B.Product1 = rtb_Gain3_tmp *
    (parameter_Estimation_2019a_P.Gain3_Gain * rtb_Add2);
  if (rtmIsMajorTimeStep(parameter_Estimation_2019a_M)) {
    /* Matfile logging */
    rt_UpdateTXYLogVars(parameter_Estimation_2019a_M->rtwLogInfo,
                        (parameter_Estimation_2019a_M->Timing.t));
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(parameter_Estimation_2019a_M)) {
    if (rtmIsMajorTimeStep(parameter_Estimation_2019a_M)) {
      /* Update for DiscreteFilter: '<S1>/Discrete Filter' */
      parameter_Estimation_2019a_DW.DiscreteFilter_states =
        parameter_Estimation_2019a_DW.DiscreteFilter_tmp;

      /* Update for DiscreteFilter: '<Root>/Discrete Filter1' */
      parameter_Estimation_2019a_DW.DiscreteFilter1_states[1] =
        parameter_Estimation_2019a_DW.DiscreteFilter1_states[0];
      parameter_Estimation_2019a_DW.DiscreteFilter1_states[0] =
        parameter_Estimation_2019a_DW.DiscreteFilter1_tmp;
    }
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(parameter_Estimation_2019a_M)) {
    /* signal main to stop simulation */
    {                                  /* Sample time: [0.0s, 0.0s] */
      if ((rtmGetTFinal(parameter_Estimation_2019a_M)!=-1) &&
          !((rtmGetTFinal(parameter_Estimation_2019a_M)-
             (((parameter_Estimation_2019a_M->Timing.clockTick1+
                parameter_Estimation_2019a_M->Timing.clockTickH1* 4294967296.0))
              * 0.001)) > (((parameter_Estimation_2019a_M->Timing.clockTick1+
                             parameter_Estimation_2019a_M->Timing.clockTickH1*
                             4294967296.0)) * 0.001) * (DBL_EPSILON))) {
        rtmSetErrorStatus(parameter_Estimation_2019a_M, "Simulation finished");
      }
    }

    rt_ertODEUpdateContinuousStates(&parameter_Estimation_2019a_M->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick0 and the high bits
     * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++parameter_Estimation_2019a_M->Timing.clockTick0)) {
      ++parameter_Estimation_2019a_M->Timing.clockTickH0;
    }

    parameter_Estimation_2019a_M->Timing.t[0] = rtsiGetSolverStopTime
      (&parameter_Estimation_2019a_M->solverInfo);

    {
      /* Update absolute timer for sample time: [0.001s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.001, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       * Timer of this task consists of two 32 bit unsigned integers.
       * The two integers represent the low bits Timing.clockTick1 and the high bits
       * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
       */
      parameter_Estimation_2019a_M->Timing.clockTick1++;
      if (!parameter_Estimation_2019a_M->Timing.clockTick1) {
        parameter_Estimation_2019a_M->Timing.clockTickH1++;
      }
    }
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void parameter_Estimation_2019a_derivatives(void)
{
  XDot_parameter_Estimation_201_T *_rtXdot;
  _rtXdot = ((XDot_parameter_Estimation_201_T *)
             parameter_Estimation_2019a_M->derivs);

  /* Derivatives for Integrator: '<Root>/Integrator' */
  _rtXdot->Integrator_CSTATE = parameter_Estimation_2019a_B.Product;

  /* Derivatives for Integrator: '<Root>/Integrator1' */
  _rtXdot->Integrator1_CSTATE = parameter_Estimation_2019a_B.Product1;
}

/* Model initialize function */
void parameter_Estimation_2019a_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)parameter_Estimation_2019a_M, 0,
                sizeof(RT_MODEL_parameter_Estimation_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&parameter_Estimation_2019a_M->solverInfo,
                          &parameter_Estimation_2019a_M->Timing.simTimeStep);
    rtsiSetTPtr(&parameter_Estimation_2019a_M->solverInfo, &rtmGetTPtr
                (parameter_Estimation_2019a_M));
    rtsiSetStepSizePtr(&parameter_Estimation_2019a_M->solverInfo,
                       &parameter_Estimation_2019a_M->Timing.stepSize0);
    rtsiSetdXPtr(&parameter_Estimation_2019a_M->solverInfo,
                 &parameter_Estimation_2019a_M->derivs);
    rtsiSetContStatesPtr(&parameter_Estimation_2019a_M->solverInfo, (real_T **)
                         &parameter_Estimation_2019a_M->contStates);
    rtsiSetNumContStatesPtr(&parameter_Estimation_2019a_M->solverInfo,
      &parameter_Estimation_2019a_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&parameter_Estimation_2019a_M->solverInfo,
      &parameter_Estimation_2019a_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&parameter_Estimation_2019a_M->solverInfo,
      &parameter_Estimation_2019a_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&parameter_Estimation_2019a_M->solverInfo,
      &parameter_Estimation_2019a_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&parameter_Estimation_2019a_M->solverInfo,
                          (&rtmGetErrorStatus(parameter_Estimation_2019a_M)));
    rtsiSetRTModelPtr(&parameter_Estimation_2019a_M->solverInfo,
                      parameter_Estimation_2019a_M);
  }

  rtsiSetSimTimeStep(&parameter_Estimation_2019a_M->solverInfo, MAJOR_TIME_STEP);
  parameter_Estimation_2019a_M->intgData.y = parameter_Estimation_2019a_M->odeY;
  parameter_Estimation_2019a_M->intgData.f[0] =
    parameter_Estimation_2019a_M->odeF[0];
  parameter_Estimation_2019a_M->intgData.f[1] =
    parameter_Estimation_2019a_M->odeF[1];
  parameter_Estimation_2019a_M->intgData.f[2] =
    parameter_Estimation_2019a_M->odeF[2];
  parameter_Estimation_2019a_M->contStates = ((X_parameter_Estimation_2019a_T *)
    &parameter_Estimation_2019a_X);
  rtsiSetSolverData(&parameter_Estimation_2019a_M->solverInfo, (void *)
                    &parameter_Estimation_2019a_M->intgData);
  rtsiSetSolverName(&parameter_Estimation_2019a_M->solverInfo,"ode3");
  rtmSetTPtr(parameter_Estimation_2019a_M,
             &parameter_Estimation_2019a_M->Timing.tArray[0]);
  rtmSetTFinal(parameter_Estimation_2019a_M, 10.0);
  parameter_Estimation_2019a_M->Timing.stepSize0 = 0.001;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    parameter_Estimation_2019a_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(parameter_Estimation_2019a_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(parameter_Estimation_2019a_M->rtwLogInfo, (NULL));
    rtliSetLogT(parameter_Estimation_2019a_M->rtwLogInfo, "tout");
    rtliSetLogX(parameter_Estimation_2019a_M->rtwLogInfo, "");
    rtliSetLogXFinal(parameter_Estimation_2019a_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(parameter_Estimation_2019a_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(parameter_Estimation_2019a_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(parameter_Estimation_2019a_M->rtwLogInfo, 0);
    rtliSetLogDecimation(parameter_Estimation_2019a_M->rtwLogInfo, 1);
    rtliSetLogY(parameter_Estimation_2019a_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(parameter_Estimation_2019a_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(parameter_Estimation_2019a_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &parameter_Estimation_2019a_B), 0,
                sizeof(B_parameter_Estimation_2019a_T));

  /* states (continuous) */
  {
    (void) memset((void *)&parameter_Estimation_2019a_X, 0,
                  sizeof(X_parameter_Estimation_2019a_T));
  }

  /* states (dwork) */
  (void) memset((void *)&parameter_Estimation_2019a_DW, 0,
                sizeof(DW_parameter_Estimation_2019a_T));

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(parameter_Estimation_2019a_M->rtwLogInfo, 0.0,
    rtmGetTFinal(parameter_Estimation_2019a_M),
    parameter_Estimation_2019a_M->Timing.stepSize0, (&rtmGetErrorStatus
    (parameter_Estimation_2019a_M)));

  /* Start for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: parameter_Estimation_2019a/HIL Initialize (hil_initialize_block) */
  {
    static const t_uint analog_input_channels[2U] = {
      0
      , 1
    };

    static const t_double analog_input_minimums[2U] = {
      -10.0
      , -10.0
    };

    static const t_double analog_input_maximums[2U] = {
      10.0
      , 10.0
    };

    static const t_uint analog_output_channels[2U] = {
      0
      , 1
    };

    static const t_double analog_output_minimums[2U] = {
      -10.0
      , -10.0
    };

    static const t_double analog_output_maximums[2U] = {
      10.0
      , 10.0
    };

    static const t_double initial_analog_outputs[2U] = {
      0.0
      , 0.0
    };

    static const t_uint encoder_input_channels[2U] = {
      0
      , 1
    };

    static const t_encoder_quadrature_mode encoder_quadrature[2U] = {
      ENCODER_QUADRATURE_4X
      , ENCODER_QUADRATURE_4X
    };

    static const t_int32 initial_encoder_counts[2U] = {
      0
      , 0
    };

    t_int result;
    t_boolean is_switching;
    result = hil_open("q2_usb", "0",
                      &parameter_Estimation_2019a_DW.HILInitialize_Card);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(parameter_Estimation_2019a_M, _rt_error_message);
      return;
    }

    is_switching = false;
    result = hil_set_card_specific_options
      (parameter_Estimation_2019a_DW.HILInitialize_Card,
       "d0=digital;d1=digital;led=auto;update_rate=normal;decimation=1", 63);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(parameter_Estimation_2019a_M, _rt_error_message);
      return;
    }

    result = hil_watchdog_clear(parameter_Estimation_2019a_DW.HILInitialize_Card);
    if (result < 0 && result != -QERR_HIL_WATCHDOG_CLEAR) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(parameter_Estimation_2019a_M, _rt_error_message);
      return;
    }

    if (!is_switching) {
      result = hil_set_analog_input_ranges
        (parameter_Estimation_2019a_DW.HILInitialize_Card, analog_input_channels,
         2U,
         analog_input_minimums, analog_input_maximums);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(parameter_Estimation_2019a_M, _rt_error_message);
        return;
      }
    }

    if (!is_switching) {
      result = hil_set_analog_output_ranges
        (parameter_Estimation_2019a_DW.HILInitialize_Card,
         analog_output_channels, 2U,
         analog_output_minimums, analog_output_maximums);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(parameter_Estimation_2019a_M, _rt_error_message);
        return;
      }
    }

    if (!is_switching) {
      result = hil_write_analog(parameter_Estimation_2019a_DW.HILInitialize_Card,
        analog_output_channels, 2U, initial_analog_outputs);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(parameter_Estimation_2019a_M, _rt_error_message);
        return;
      }
    }

    if (!is_switching) {
      result = hil_set_encoder_quadrature_mode
        (parameter_Estimation_2019a_DW.HILInitialize_Card,
         encoder_input_channels, 2U, (t_encoder_quadrature_mode *)
         encoder_quadrature);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(parameter_Estimation_2019a_M, _rt_error_message);
        return;
      }
    }

    if (!is_switching) {
      result = hil_set_encoder_counts
        (parameter_Estimation_2019a_DW.HILInitialize_Card,
         encoder_input_channels, 2U, initial_encoder_counts);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(parameter_Estimation_2019a_M, _rt_error_message);
        return;
      }
    }
  }

  /* Start for S-Function (hil_read_encoder_timebase_block): '<Root>/HIL Read Encoder Timebase1' */

  /* S-Function Block: parameter_Estimation_2019a/HIL Read Encoder Timebase1 (hil_read_encoder_timebase_block) */
  {
    t_error result;
    result = hil_task_create_encoder_reader
      (parameter_Estimation_2019a_DW.HILInitialize_Card,
       parameter_Estimation_2019a_P.HILReadEncoderTimebase1_samples,
       parameter_Estimation_2019a_P.HILReadEncoderTimebase1_channel, 2,
       &parameter_Estimation_2019a_DW.HILReadEncoderTimebase1_Task);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(parameter_Estimation_2019a_M, _rt_error_message);
    }
  }

  /* InitializeConditions for DiscreteFilter: '<S1>/Discrete Filter' */
  parameter_Estimation_2019a_DW.DiscreteFilter_states =
    parameter_Estimation_2019a_P.DiscreteFilter_InitialStates;

  /* InitializeConditions for DiscreteFilter: '<Root>/Discrete Filter1' */
  parameter_Estimation_2019a_DW.DiscreteFilter1_states[0] =
    parameter_Estimation_2019a_P.DiscreteFilter1_InitialStates;
  parameter_Estimation_2019a_DW.DiscreteFilter1_states[1] =
    parameter_Estimation_2019a_P.DiscreteFilter1_InitialStates;

  /* InitializeConditions for Integrator: '<Root>/Integrator' */
  parameter_Estimation_2019a_X.Integrator_CSTATE =
    parameter_Estimation_2019a_P.bhat0;

  /* InitializeConditions for Integrator: '<Root>/Integrator1' */
  parameter_Estimation_2019a_X.Integrator1_CSTATE =
    parameter_Estimation_2019a_P.mhat0;
}

/* Model terminate function */
void parameter_Estimation_2019a_terminate(void)
{
  /* Terminate for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: parameter_Estimation_2019a/HIL Initialize (hil_initialize_block) */
  {
    t_boolean is_switching;
    t_int result;
    t_uint32 num_final_analog_outputs = 0;
    static const t_uint analog_output_channels[2U] = {
      0
      , 1
    };

    hil_task_stop_all(parameter_Estimation_2019a_DW.HILInitialize_Card);
    hil_monitor_stop_all(parameter_Estimation_2019a_DW.HILInitialize_Card);
    is_switching = false;
    if ((parameter_Estimation_2019a_P.HILInitialize_AOTerminate && !is_switching)
        || (parameter_Estimation_2019a_P.HILInitialize_AOExit && is_switching))
    {
      parameter_Estimation_2019a_DW.HILInitialize_AOVoltages[0] =
        parameter_Estimation_2019a_P.HILInitialize_AOFinal;
      parameter_Estimation_2019a_DW.HILInitialize_AOVoltages[1] =
        parameter_Estimation_2019a_P.HILInitialize_AOFinal;
      num_final_analog_outputs = 2U;
    }

    if (num_final_analog_outputs > 0) {
      result = hil_write_analog(parameter_Estimation_2019a_DW.HILInitialize_Card,
        analog_output_channels, num_final_analog_outputs,
        &parameter_Estimation_2019a_DW.HILInitialize_AOVoltages[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(parameter_Estimation_2019a_M, _rt_error_message);
      }
    }

    hil_task_delete_all(parameter_Estimation_2019a_DW.HILInitialize_Card);
    hil_monitor_delete_all(parameter_Estimation_2019a_DW.HILInitialize_Card);
    hil_close(parameter_Estimation_2019a_DW.HILInitialize_Card);
    parameter_Estimation_2019a_DW.HILInitialize_Card = NULL;
  }
}
